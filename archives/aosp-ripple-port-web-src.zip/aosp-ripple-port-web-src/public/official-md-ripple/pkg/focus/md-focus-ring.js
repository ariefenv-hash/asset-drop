/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { customElement } from 'lit/decorators.js';
import { FocusRing } from './internal/focus-ring.js';
import { styles } from './internal/focus-ring-styles.cssresult.js';
/**
 * TODO(b/267336424): add docs
 *
 * @final
 * @suppress {visibility}
 */
let MdFocusRing = class MdFocusRing extends FocusRing {
};
MdFocusRing.styles = [styles];
MdFocusRing = __decorate([
    customElement('md-focus-ring')
], MdFocusRing);
export { MdFocusRing };
//# sourceMappingURL=md-focus-ring.js.map