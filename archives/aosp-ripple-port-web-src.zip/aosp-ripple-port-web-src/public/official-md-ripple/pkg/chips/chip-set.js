/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { customElement } from 'lit/decorators.js';
import { ChipSet } from './internal/chip-set.js';
import { styles } from './internal/chip-set-styles.cssresult.js';
/**
 * TODO(b/243982145): add docs
 *
 * @final
 * @suppress {visibility}
 */
let MdChipSet = class MdChipSet extends ChipSet {
};
MdChipSet.styles = [styles];
MdChipSet = __decorate([
    customElement('md-chip-set')
], MdChipSet);
export { MdChipSet };
//# sourceMappingURL=chip-set.js.map