/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { customElement } from 'lit/decorators.js';
import { AssistChip } from './internal/assist-chip.js';
import { styles } from './internal/assist-styles.cssresult.js';
import { styles as elevatedStyles } from './internal/elevated-styles.cssresult.js';
import { styles as sharedStyles } from './internal/shared-styles.cssresult.js';
/**
 * TODO(b/243982145): add docs
 *
 * @final
 * @suppress {visibility}
 */
let MdAssistChip = class MdAssistChip extends AssistChip {
};
MdAssistChip.styles = [
    sharedStyles,
    elevatedStyles,
    styles,
];
MdAssistChip = __decorate([
    customElement('md-assist-chip')
], MdAssistChip);
export { MdAssistChip };
//# sourceMappingURL=assist-chip.js.map