"use client";
/**
 * 系统主题色选择界面的配色方案圆形预览（Wallpaper & style → 颜色选项图标）
 * —— 第七轮按铁律四与壁纸取色管线融合：本组件不再持有任何平行演示种子输入，
 * 种子一律来自 AmbientBackdrop 的壁纸上传 → MCU QuantizerWsmeans + Score.java
 * 提取候选（config.wallpaperSeeds），点击候选即应用为全站主题种子（与系统
 * WallpaperPicker2 行为一致：点选颜色选项 = 应用该方案）。未上传壁纸时的兜底
 * 种子为源码常量 ColorScheme.GOOGLE_BLUE（见下方诚实声明）。
 *
 * 【源码依据】tmp/tp17（platform/packages/apps/ThemePicker，Android 17 manifest 项目）
 *  1. 圆形几何：src/com/android/customization/picker/color/ui/view/ColorOptionIconView.kt
 *     —— 整圆 = 4 个 90° 扇形（drawArc startAngle 0/90/180/270，useCenter=true）：
 *        color3 [0°,90°] 右下、color2 [90°,180°] 左下、color0 [180°,270°] 左上、
 *        color1 [270°,360°] 右上；w/h 取偶避免扇形间像素缝隙（roundDownToEven）。
 *        color0 == color1（同为 accent1）→ 顶部两象限同色，视觉上合并为
 *        "上半大半圆主色 + 底部两个 1/4 扇形配色"——即用户描述的系统主题色选择样式。
 *  2. 四色映射：src/com/android/customization/model/color/ColorProvider.kt L246-272
 *        light = [accent1.s600, accent1.s600, withLStar(accent2.s500, 85), accent3.s300]
 *        dark  = [accent1.s200, accent1.s200, withLStar(accent2.s500, 35), accent3.s300]
 *     shade→tone（sysui17/monet/TonalPalette.java getAtTone）：s600→40、s200→80、
 *     s500→50、s300→70；ALPHA_MASK=0xFF（全不透明）。
 *  3. 四种风格色板（styleList，ColorProvider.kt L71-74）：TONAL_SPOT / SPRITZ /
 *     VIBRANT / EXPRESSIVE，CoreSpec 逐值取自 Android 13 SystemUI/monet/ColorScheme.kt
 *     L158-195（MCU 语义，Android 14+ libmonet 承接）——移植见 src/aosp/monetStyleSpec.ts。
 *  4. 尺寸：res/values/dimens.xml L115 component_color_chip_size = 40dp；
 *     风格标签 res/values-zh-rCN/strings.xml content_description_*_color_option。
 *
 * 【与壁纸取色管线的融合（铁律四）】
 *  - 种子候选：config.wallpaperSeeds（AmbientBackdrop 发布，Score 排序 + HCT 衍生）；
 *  - 选中态：config.customAccentHex（presetId === AMBIENT_PRESET_ID 时）——点击候选
 *    经 onConfigChange 应用为全站种子，主题、涟漪、滑块、圆形预览实时同步；
 *  - 兜底：无壁纸时使用 GOOGLE_BLUE（sysui17/monet/ColorScheme.java L55 源码常量），
 *    界面如实标注"源码兜底种子"。
 *
 * 【诚实声明】
 *  - 未上传壁纸时种子为源码常量 GOOGLE_BLUE（非壁纸提取，界面已标注）；上传壁纸后
 *    本卡种子全部来自 QuantizerWsmeans + Score 取色管线；
 *  - 选中态外圈（option_item_border/option_item_background）属于 WallpaperPicker2 依赖库
 *    资源（本仓库未含），未移植——本卡只呈现 ColorOptionIconView 本体；
 *  - 预设色（getPresetColorPreview）与单色（Monochrome）变体未纳入（需预置 bundle 桩）；
 *  - L* 重定标按 Android ColorUtils colorToLAB/LABToColor 白点 {95.047,100,108.883}
 *    （D65）直译，与 HCT tone 同源不同路径。
 */
import React, { useMemo } from 'react';
import { buildSchemePreviewColors, THEME_STYLE_LABELS, type ThemeStyleName } from '@/aosp/monetStyleSpec';
import { AMBIENT_PRESET_ID, type LabConfigState } from './InteractiveLab';
import type { M3ThemeTokens } from '@/aosp/dynamicColor';

/** 兜底种子：GOOGLE_BLUE 为源码常量（sysui17/monet/ColorScheme.java L55） */
const GOOGLE_BLUE = '#1B6EF3';
const FALLBACK_SEEDS = [
  {
    name: '谷歌蓝 · 源码兜底种子',
    hex: GOOGLE_BLUE,
    desc: '未上传壁纸时的兜底：ColorScheme.GOOGLE_BLUE（源码常量）；上传壁纸后由 MCU 取色管线接管',
  },
];
interface SeedCandidate {
  name: string;
  hex: string;
  desc: string;
}

const STYLES: ThemeStyleName[] = ['tonal_spot', 'spritz', 'vibrant', 'expressive'];

/**
 * 四象限扇形（ColorOptionIconView.kt onDraw L72-111 逐行转译）。
 * Canvas 角度：0° = 3 点钟方向、顺时针；SVG y 向下，顺时针 = sweep-flag 1。
 * 绘制顺序与源码一致：color3 → color2 → color0 → color1。
 */
function QuadrantCircle({ colors, size = 40 }: { colors: [string, string, string, string]; size?: number }) {
  const r = size / 2;
  // 第 25 轮：每片加同色 0.75 描边（外扩 ~0.4px）——相邻扇形共享边在浏览器抗锯齿下
  // 会出现发丝状缝隙（源码 roundDownToEven 取偶注释同为防缝口径，SVG 侧同色描边补齐）
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true" style={{ display: 'block' }}>
      {/* color3：drawArc(oval, 0, 90, true) —— 右下 */}
      <path d={`M ${r} ${r} L ${size} ${r} A ${r} ${r} 0 0 1 ${r} ${size} Z`} fill={colors[3]} stroke={colors[3]} strokeWidth={0.75} strokeLinejoin="round" />
      {/* color2：drawArc(oval, 90, 90, true) —— 左下 */}
      <path d={`M ${r} ${r} L ${r} ${size} A ${r} ${r} 0 0 1 0 ${r} Z`} fill={colors[2]} stroke={colors[2]} strokeWidth={0.75} strokeLinejoin="round" />
      {/* color0：drawArc(oval, 180, 90, true) —— 左上 */}
      <path d={`M ${r} ${r} L 0 ${r} A ${r} ${r} 0 0 1 ${r} 0 Z`} fill={colors[0]} stroke={colors[0]} strokeWidth={0.75} strokeLinejoin="round" />
      {/* color1：drawArc(oval, 270, 90, true) —— 右上（与 color0 同色 → 顶半圆） */}
      <path d={`M ${r} ${r} L ${r} 0 A ${r} ${r} 0 0 1 ${size} ${r} Z`} fill={colors[1]} stroke={colors[1]} strokeWidth={0.75} strokeLinejoin="round" />
    </svg>
  );
}

interface ColorSchemePreviewDemoProps {
  theme: M3ThemeTokens;
  config: LabConfigState;
  onConfigChange: React.Dispatch<React.SetStateAction<LabConfigState>>;
  /** 第 25 轮：明暗模式双向接线 —— 点击浅/深行圆形预览 = 应用该派生风格 + 该行明暗 */
  isDark: boolean;
  onDarkChange: (dark: boolean) => void;
}

export function ColorSchemePreviewDemo({ theme, config, onConfigChange, isDark, onDarkChange }: ColorSchemePreviewDemoProps) {
  // 种子候选：壁纸取色管线（铁律四：唯一来源）→ 兜底 GOOGLE_BLUE
  const seeds: SeedCandidate[] =
    config.wallpaperSeeds && config.wallpaperSeeds.length > 0
      ? config.wallpaperSeeds
      : FALLBACK_SEEDS;
  const fromWallpaper = config.wallpaperSeeds != null && config.wallpaperSeeds.length > 0;

  // 选中态即全站主题种子（presetId === AMBIENT_PRESET_ID 时 customAccentHex 生效）
  const accent = config.presetId === AMBIENT_PRESET_ID ? config.customAccentHex ?? null : null;
  const activeIdx = useMemo(() => {
    if (accent) {
      const i = seeds.findIndex((s) => s.hex.toLowerCase() === accent.toLowerCase());
      if (i >= 0) return i;
    }
    return 0;
  }, [accent, seeds]);
  const seed = seeds[activeIdx];

  const { light, dark } = useMemo(() => {
    return {
      light: STYLES.map((s) => buildSchemePreviewColors(seed.hex, s, false)),
      dark: STYLES.map((s) => buildSchemePreviewColors(seed.hex, s, true)),
    };
  }, [seed.hex]);

  /** 点击候选 = 应用为全站主题种子（与 AmbientBackdrop.applyScheme 同一动作） */
  const applySeed = (s: SeedCandidate) => {
    onConfigChange((prev) => ({
      ...prev,
      presetId: AMBIENT_PRESET_ID,
      customAccentHex: s.hex,
      customAccentLabel: s.name,
    }));
  };

  /**
   * 第 25 轮（用户要求）：圆形预览可点击应用 —— 此前仅展示，派生风格（spritz/vibrant）
   * 点不动；现点击任意圆形 = 应用该风格为全站 themeVariant + 应用该行明暗模式
   * （与 WallpaperPicker2「点选颜色选项 = 应用方案」一致；种子色不变，由上方种子条负责）。
   * 逻辑口径：行列决定动作 —— 列 = ColorProvider.kt styleList 四风格；行 = 浅/暗 preview。
   */
  const applyStyle = (style: ThemeStyleName, dark: boolean) => {
    onConfigChange((prev) => ({ ...prev, themeVariant: style }));
    onDarkChange(dark);
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          系统主题色选择 · 配色方案圆形预览（上半圆主色 + 两 1/4 扇形配色）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          ThemePicker ColorOptionIconView.kt {'{'}4×drawArc 90°{'}'} · ColorProvider.kt L246-311 {'{'}accent1 s600/s200 ×2 · accent2 s500→LStar 85/35 · accent3 s300{'}'} · TonalPalette.getAtTone(sN)=tone((1000−N)/10) · monet ColorScheme.kt CoreSpec · android-17.0.0_r1
        </span>
      </div>

      {/* 种子候选（壁纸取色管线；点击 = 应用为全站主题种子，与 WallpaperPicker2 一致） */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-slate-500 dark:text-slate-400 shrink-0">种子色：</span>
        {seeds.map((s, i) => (
          <button
            key={`${s.name}-${s.hex}`}
            type="button"
            onClick={() => applySeed(s)}
            title={s.desc}
            aria-pressed={i === activeIdx}
            className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] transition-opacity hover:opacity-90"
            style={{
              borderColor: i === activeIdx ? theme.primary : theme.outlineVariant,
              color: theme.onSurface,
              backgroundColor: i === activeIdx ? theme.surfaceContainerHigh : 'transparent',
            }}
          >
            <span
              className="h-3.5 w-3.5 rounded-full shrink-0"
              style={{ backgroundColor: s.hex }}
              aria-hidden="true"
            />
            {s.hex.toUpperCase()}
          </button>
        ))}
        <span className="text-[10px] text-slate-500 dark:text-slate-400 break-all">
          {fromWallpaper
            ? '来源：壁纸 MCU QuantizerWsmeans + Score 取色管线（AmbientBackdrop 上传壁纸后实时发布）'
            : '来源：未上传壁纸，使用源码兜底种子 ColorScheme.GOOGLE_BLUE —— 到上方「动态配色」卡片上传壁纸即可由取色管线实时接管'}
        </span>
      </div>

      <div className="space-y-4 rounded-lg p-5" style={{ backgroundColor: theme.surfaceContainerLow }}>
        {/* 浅色一行 + 深色一行（previewInfo.resolveColors(false/true) 两组）；
            第 25 轮：每颗圆形均可点击 = 应用该风格 + 该行明暗（选中外圈随行列判定） */}
        {([
          { title: '浅色主题（getLightColorPreview）', row: light, dark: false },
          { title: '深色主题（getDarkColorPreview）', row: dark, dark: true },
        ] as const).map((group) => (
          <div key={group.title} className="space-y-2">
            <div className="text-xs font-medium text-slate-600 dark:text-slate-300">
              {group.title} · 种子 {seed.hex.toUpperCase()}
              <span className="ml-2 font-normal text-slate-500 dark:text-slate-400">点击圆形即应用（风格 + {group.dark ? '深色' : '浅色'}模式）</span>
            </div>
            <div className="flex flex-wrap gap-6">
              {STYLES.map((s, i) => {
                const active = s === config.themeVariant && group.dark === isDark;
                return (
                  <div key={s} className="flex flex-col items-center gap-1.5 w-[72px]">
                    <button
                      type="button"
                      onClick={() => applyStyle(s, group.dark)}
                      aria-pressed={active}
                      aria-label={`应用${THEME_STYLE_LABELS[s]}（${group.dark ? '深色' : '浅色'}主题）`}
                      title={`点击应用：${THEME_STYLE_LABELS[s]} · ${group.dark ? '深色' : '浅色'}模式`}
                      className="inline-block cursor-pointer rounded-full transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2"
                      style={{
                        lineHeight: 0,
                        // 选中风格（= 全站 themeVariant）且明暗行匹配时外圈指示：surface 间隔 + primary 圆环
                        boxShadow: active
                          ? `0 0 0 2px ${theme.surface}, 0 0 0 4px ${theme.primary}`
                          : 'none',
                      }}
                    >
                      <QuadrantCircle colors={group.row[i].colors} size={40} />
                    </button>
                    <span className="text-[10px] text-center leading-tight text-slate-500 dark:text-slate-400">
                      {THEME_STYLE_LABELS[s]}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {/* 四象限角色说明 */}
        <div className="grid gap-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400 sm:grid-cols-2">
          <span>· 左上 + 右上（合并为上半大半圆）＝ accent1（主色调色板）</span>
          <span>· 浅色取 shade s600 → tone 40；深色取 shade s200 → tone 80</span>
          <span>· 左下 1/4 扇形 ＝ accent2 shade s500 → tone 50 后重设 L*（浅 85 / 深 35）</span>
          <span>· 右下 1/4 扇形 ＝ accent3 shade s300 → tone 70（明暗同值）</span>
        </div>
      </div>

      <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          <span className="font-medium text-slate-700 dark:text-slate-300">融合说明（铁律四）：</span>
          本卡的种子候选与选中态即全站主题种子数据流——「动态配色」卡片上传壁纸 →
          MCU QuantizerWsmeans + Score.java 提取候选（Score 排序 + HCT 衍生）→
          config.wallpaperSeeds 发布 → 此处逐颗以四风格圆形方案呈现；点击候选 =
          应用为全站种子（页面底色、涟漪、滑块、开关、按钮色板与本卡同步刷新），
          与系统 WallpaperPicker2 的「点选颜色选项 = 应用方案」行为一致。
        </p>
        <p>
          <span className="font-medium text-slate-700 dark:text-slate-300">风格来源（styleList，每颗种子 4 个选项）：</span>
          TONAL_SPOT 主 chroma 36 / SPRITZ 12 / VIBRANT MaxOut(130) / EXPRESSIVE（色相 +240°，
          chroma 40）——a2/a3 色相分别走 HueVibrantSecondary/Tertiary 与
          HueExpressiveSecondary/Tertiary 分段旋转表（ColorScheme.kt L75-103）；外圈指示 =
          当前全站 themeVariant（第 25 轮起与明暗行联合判定）。四种风格均已接入全站
          buildM3Theme（中性色 n1/n2 同样按 CoreSpec：Spritz 2/2 · Vibrant 10/12），
          点击即全站生效（页面底色、涟漪、滑块、开关同步）。
        </p>
        <p>
          <span className="font-medium text-slate-700 dark:text-slate-300">几何细节：</span>
          四扇形按 Canvas 角度 0°/90°/180°/270° 顺时针各 90°（useCenter=true），绘制顺序
          color3→color2→color0→color1；直径 40px = component_color_chip_size（40dp，取偶数
          与源码 roundDownToEven 注释一致）。
        </p>
        <p>
          <span className="text-amber-600 dark:text-amber-400">诚实声明：</span>
          ① 未上传壁纸时种子为源码常量 GOOGLE_BLUE（非壁纸提取，界面已标注来源）；
          ② 选中态外圈描边属于 WallpaperPicker2 依赖库资源（option_item_border 等，
          本仓库未含），未移植，风格选中指示为本页标注；③ 预设色与单色变体未纳入
          （输入为预置 bundle 桩数据）；④ L* 重定标按 Android ColorUtils colorToLAB/
          LABToColor 白点 {'{95.047, 100, 108.883}'}（D65）直译，与 HCT tone 同源不同路径。
        </p>
      </div>
    </div>
  );
}
