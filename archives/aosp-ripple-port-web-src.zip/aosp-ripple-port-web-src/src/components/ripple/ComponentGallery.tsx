"use client";
import React, { useState } from 'react';
import {
  Bell,
  Bluetooth,
  Bookmark,
  Flashlight,
  Heart,
  Moon,
  MoreVertical,
  Play,
  Share2,
  Shield,
  SkipBack,
  SkipForward,
  Sliders,
  Sun,
  Volume2,
  Wifi,
} from 'lucide-react';
import { hexToRgbaWave, M3ThemeTokens } from '../../aosp/dynamicColor';
import { AospExpressiveSlider } from './AospExpressiveSlider';
import { AospExpressiveSwitch } from './AospExpressiveSwitch';
import { AospRippleSurface } from './AospRippleSurface';
import { ExpressiveControlsGallery } from './ExpressiveControlsGallery';
import { LabConfigState } from './InteractiveLab';
import { RowSqueezeGallery } from './RowSqueezeGallery';

interface ComponentGalleryProps {
  isDark: boolean;
  config: LabConfigState;
  theme: M3ThemeTokens;
}

export const ComponentGallery: React.FC<ComponentGalleryProps> = React.memo(
  ({ isDark, config, theme }) => {
    const [tiles, setTiles] = useState({
      wifi: true,
      bluetooth: true,
      flashlight: false,
      dnd: false,
    });
    const [notificationsEnabled, setNotificationsEnabled] = useState(true);
    const [hapticsEnabled, setHapticsEnabled] = useState(true);
    const [masterExpressiveEnabled, setMasterExpressiveEnabled] = useState(true);
    const [minimalDotSwitch, setMinimalDotSwitch] = useState(false);
    const [liked, setLiked] = useState(false);
    const [bookmarked, setBookmarked] = useState(false);

    const [mediaVolume, setMediaVolume] = useState(64);
    const [screenBrightness, setScreenBrightness] = useState(78);
    const [hapticSteps, setHapticSteps] = useState(3);

    const waveColor = hexToRgbaWave(
      theme.primary,
      Math.max(isDark ? 0.24 : 0.22, config.waveAlpha)
    );
    const filledWave = { r: 1, g: 1, b: 1, a: 0.28 };
    const sparkleColor = { r: 1, g: 1, b: 1, a: config.sparkleAlpha };

    const toggleTile = (key: keyof typeof tiles) => {
      setTiles((prev) => ({ ...prev, [key]: !prev[key] }));
    };

    return (
      <section id="gallery" className="scroll-mt-24 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
              Android 12–17 Expressive 组件级移植展示
            </h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              包含 QS 整排挤压磁贴、MaterialButtonGroup、带手柄滑块、形变开关（MaterialSwitch）及系统组件，均由 WebGL2 着色器、弹簧物理与 Monet HCT 动态色彩实时驱动。
            </p>
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
            {config.mode === 'framework'
              ? 'Engine: RippleShader.java'
              : 'Engine: SystemUI RippleShader.kt'}
          </div>
        </div>

        <RowSqueezeGallery isDark={isDark} config={config} theme={theme} />

        <ExpressiveControlsGallery isDark={isDark} config={config} theme={theme} />

        {/* Expressive Handle Sliders & Switches Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  AOSP Expressive 带手柄滑块 (BaseSlider · m3_comp_slider)
                </h3>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  4dp 手柄按压形变至 2dp (0.5×)，6dp 轨道断隙与 4dp 尾端 stop indicator；分段滑块仅绘制内部步进 tick，尾端圆点随滑块避让。
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                gap 6dp · handle 4→2dp
              </span>
            </div>

            <div className="space-y-5 pt-1">
              <AospExpressiveSlider
                label="XS 16dp 连续滑块（媒体音量）"
                value={mediaVolume}
                min={0}
                max={100}
                step={1}
                size="xs"
                unit="%"
                mode={config.mode}
                waveColor={waveColor}
                sparkleColor={sparkleColor}
                sparkleStrength={config.sparkleStrength}
                distortionStrength={config.distortionStrength}
                systemUiShape={config.systemUiShape}
                speedMultiplier={config.speedMultiplier}
                densityScale={config.densityScale}
                accentHex={theme.primary}
                theme={theme}
                onChange={setMediaVolume}
              />

              <AospExpressiveSlider
                label="M 40dp 内嵌图标滑块（屏幕亮度）"
                value={screenBrightness}
                min={0}
                max={100}
                step={1}
                size="m"
                unit="%"
                icon={<Sun className="h-5 w-5" />}
                mode={config.mode}
                waveColor={waveColor}
                sparkleColor={sparkleColor}
                sparkleStrength={config.sparkleStrength}
                distortionStrength={config.distortionStrength}
                systemUiShape={config.systemUiShape}
                speedMultiplier={config.speedMultiplier}
                densityScale={config.densityScale}
                accentHex={theme.primary}
                theme={theme}
                onChange={setScreenBrightness}
              />

              <AospExpressiveSlider
                label="L 56dp 分段步进滑块（触感强度挡位）"
                value={hapticSteps}
                min={0}
                max={5}
                step={1}
                size="l"
                showStops
                unit=" 档"
                icon={<Volume2 className="h-6 w-6" />}
                mode={config.mode}
                waveColor={waveColor}
                sparkleColor={sparkleColor}
                sparkleStrength={config.sparkleStrength}
                distortionStrength={config.distortionStrength}
                systemUiShape={config.systemUiShape}
                speedMultiplier={config.speedMultiplier}
                densityScale={config.densityScale}
                accentHex={theme.primary}
                theme={theme}
                onChange={setHapticSteps}
              />
            </div>
          </div>

          <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs flex flex-col justify-between gap-5">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                AOSP MaterialSwitch 与主开关横幅
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                52×32dp 轨道，拇指按压动态膨胀至 28dp 并伴随无界 WebGL2 闪烁光环
              </p>
            </div>

            <AospRippleSurface
              role="button"
              tabIndex={0}
              ariaPressed={masterExpressiveEnabled}
              onClick={() => setMasterExpressiveEnabled((v) => !v)}
              mode={config.mode}
              color={masterExpressiveEnabled ? filledWave : waveColor}
              sparkleColor={sparkleColor}
              sparkleStrength={config.sparkleStrength}
              distortionStrength={config.distortionStrength}
              systemUiShape={config.systemUiShape}
              speedMultiplier={config.speedMultiplier}
              densityScale={config.densityScale}
              maskRadius={28}
              style={
                masterExpressiveEnabled
                  ? { backgroundColor: theme.primary, color: theme.onPrimary }
                  : undefined
              }
              className={`rounded-[28px] px-5 py-4 transition-colors ${
                masterExpressiveEnabled
                  ? ''
                  : 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-100'
              }`}
            >
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">
                    自适应表达性触控反馈
                  </div>
                  <div
                    className={`text-xs truncate ${
                      masterExpressiveEnabled
                        ? 'opacity-85'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {masterExpressiveEnabled
                      ? 'MainSwitchPreference · 已开启'
                      : '已关闭'}
                  </div>
                </div>
                <AospExpressiveSwitch
                  checked={masterExpressiveEnabled}
                  onChange={setMasterExpressiveEnabled}
                  ariaLabel="自适应表达性触控反馈主开关"
                  showIcons
                  mode={config.mode}
                  waveColor={masterExpressiveEnabled ? filledWave : waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  accentHex={masterExpressiveEnabled ? theme.onPrimary : theme.primary}
                  onPrimaryHex={theme.primary}
                />
              </div>
            </AospRippleSurface>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between gap-4 px-4 py-3.5">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                    带状态图标开关 (24→28dp)
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    m3_comp_switch_thumb_icon · 16dp 矢量图标
                  </div>
                </div>
                <AospExpressiveSwitch
                  checked={notificationsEnabled}
                  onChange={setNotificationsEnabled}
                  ariaLabel="带状态图标开关"
                  showIcons
                  mode={config.mode}
                  waveColor={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  accentHex={theme.primary}
                  onPrimaryHex={theme.onPrimary}
                />
              </div>

              <div className="flex items-center justify-between gap-4 px-4 py-3.5">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                    标准无图标圆点开关 (16→24→28dp)
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    未选中 16dp 圆点 · 选中 24dp · 按下 28dp
                  </div>
                </div>
                <AospExpressiveSwitch
                  checked={minimalDotSwitch}
                  onChange={setMinimalDotSwitch}
                  ariaLabel="标准无图标圆点开关"
                  showIcons={false}
                  mode={config.mode}
                  waveColor={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  accentHex={theme.primary}
                  onPrimaryHex={theme.onPrimary}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Quick Settings 2x2 Grid */}
          <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs">
            <div className="mb-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="font-medium text-slate-800 dark:text-slate-200">
                Quick Settings 磁贴
              </span>
              <span>点击切换状态</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                {
                  key: 'wifi' as const,
                  label: 'WLAN',
                  sub: tiles.wifi ? 'Pixel_5G' : '已关闭',
                  icon: Wifi,
                },
                {
                  key: 'bluetooth' as const,
                  label: '蓝牙',
                  sub: tiles.bluetooth ? '已连接' : '已关闭',
                  icon: Bluetooth,
                },
                {
                  key: 'flashlight' as const,
                  label: '手电筒',
                  sub: tiles.flashlight ? '开启' : '关闭',
                  icon: Flashlight,
                },
                {
                  key: 'dnd' as const,
                  label: '勿扰模式',
                  sub: tiles.dnd ? '开启' : '关闭',
                  icon: Moon,
                },
              ].map((item) => {
                const active = tiles[item.key];
                const Icon = item.icon;
                return (
                  <AospRippleSurface
                    key={item.key}
                    role="button"
                    tabIndex={0}
                    ariaPressed={active}
                    onClick={() => toggleTile(item.key)}
                    mode={config.mode}
                    color={active ? filledWave : waveColor}
                    sparkleColor={sparkleColor}
                    sparkleStrength={config.sparkleStrength}
                    distortionStrength={config.distortionStrength}
                    systemUiShape={config.systemUiShape}
                    speedMultiplier={config.speedMultiplier}
                    densityScale={config.densityScale}
                    maskRadius={20}
                    style={
                      active
                        ? { backgroundColor: theme.primary, color: theme.onPrimary }
                        : undefined
                    }
                    className={`rounded-[20px] p-4 transition-colors ${
                      active
                        ? ''
                        : 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-5 w-5 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{item.label}</div>
                        <div
                          className={`text-xs truncate ${
                            active ? 'opacity-85' : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {item.sub}
                        </div>
                      </div>
                    </div>
                  </AospRippleSurface>
                );
              })}
            </div>

            {/* Material 3 Button Row */}
            <div className="mt-5 pt-5 border-t border-slate-200 dark:border-slate-800">
              <div className="mb-3 text-xs font-medium text-slate-600 dark:text-slate-300">
                Material 3 按钮与无界图标反馈
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <AospRippleSurface
                  role="button"
                  tabIndex={0}
                  mode={config.mode}
                  color={filledWave}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  maskRadius={999}
                  style={{ backgroundColor: theme.primary, color: theme.onPrimary }}
                  className="rounded-full px-5 py-2.5 text-xs font-medium"
                >
                  确认应用
                </AospRippleSurface>

                <AospRippleSurface
                  role="button"
                  tabIndex={0}
                  mode={config.mode}
                  color={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  maskRadius={999}
                  style={{
                    backgroundColor: theme.secondaryContainer,
                    color: theme.onSecondaryContainer,
                  }}
                  className="rounded-full px-5 py-2.5 text-xs font-medium"
                >
                  色调按钮
                </AospRippleSurface>

                <AospRippleSurface
                  role="button"
                  tabIndex={0}
                  mode={config.mode}
                  color={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  maskRadius={999}
                  className="rounded-full border border-slate-300 dark:border-slate-700 px-5 py-2.5 text-xs font-medium text-slate-800 dark:text-slate-200"
                >
                  描边按钮
                </AospRippleSurface>

                <div className="ml-auto flex items-center gap-2">
                  <AospRippleSurface
                    role="button"
                    tabIndex={0}
                    ariaLabel="收藏"
                    ariaPressed={liked}
                    onClick={() => setLiked((v) => !v)}
                    mode={config.mode}
                    color={waveColor}
                    sparkleColor={sparkleColor}
                    sparkleStrength={config.sparkleStrength}
                    distortionStrength={config.distortionStrength}
                    systemUiShape="circle"
                    hasMask={false}
                    centered
                    unboundedPadding={20}
                    speedMultiplier={config.speedMultiplier}
                    densityScale={config.densityScale}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 dark:text-slate-300"
                  >
                    <Heart
                      className={`h-5 w-5 ${
                        liked ? 'fill-rose-500 text-rose-500' : ''
                      }`}
                    />
                  </AospRippleSurface>

                  <AospRippleSurface
                    role="button"
                    tabIndex={0}
                    ariaLabel="书签"
                    ariaPressed={bookmarked}
                    onClick={() => setBookmarked((v) => !v)}
                    mode={config.mode}
                    color={waveColor}
                    sparkleColor={sparkleColor}
                    sparkleStrength={config.sparkleStrength}
                    distortionStrength={config.distortionStrength}
                    systemUiShape="circle"
                    hasMask={false}
                    centered
                    unboundedPadding={20}
                    speedMultiplier={config.speedMultiplier}
                    densityScale={config.densityScale}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 dark:text-slate-300"
                  >
                    <Bookmark
                      className="h-5 w-5"
                      style={
                        bookmarked
                          ? { fill: theme.primary, color: theme.primary }
                          : undefined
                      }
                    />
                  </AospRippleSurface>

                  <AospRippleSurface
                    role="button"
                    tabIndex={0}
                    ariaLabel="分享"
                    mode={config.mode}
                    color={waveColor}
                    sparkleColor={sparkleColor}
                    sparkleStrength={config.sparkleStrength}
                    distortionStrength={config.distortionStrength}
                    systemUiShape="circle"
                    hasMask={false}
                    centered
                    unboundedPadding={20}
                    speedMultiplier={config.speedMultiplier}
                    densityScale={config.densityScale}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 dark:text-slate-300"
                  >
                    <Share2 className="h-5 w-5" />
                  </AospRippleSurface>
                </div>
              </div>
            </div>
          </div>

          {/* Android Settings List & Media Surface */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
              <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  Android 系统设置列表项 (矩形边界遮罩 + Expressive Switch)
                </span>
                <span>点击条目或开关</span>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                <AospRippleSurface
                  role="button"
                  tabIndex={0}
                  onClick={() => setNotificationsEnabled((v) => !v)}
                  mode={config.mode}
                  color={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  maskRadius={0}
                  className="px-5 py-4"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5 min-w-0">
                      <Bell className="h-5 w-5 text-slate-600 dark:text-slate-300 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                          通知涟漪与角标提示
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {notificationsEnabled ? '已启用系统通知触控反馈' : '已静音通知反馈'}
                        </div>
                      </div>
                    </div>
                    <AospExpressiveSwitch
                      checked={notificationsEnabled}
                      onChange={setNotificationsEnabled}
                      ariaLabel="通知涟漪与角标提示"
                      showIcons
                      mode={config.mode}
                      waveColor={waveColor}
                      sparkleColor={sparkleColor}
                      sparkleStrength={config.sparkleStrength}
                      distortionStrength={config.distortionStrength}
                      systemUiShape={config.systemUiShape}
                      speedMultiplier={config.speedMultiplier}
                      densityScale={config.densityScale}
                      accentHex={theme.primary}
                      onPrimaryHex={theme.onPrimary}
                    />
                  </div>
                </AospRippleSurface>

                <AospRippleSurface
                  role="button"
                  tabIndex={0}
                  onClick={() => setHapticsEnabled((v) => !v)}
                  mode={config.mode}
                  color={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  maskRadius={0}
                  className="px-5 py-4"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5 min-w-0">
                      <Volume2 className="h-5 w-5 text-slate-600 dark:text-slate-300 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                          触感与涟漪同步响应
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {hapticsEnabled ? '450ms 入场阶段跟随按压状态' : '仅视觉反馈'}
                        </div>
                      </div>
                    </div>
                    <AospExpressiveSwitch
                      checked={hapticsEnabled}
                      onChange={setHapticsEnabled}
                      ariaLabel="触感与涟漪同步响应"
                      showIcons
                      mode={config.mode}
                      waveColor={waveColor}
                      sparkleColor={sparkleColor}
                      sparkleStrength={config.sparkleStrength}
                      distortionStrength={config.distortionStrength}
                      systemUiShape={config.systemUiShape}
                      speedMultiplier={config.speedMultiplier}
                      densityScale={config.densityScale}
                      accentHex={theme.primary}
                      onPrimaryHex={theme.onPrimary}
                    />
                  </div>
                </AospRippleSurface>

                <AospRippleSurface
                  role="button"
                  tabIndex={0}
                  mode={config.mode}
                  color={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  maskRadius={0}
                  className="px-5 py-4"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5 min-w-0">
                      <Shield className="h-5 w-5 text-slate-600 dark:text-slate-300 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                          安全与隐私权限管理
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          支持高达 10 个并发 RippleAnimationSession 叠加渲染
                        </div>
                      </div>
                    </div>
                    <Sliders className="h-4 w-4 text-slate-400 shrink-0" />
                  </div>
                </AospRippleSurface>
              </div>
            </div>

            <AospRippleSurface
              role="button"
              tabIndex={0}
              mode={config.mode}
              color={waveColor}
              sparkleColor={sparkleColor}
              sparkleStrength={config.sparkleStrength}
              distortionStrength={config.distortionStrength}
              systemUiShape={config.systemUiShape}
              speedMultiplier={config.speedMultiplier}
              densityScale={config.densityScale}
              maskRadius={16}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs"
            >
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    SystemUI Media Surface · 点击卡片任意处
                  </div>
                  <div className="mt-1 font-display text-base font-semibold text-slate-900 dark:text-slate-100 truncate">
                    Material You Expressive Touch Surface
                  </div>
                  <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    Premultiplied SkBlendMode::kSrcOver · 60/120fps WebGL2
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 text-slate-700 dark:text-slate-200">
                  <span className="p-2 rounded-full">
                    <SkipBack className="h-4 w-4" />
                  </span>
                  <span
                    className="flex h-10 w-10 items-center justify-center rounded-2xl"
                    style={{ backgroundColor: theme.primary, color: theme.onPrimary }}
                  >
                    <Play className="h-4 w-4 ml-0.5" />
                  </span>
                  <span className="p-2 rounded-full">
                    <SkipForward className="h-4 w-4" />
                  </span>
                  <span className="p-2 rounded-full">
                    <MoreVertical className="h-4 w-4" />
                  </span>
                </div>
              </div>
            </AospRippleSurface>
          </div>
        </div>
      </section>
    );
  }
);
