"use client";
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Hand, Pause, Play, RotateCcw } from 'lucide-react';
import {
  buildM3Theme,
  hexToRgbaWave,
  hexWithAlpha,
  M3ThemeTokens,
  ThemeVariant,
} from '../../aosp/dynamicColor';
import {
  AOSP_MAX_RIPPLES,
  AOSP_SYSTEMUI_DURATION,
  AOSP_SYSTEMUI_DURATION_LEGACY,
  AospRippleEngineMode,
  FrameworkUniformSnapshot,
  RippleColorRGBA,
  RippleSession,
  SystemUiRippleShape,
  WebGL2RippleRenderer,
} from '../../aosp/RippleEngine';
import { AospExpressiveSlider } from './AospExpressiveSlider';

export interface ColorPreset {
  id: string;
  label: string;
  hex: string;
  isMonochrome?: boolean;
  lightWave: RippleColorRGBA;
  darkWave: RippleColorRGBA;
}

/** Palette id reserved for the accent extracted from wallpaper or custom color picker. */
export const AMBIENT_PRESET_ID = '__ambient';

export const COLOR_PRESETS: ColorPreset[] = [
  {
    id: 'indigo',
    label: 'Material Indigo',
    hex: '#4F46E5',
    lightWave: { r: 0.31, g: 0.275, b: 0.898, a: 0.24 },
    darkWave: { r: 0.506, g: 0.549, b: 0.973, a: 0.28 },
  },
  {
    id: 'teal',
    label: 'Dynamic Teal',
    hex: '#0D9488',
    lightWave: { r: 0.051, g: 0.58, b: 0.533, a: 0.24 },
    darkWave: { r: 0.176, g: 0.831, b: 0.749, a: 0.28 },
  },
  {
    id: 'rose',
    label: 'Pixel Coral',
    hex: '#E11D48',
    lightWave: { r: 0.882, g: 0.114, b: 0.282, a: 0.24 },
    darkWave: { r: 0.984, g: 0.443, b: 0.522, a: 0.28 },
  },
  {
    id: 'amber',
    label: 'Warm Amber',
    hex: '#D97706',
    lightWave: { r: 0.851, g: 0.467, b: 0.024, a: 0.24 },
    darkWave: { r: 0.984, g: 0.749, b: 0.141, a: 0.28 },
  },
  {
    id: 'neutral',
    label: 'AOSP System',
    hex: '#64748B',
    isMonochrome: true,
    lightWave: { r: 0.06, g: 0.09, b: 0.16, a: 0.18 },
    darkWave: { r: 1.0, g: 1.0, b: 1.0, a: 0.26 },
  },
];

export interface LabConfigState {
  mode: AospRippleEngineMode;
  presetId: string;
  themeVariant: ThemeVariant;
  /** Seed extracted from ambient wallpaper or picked manually. */
  customAccentHex?: string;
  customAccentLabel?: string;
  /**
   * 壁纸取色管线发布的种子候选（AmbientBackdrop：MCU QuantizerWsmeans + Score.java）。
   * 铁律四：其它需要种子输入的组件（如配色方案圆形预览）必须消费本字段，
   * 禁止另建平行演示输入。
   */
  wallpaperSeeds?: { name: string; hex: string; desc: string }[];
  waveAlpha: number;
  sparkleAlpha: number;
  sparkleStrength: number;
  distortionStrength: number;
  systemUiShape: SystemUiRippleShape;
  densityScale: number;
  speedMultiplier: number;
  /** SystemUI 模式效果时长。默认 3000ms = Android 17 DEFAULT_RIPPLE_EFFECT_DURATION。 */
  systemUiDurationMs: number;
  hasMask: boolean;
  maskRadius: number;
  autoRadius: boolean;
  manualRadius: number;
  showMathOverlay: boolean;
}

export function resolveSeedHex(config: LabConfigState): {
  hex: string;
  label: string;
  isMonochrome: boolean;
} {
  const found = COLOR_PRESETS.find((p) => p.id === config.presetId);
  if (found) {
    return { hex: found.hex, label: found.label, isMonochrome: Boolean(found.isMonochrome) };
  }
  if (config.customAccentHex) {
    return {
      hex: config.customAccentHex,
      label: config.customAccentLabel ?? 'Ambient Theme',
      isMonochrome: false,
    };
  }
  return { hex: COLOR_PRESETS[0].hex, label: COLOR_PRESETS[0].label, isMonochrome: false };
}

export function resolveTheme(config: LabConfigState, isDark: boolean): M3ThemeTokens {
  const { hex, isMonochrome } = resolveSeedHex(config);
  return buildM3Theme(hex, config.themeVariant ?? 'tonal_spot', isDark, { isMonochrome });
}

export function resolveAccent(config: LabConfigState): ColorPreset {
  const seed = resolveSeedHex(config);
  const lightTheme = buildM3Theme(seed.hex, config.themeVariant ?? 'tonal_spot', false, {
    isMonochrome: seed.isMonochrome,
  });
  const darkTheme = buildM3Theme(seed.hex, config.themeVariant ?? 'tonal_spot', true, {
    isMonochrome: seed.isMonochrome,
  });
  return {
    id: config.presetId === AMBIENT_PRESET_ID ? AMBIENT_PRESET_ID : seed.label,
    label: seed.label,
    hex: lightTheme.primary,
    isMonochrome: seed.isMonochrome,
    lightWave: hexToRgbaWave(lightTheme.primary, 0.24),
    darkWave: hexToRgbaWave(darkTheme.primary, 0.28),
  };
}

interface InteractiveLabProps {
  isDark: boolean;
  config: LabConfigState;
  theme?: M3ThemeTokens;
  onConfigChange: React.Dispatch<React.SetStateAction<LabConfigState>>;
  onTelemetryUpdate: (snapshot: FrameworkUniformSnapshot | null) => void;
}

export const DEFAULT_LAB_CONFIG: LabConfigState = {
  mode: 'framework',
  presetId: 'indigo',
  themeVariant: 'tonal_spot',
  waveAlpha: 0.26,
  sparkleAlpha: 0.553, // AOSP DEFAULT_EFFECT_COLOR 0x8d / 255
  sparkleStrength: 0.3, // AOSP SystemUI RIPPLE_SPARKLE_STRENGTH
  distortionStrength: 1.0,
  systemUiShape: 'circle',
  densityScale: 2.1, // AOSP RippleShader.java densityScale = 2.1f
  speedMultiplier: 1.0,
  systemUiDurationMs: AOSP_SYSTEMUI_DURATION, // Android 17 (android-17.0.0_r1) = 3000ms
  hasMask: true,
  maskRadius: 24,
  autoRadius: true,
  manualRadius: 220,
  showMathOverlay: true,
  wallpaperSeeds: undefined,
};

export const InteractiveLab: React.FC<InteractiveLabProps> = ({
  isDark,
  config,
  theme: themeProp,
  onConfigChange,
  onTelemetryUpdate,
}) => {
  const theme = themeProp ?? resolveTheme(config, isDark);
  const seedInfo = resolveSeedHex(config);

  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<WebGL2RippleRenderer | null>(null);
  const sessionsRef = useRef<RippleSession[]>([]);
  /** 第 23 轮修复：按 pointerId 记账的舞台按压 session（多指/快速连点各自独立释放） */
  const pointerSessionsRef = useRef<Map<number, RippleSession>>(new Map());
  /** 第 23 轮修复：按 session id 记账的演示释放定时器（旧实现单槽 demoTimerRef，
   *  快速连点“触发点击/长按”会 clearTimeout 掉上一个 session 的释放定时器，
   *  导致它永远停留在 HOLDING——framework 模式下填充层（底色）永久铺在舞台底部 */
  const demoTimersRef = useRef<Map<number, number>>(new Map());
  const nextIdRef = useRef(1);
  const rafRef = useRef<number | null>(null);
  const onTelemetryUpdateRef = useRef(onTelemetryUpdate);
  const configRef = useRef(config);
  const isDarkRef = useRef(isDark);
  useEffect(() => {
    onTelemetryUpdateRef.current = onTelemetryUpdate;
    configRef.current = config;
    isDarkRef.current = isDark;
  });

  const [webglSupported, setWebglSupported] = useState(true);
  const [telemetry, setTelemetry] = useState<FrameworkUniformSnapshot | null>(null);
  const [activeCount, setActiveCount] = useState(0);
  const [isHoldingDemo, setIsHoldingDemo] = useState(false);
  const [stageSize, setStageSize] = useState<{ w: number; h: number } | null>(null);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const update = () => {
      const r = stage.getBoundingClientRect();
      setStageSize({ w: r.width, h: r.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(stage);
    return () => ro.disconnect();
  }, []);

  const getActiveWaveColor = useCallback((): RippleColorRGBA => {
    const c = configRef.current;
    const activeTheme = resolveTheme(c, isDarkRef.current);
    return hexToRgbaWave(activeTheme.primary, c.waveAlpha);
  }, []);

  // render 期从 props 直接推导，避免在渲染中访问 ref（react-hooks/refs）
  const renderTheme = themeProp ?? resolveTheme(config, isDark);
  const renderWaveColor = hexToRgbaWave(renderTheme.primary, config.waveAlpha);

  const renderFrameRef = useRef<() => void>(() => {});

  const renderFrame = useCallback(() => {
    const stage = stageRef.current;
    const renderer = rendererRef.current;
    if (!stage || !renderer) {
      rafRef.current = null;
      return;
    }

    const rect = stage.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    const now = performance.now();
    const sessions = sessionsRef.current;

    // 第 23 轮防漏保险：任何 HOLDING 超过 15s 的 session（无论何种未来泄漏路径）
    // 强制释放——AOSP 语义里 hold 只应持续到用户抬手，演示最长 1.2s。
    for (const s of sessions) {
      if (s.isHolding && now - s.startTimeMs > 15000) {
        s.release(now);
      }
    }

    renderer.renderSessions(sessions, rect.width, rect.height, dpr, now);

    const alive = sessions.filter((s) => !s.finished);
    // 修复报告缺陷 #8：会话收尾当帧同步输出最终快照，避免遥测滞后一帧
    const finishedLast =
      alive.length === 0 && sessions.length > 0
        ? sessions[sessions.length - 1]
        : null;
    sessionsRef.current = alive;
    setActiveCount(alive.length);

    if (alive.length > 0) {
      const latest = alive[alive.length - 1];
      const snap = latest.getTelemetry(now);
      setTelemetry(snap);
      onTelemetryUpdateRef.current(snap);
      rafRef.current = requestAnimationFrame(() => renderFrameRef.current());
    } else if (finishedLast) {
      const snap = finishedLast.getTelemetry(now);
      setTelemetry(snap);
      onTelemetryUpdateRef.current(snap);
      rafRef.current = null;
    } else {
      setTelemetry(null);
      onTelemetryUpdateRef.current(null);
      rafRef.current = null;
    }
  }, []);

  useEffect(() => {
    renderFrameRef.current = renderFrame;
  }, [renderFrame]);

  const ensureLoop = useCallback(() => {
    if (rafRef.current === null) {
      rafRef.current = requestAnimationFrame(() => renderFrameRef.current());
    }
  }, []);

  const spawnRippleAt = useCallback(
    (xCss: number, yCss: number, holdMs?: number) => {
      const stage = stageRef.current;
      if (!stage) return;
      const rect = stage.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const c = configRef.current;

      if (sessionsRef.current.length >= AOSP_MAX_RIPPLES) {
        const evicted = sessionsRef.current.shift();
        // 第 23 轮：被挤出的 session 若还有待触发的释放定时器，一并清账
        if (evicted) {
          const pending = demoTimersRef.current.get(evicted.id);
          if (pending !== undefined) {
            window.clearTimeout(pending);
            demoTimersRef.current.delete(evicted.id);
          }
        }
      }

      const session = new RippleSession(
        nextIdRef.current++,
        {
          mode: c.mode,
          touchX: xCss,
          touchY: yCss,
          originX: rect.width * 0.5,
          originY: rect.height * 0.5,
          width: rect.width,
          height: rect.height,
          dpr,
          maxRadiusOverride: c.autoRadius ? null : c.manualRadius,
          color: getActiveWaveColor(),
          sparkleColor: { r: 1, g: 1, b: 1, a: c.sparkleAlpha },
          sparkleStrength: c.sparkleStrength,
          distortionStrength: c.distortionStrength,
          systemUiShape: c.systemUiShape,
          hasMask: c.hasMask,
          maskRadius: c.maskRadius,
          densityScale: c.densityScale,
          speedMultiplier: c.speedMultiplier,
          durationMs: c.systemUiDurationMs,
        },
        performance.now()
      );

      sessionsRef.current.push(session);
      ensureLoop();

      if (typeof holdMs === 'number') {
        // 第 23 轮：释放定时器按 session 各自记账（旧单槽实现会被下一次点击
        // clearTimeout，前一个 session 永不释放 → 底色残留）。同 session 重入
        // （理论不发生）只重置自己的定时器，不影响其他在途 session。
        const existing = demoTimersRef.current.get(session.id);
        if (existing !== undefined) window.clearTimeout(existing);
        const timer = window.setTimeout(() => {
          demoTimersRef.current.delete(session.id);
          session.release(performance.now());
          if (demoTimersRef.current.size === 0) {
            setIsHoldingDemo(false);
          }
          ensureLoop();
        }, holdMs);
        demoTimersRef.current.set(session.id, timer);
      }

      return session;
    },
    [ensureLoop, getActiveWaveColor]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const renderer = new WebGL2RippleRenderer(canvas);
    rendererRef.current = renderer;
    setWebglSupported(renderer.isSupported());

    const timer = window.setTimeout(() => {
      const stage = stageRef.current;
      if (stage) {
        const rect = stage.getBoundingClientRect();
        spawnRippleAt(rect.width * 0.38, rect.height * 0.45, 220);
      }
    }, 240);

    return () => {
      window.clearTimeout(timer);
      // 第 23 轮：卸载时清空全部演示定时器，避免卸载后 setState / 释放已死 session
      demoTimersRef.current.forEach((t) => window.clearTimeout(t));
      demoTimersRef.current.clear();
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      renderer.dispose();
    };
  }, [spawnRippleAt]);

  useEffect(() => {
    for (const s of sessionsRef.current) {
      s.updateConfig({
        color: getActiveWaveColor(),
        sparkleColor: { r: 1, g: 1, b: 1, a: config.sparkleAlpha },
        sparkleStrength: config.sparkleStrength,
        distortionStrength: config.distortionStrength,
        systemUiShape: config.systemUiShape,
        hasMask: config.hasMask,
        maskRadius: config.maskRadius,
        maxRadiusOverride: config.autoRadius ? null : config.manualRadius,
        densityScale: config.densityScale,
        speedMultiplier: config.speedMultiplier,
        durationMs: config.systemUiDurationMs,
      });
    }
  }, [config, isDark, getActiveWaveColor]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    const session = spawnRippleAt(e.clientX - rect.left, e.clientY - rect.top);
    if (session) {
      // 第 23 轮：多指/快速连点各 pointer 独立记账，抬手只释放自己的 session
      pointerSessionsRef.current.set(e.pointerId, session);
    }
  };

  const handlePointerRelease = (e?: React.PointerEvent<HTMLDivElement>) => {
    // 第 23 轮：只释放触发事件的 pointer 自己的 session（旧实现只释放最后一个，
    // 多指场景下先前 pointer 的 session 泄漏为永久底色）；pointerleave 时
    // 未带事件的路径释放全部在按 session（对应官方 md-ripple "移出即释放"语义）。
    if (e && pointerSessionsRef.current.size > 0) {
      const own = pointerSessionsRef.current.get(e.pointerId);
      if (own) {
        own.release(performance.now());
        pointerSessionsRef.current.delete(e.pointerId);
        return;
      }
    }
    if (!e || pointerSessionsRef.current.size === 0) {
      pointerSessionsRef.current.forEach((s) => s.release(performance.now()));
      pointerSessionsRef.current.clear();
    }
  };

  const triggerCenterTap = () => {
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    spawnRippleAt(rect.width * 0.32, rect.height * 0.4, 80);
  };

  const triggerLongHoldDemo = () => {
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    setIsHoldingDemo(true);
    spawnRippleAt(rect.width * 0.65, rect.height * 0.56, 1200);
  };

  const resetDefaults = () => {
    onConfigChange(DEFAULT_LAB_CONFIG);
  };

  const waveColor = renderWaveColor;
  const sparkleColor = { r: 1, g: 1, b: 1, a: config.sparkleAlpha };

  return (
    <section id="lab" className="scroll-mt-24 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
      {/* Left Interactive WebGL2 Stage */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        <div
          ref={stageRef}
          role="application"
          aria-label="AOSP Ripple Shader Interactive Canvas"
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerRelease}
          onPointerCancel={handlePointerRelease}
          onPointerLeave={handlePointerRelease}
          style={{
            borderRadius: config.hasMask ? `${config.maskRadius}px` : '0px',
          }}
          className={`relative min-h-[420px] lg:min-h-[480px] w-full select-none cursor-crosshair border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm transition-[border-radius] duration-200 ${
            config.hasMask ? 'overflow-hidden' : 'overflow-visible'
          }`}
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 opacity-40 dark:opacity-25"
            style={{
              backgroundImage:
                'radial-gradient(circle, rgba(100,116,139,0.28) 1px, transparent 1px)',
              backgroundSize: '24px 24px',
            }}
          />

          <div className="pointer-events-none relative z-10 flex h-full min-h-[420px] lg:min-h-[480px] flex-col justify-between p-6">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-center gap-2">
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  {config.mode === 'framework'
                    ? 'RippleDrawable · STYLE_PATTERNED'
                    : 'SystemUI · SurfaceEffects RippleShader'}
                </span>
                <span aria-hidden="true">·</span>
                <span>WebGL2 GLSL ES 3.00</span>
              </div>
              <span className="font-mono tabular-nums">
                Active Sessions: {activeCount}/{AOSP_MAX_RIPPLES}
              </span>
            </div>

            <div className="mx-auto my-auto max-w-md text-center">
              <div
                className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200/80 dark:border-slate-700"
                style={{
                  backgroundColor: theme.primaryContainer,
                  color: theme.onPrimaryContainer,
                }}
              >
                <Hand className="h-5 w-5" />
              </div>
              <p className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                点击或长按画布任意位置触发 AOSP 涟漪
              </p>
              <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">
                {config.mode === 'framework'
                  ? '短按触发 450ms 入场 + 375ms 退场；长按保持 progress=0.5 观察长达 7000ms 噪声闪烁过程'
                  : `SystemUI 模式：单段 STANDARD 缓动全程 ${config.systemUiDurationMs}ms（Android 17 默认），可在右侧切换旧版 750ms 对照`}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              <span>
                {config.mode === 'framework'
                  ? 'ENTER 450ms (0.4, 0, 0.2, 1) · EXIT 375ms (Linear)'
                  : `STANDARD (0.2, 0, 0, 1) · ${config.systemUiDurationMs} ms · Shape: ${config.systemUiShape.toUpperCase()}`}
              </span>
              <span>
                {config.hasMask
                  ? `Mask: RoundedRect(${config.maskRadius}px)`
                  : 'Mask: Unbounded (in_hasMask = 0)'}
              </span>
            </div>
          </div>

          <canvas
            ref={canvasRef}
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 z-20 h-full w-full"
          />

          {config.showMathOverlay && telemetry && stageSize && (
            <svg
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 z-30 h-full w-full"
              viewBox={`0 0 ${stageSize.w} ${stageSize.h}`}
            >
              <circle
                cx={stageSize.w * 0.5}
                cy={stageSize.h * 0.5}
                r={3.5}
                fill="none"
                stroke="#64748b"
                strokeWidth={1.25}
              />
              {config.mode === 'framework' && (
                <>
                  <line
                    x1={telemetry.centerX}
                    y1={telemetry.centerY}
                    x2={stageSize.w * 0.5}
                    y2={stageSize.h * 0.5}
                    stroke={theme.primary}
                    strokeDasharray="4 4"
                    strokeWidth={1}
                    opacity={0.75}
                  />
                  <circle
                    cx={telemetry.centerX}
                    cy={telemetry.centerY}
                    r={4}
                    fill={theme.primary}
                  />
                  <circle
                    cx={telemetry.centerX}
                    cy={telemetry.centerY}
                    r={
                      (telemetry.maxRadius * telemetry.scaleIn) /
                      Math.min(window.devicePixelRatio || 1, 2.5)
                    }
                    fill="none"
                    stroke={theme.primary}
                    strokeWidth={1}
                    strokeDasharray="6 4"
                    opacity={0.55}
                  />
                </>
              )}
            </svg>
          )}

          {!webglSupported && (
            <div className="absolute inset-0 z-40 flex items-center justify-center bg-white/95 dark:bg-slate-900/95 p-6 text-center">
              <p className="text-sm text-rose-600 dark:text-rose-400">
                当前浏览器环境不支持 WebGL2，无法运行 AOSP GLSL ES 3.00 着色器。
              </p>
            </div>
          )}
        </div>

        {/* Live Uniform Telemetry Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 text-xs">
          <div>
            <div className="text-slate-500 dark:text-slate-400">State</div>
            <div className="mt-0.5 font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {telemetry ? telemetry.stage : 'IDLE'}
            </div>
          </div>
          <div>
            <div className="text-slate-500 dark:text-slate-400">in_progress</div>
            <div
              className="mt-0.5 font-mono font-semibold tabular-nums"
              style={{ color: theme.primary }}
            >
              {telemetry ? telemetry.progress.toFixed(3) : '0.000'}
            </div>
          </div>
          <div>
            <div className="text-slate-500 dark:text-slate-400">in_noisePhase</div>
            <div className="mt-0.5 font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {telemetry ? telemetry.inNoisePhase.toFixed(4) : '0.0000'}
            </div>
          </div>
          <div>
            <div className="text-slate-500 dark:text-slate-400">Sparkle Alpha</div>
            <div className="mt-0.5 font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {telemetry
                ? Math.min(telemetry.fadeIn, 1 - telemetry.fadeOutNoise).toFixed(3)
                : '0.000'}
            </div>
          </div>
          <div>
            <div className="text-slate-500 dark:text-slate-400">Elapsed</div>
            <div className="mt-0.5 font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {telemetry ? `${Math.round(telemetry.elapsedMs)} ms` : '0 ms'}
            </div>
          </div>
        </div>
      </div>

      {/* Right Parameter & Shader Deck */}
      <div className="lg:col-span-4 flex flex-col justify-between rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
        <div className="space-y-5">
          {/* Engine Mode Segmented Switch */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-2">
              AOSP 着色器引擎
            </label>
            <div className="grid grid-cols-2 gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
              <button
                type="button"
                onClick={() => onConfigChange((prev) => ({ ...prev, mode: 'framework' }))}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate ${
                  config.mode === 'framework'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Framework Java
              </button>
              <button
                type="button"
                onClick={() => onConfigChange((prev) => ({ ...prev, mode: 'systemui' }))}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate ${
                  config.mode === 'systemui'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                SystemUI Kt
              </button>
            </div>
          </div>

          {/* Material You Dynamic Color Presets + Scheme Variant (Monet HCT) */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
                Material You 动态种子色
              </span>
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400 truncate">
                {seedInfo.label} · {theme.primary}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              {config.customAccentHex && (
                <button
                  type="button"
                  aria-label={config.customAccentLabel ?? 'Ambient Theme'}
                  title={`${config.customAccentLabel ?? '自定义种子色'} (${config.customAccentHex})`}
                  onClick={() =>
                    onConfigChange((prev) => ({ ...prev, presetId: AMBIENT_PRESET_ID }))
                  }
                  className={`h-8 w-8 rounded-full transition-transform focus-visible:outline-2 focus-visible:outline-offset-2 ${
                    config.presetId === AMBIENT_PRESET_ID
                      ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-white dark:ring-offset-slate-900 scale-105'
                      : 'hover:scale-105'
                  }`}
                  style={{
                    backgroundColor: config.customAccentHex,
                    outlineColor: theme.primary,
                  }}
                />
              )}

              {COLOR_PRESETS.map((preset) => {
                const selected = config.presetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    aria-label={preset.label}
                    title={`${preset.label} (${preset.hex})`}
                    onClick={() =>
                      onConfigChange((prev) => ({ ...prev, presetId: preset.id }))
                    }
                    className={`h-8 w-8 rounded-full transition-transform focus-visible:outline-2 focus-visible:outline-offset-2 ${
                      selected
                        ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-white dark:ring-offset-slate-900 scale-105'
                        : 'hover:scale-105'
                    }`}
                    style={{
                      backgroundColor: preset.hex,
                      outlineColor: theme.primary,
                    }}
                  />
                );
              })}

              <label
                title="自定义任意种子色（实时通过 Monet HCT 映射为全套 M3 色彩角色）"
                className="relative inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-full border border-slate-200 dark:border-slate-700 px-2.5 text-[11px] font-mono text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <span
                  className="h-3.5 w-3.5 rounded-full border border-black/10 dark:border-white/20"
                  style={{ backgroundColor: theme.seedHex }}
                />
                <span>取色</span>
                <input
                  type="color"
                  aria-label="自定义种子色"
                  value={theme.seedHex}
                  onChange={(e) => {
                    const hex = e.target.value.toUpperCase();
                    onConfigChange((prev) => ({
                      ...prev,
                      presetId: AMBIENT_PRESET_ID,
                      customAccentHex: hex,
                      customAccentLabel: `Seed ${hex}`,
                    }));
                  }}
                  className="sr-only"
                />
              </label>
            </div>

            {/* DynamicScheme Variant Selector —— 第 25 轮扩为 ColorProvider.kt styleList
                全集四风格（TONAL_SPOT/SPRITZ/VIBRANT/EXPRESSIVE），CoreSpec 中性色 n1/n2
                一并按 AOSP-13 ColorScheme.kt L136-186 接入 buildM3Theme */}
            <div className="grid grid-cols-2 gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
              {([
                { v: 'tonal_spot', label: 'TonalSpot 标准' },
                { v: 'spritz', label: 'Spritz 中性' },
                { v: 'vibrant', label: 'Vibrant 鲜艳' },
                { v: 'expressive', label: 'Expressive 炫彩' },
              ] as const).map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  onClick={() => onConfigChange((prev) => ({ ...prev, themeVariant: opt.v }))}
                  className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    config.themeVariant === opt.v
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {config.mode === 'systemui' && (
            <div className="space-y-4">
              <div>
                <span className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-2">
                  效果时长 (DEFAULT_RIPPLE_EFFECT_DURATION)
                </span>
                <div className="grid grid-cols-2 gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
                  <button
                    type="button"
                    onClick={() =>
                      onConfigChange((prev) => ({
                        ...prev,
                        systemUiDurationMs: AOSP_SYSTEMUI_DURATION,
                      }))
                    }
                    className={`px-2 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      config.systemUiDurationMs === AOSP_SYSTEMUI_DURATION
                        ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Android 17 · 3000ms
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onConfigChange((prev) => ({
                        ...prev,
                        systemUiDurationMs: AOSP_SYSTEMUI_DURATION_LEGACY,
                      }))
                    }
                    className={`px-2 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      config.systemUiDurationMs === AOSP_SYSTEMUI_DURATION_LEGACY
                        ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    旧版 A13/14 · 750ms
                  </button>
                </div>
                <p className="mt-1.5 text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                  Android 17（android-17.0.0_r1）SystemUI 默认 3000ms；750ms 为 Android
                  13/14 旧值，仅作版本差异对照。
                </p>
              </div>
              <div>
                <span className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-2">
                  SDF 几何形态 (RippleShape)
                </span>
              <div className="grid grid-cols-3 gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
                {(['circle', 'rounded_box', 'ellipse'] as SystemUiRippleShape[]).map(
                  (shape) => (
                    <button
                      key={shape}
                      type="button"
                      onClick={() =>
                        onConfigChange((prev) => ({ ...prev, systemUiShape: shape }))
                      }
                      className={`px-2 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        config.systemUiShape === shape
                          ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {shape === 'circle'
                        ? 'Circle'
                        : shape === 'rounded_box'
                          ? 'Rounded'
                          : 'Ellipse'}
                    </button>
                  )
                )}
              </div>
                </div>
              </div>
          )}

          {/* Sliders */}
          <div className="space-y-3">
            <AospExpressiveSlider
              size="xs"
              compact
              mode={config.mode}
              waveColor={waveColor}
              sparkleColor={sparkleColor}
              sparkleStrength={config.sparkleStrength}
              distortionStrength={config.distortionStrength}
              systemUiShape={config.systemUiShape}
              speedMultiplier={config.speedMultiplier}
              densityScale={config.densityScale}
              accentHex={theme.primary}
              theme={theme}
              label="时间倍率 (Playback Speed)"
              value={config.speedMultiplier}
              min={0.15}
              max={2.0}
              step={0.05}
              formatValue={(v) => `${v.toFixed(2)}×`}
              onChange={(v) =>
                onConfigChange((prev) => ({ ...prev, speedMultiplier: v }))
              }
            />

            <AospExpressiveSlider
              size="xs"
              compact
              mode={config.mode}
              waveColor={waveColor}
              sparkleColor={sparkleColor}
              sparkleStrength={config.sparkleStrength}
              distortionStrength={config.distortionStrength}
              systemUiShape={config.systemUiShape}
              speedMultiplier={config.speedMultiplier}
              densityScale={config.densityScale}
              accentHex={theme.primary}
              theme={theme}
              label="波纹不透明度 (in_color.a)"
              value={config.waveAlpha}
              min={0.05}
              max={0.65}
              step={0.01}
              formatValue={(v) => v.toFixed(2)}
              onChange={(v) =>
                onConfigChange((prev) => ({ ...prev, waveAlpha: v }))
              }
            />

            {config.mode === 'framework' ? (
              <AospExpressiveSlider
                size="xs"
                compact
                mode={config.mode}
                waveColor={waveColor}
                sparkleColor={sparkleColor}
                sparkleStrength={config.sparkleStrength}
                distortionStrength={config.distortionStrength}
                systemUiShape={config.systemUiShape}
                speedMultiplier={config.speedMultiplier}
                densityScale={config.densityScale}
                accentHex={theme.primary}
                theme={theme}
                label="星斑透明度 (in_sparkleColor.a)"
                value={config.sparkleAlpha}
                min={0}
                max={1}
                step={0.01}
                formatValue={(v) => v.toFixed(3)}
                onChange={(v) =>
                  onConfigChange((prev) => ({ ...prev, sparkleAlpha: v }))
                }
              />
            ) : (
              <>
                <AospExpressiveSlider
                  size="xs"
                  compact
                  mode={config.mode}
                  waveColor={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  accentHex={theme.primary}
                  theme={theme}
                  label="星斑强度 (in_sparkle_strength)"
                  value={config.sparkleStrength}
                  min={0}
                  max={1}
                  step={0.02}
                  formatValue={(v) => v.toFixed(2)}
                  onChange={(v) =>
                    onConfigChange((prev) => ({ ...prev, sparkleStrength: v }))
                  }
                />
                <AospExpressiveSlider
                  size="xs"
                  compact
                  mode={config.mode}
                  waveColor={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  accentHex={theme.primary}
                  theme={theme}
                  label="边缘扰动 (distortionStrength)"
                  value={config.distortionStrength}
                  min={0}
                  max={1.5}
                  step={0.05}
                  formatValue={(v) => v.toFixed(2)}
                  onChange={(v) =>
                    onConfigChange((prev) => ({ ...prev, distortionStrength: v }))
                  }
                />
              </>
            )}

            <AospExpressiveSlider
              size="xs"
              compact
              mode={config.mode}
              waveColor={waveColor}
              sparkleColor={sparkleColor}
              sparkleStrength={config.sparkleStrength}
              distortionStrength={config.distortionStrength}
              systemUiShape={config.systemUiShape}
              speedMultiplier={config.speedMultiplier}
              densityScale={config.densityScale}
              accentHex={theme.primary}
              theme={theme}
              label="噪声颗粒尺度 (densityScale)"
              value={config.densityScale}
              min={1.0}
              max={6.0}
              step={0.1}
              formatValue={(v) => `${v.toFixed(1)} px`}
              onChange={(v) =>
                onConfigChange((prev) => ({ ...prev, densityScale: v }))
              }
            />

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-600 dark:text-slate-300">
                  扩散半径 (computeRadius)
                </span>
                <label className="inline-flex items-center gap-1.5 text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.autoRadius}
                    onChange={(e) =>
                      onConfigChange((prev) => ({
                        ...prev,
                        autoRadius: e.target.checked,
                      }))
                    }
                    style={{ accentColor: theme.primary }}
                    className="rounded border-slate-300"
                  />
                  <span className="font-mono">
                    {config.autoRadius ? 'Auto' : `${config.manualRadius}px`}
                  </span>
                </label>
              </div>
              {!config.autoRadius && (
                <AospExpressiveSlider
                  size="xs"
                  compact
                  mode={config.mode}
                  waveColor={waveColor}
                  sparkleColor={sparkleColor}
                  sparkleStrength={config.sparkleStrength}
                  distortionStrength={config.distortionStrength}
                  systemUiShape={config.systemUiShape}
                  speedMultiplier={config.speedMultiplier}
                  densityScale={config.densityScale}
                  accentHex={theme.primary}
                  theme={theme}
                  label="手动最大半径 (maxRadius)"
                  value={config.manualRadius}
                  min={80}
                  max={420}
                  step={10}
                  formatValue={(v) => `${Math.round(v)} px`}
                  onChange={(v) =>
                    onConfigChange((prev) => ({ ...prev, manualRadius: v }))
                  }
                />
              )}
            </div>
          </div>

          {/* Mask & Overlay Toggles */}
          <div className="flex items-center justify-between pt-1 text-xs">
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={config.hasMask}
                onChange={(e) =>
                  onConfigChange((prev) => ({ ...prev, hasMask: e.target.checked }))
                }
                style={{ accentColor: theme.primary }}
                className="rounded border-slate-300"
              />
              <span>启用边界遮罩 (in_hasMask)</span>
            </label>
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={config.showMathOverlay}
                onChange={(e) =>
                  onConfigChange((prev) => ({
                    ...prev,
                    showMathOverlay: e.target.checked,
                  }))
                }
                style={{ accentColor: theme.primary }}
                className="rounded border-slate-300"
              />
              <span>几何辅助线</span>
            </label>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={triggerCenterTap}
            style={{
              backgroundColor: theme.primary,
              color: theme.onPrimary,
            }}
            className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium hover:opacity-90 transition-opacity whitespace-nowrap"
          >
            <Play className="h-3.5 w-3.5" />
            触发点击
          </button>
          <button
            type="button"
            onClick={triggerLongHoldDemo}
            disabled={isHoldingDemo}
            style={
              isHoldingDemo
                ? { borderColor: hexWithAlpha(theme.primary, 0.5) }
                : undefined
            }
            className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-100 transition-colors whitespace-nowrap disabled:opacity-60"
          >
            <Pause className="h-3.5 w-3.5" />
            {isHoldingDemo ? '长按中...' : '长按 1.2s'}
          </button>
          <button
            type="button"
            onClick={resetDefaults}
            aria-label="重置 AOSP 默认参数"
            className="inline-flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </section>
  );
};
