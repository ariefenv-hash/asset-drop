"use client";
import React, { useMemo, useState } from 'react';
import { RotateCcw, Type } from 'lucide-react';
import { M3ThemeTokens } from '../../aosp/dynamicColor';
import { AospExpressiveSlider } from './AospExpressiveSlider';

interface VariableFontPlaygroundProps {
  theme: M3ThemeTokens;
}

const AXIS_LIMITS = {
  wght: { min: 1, max: 1000, step: 1, def: 400 },
  opsz: { min: 1, max: 144, step: 1, def: 18 },
  wdth: { min: 25, max: 151, step: 1, def: 100 },
  ROND: { min: 0, max: 100, step: 1, def: 0 },
  slnt: { min: -10, max: 0, step: 1, def: 0 },
};

type AxesState = {
  wght: number;
  opsz: number;
  wdth: number;
  ROND: number;
  slnt: number;
};

const DEFAULT_AXES: AxesState = {
  wght: AXIS_LIMITS.wght.def,
  opsz: AXIS_LIMITS.opsz.def,
  wdth: AXIS_LIMITS.wdth.def,
  ROND: AXIS_LIMITS.ROND.def,
  slnt: AXIS_LIMITS.slnt.def,
};

const AXIS_META: { key: keyof AxesState; label: string; note: string }[] = [
  { key: 'wght', label: '字重 wght', note: '1–1000，Hairline → Black' },
  { key: 'opsz', label: '视觉字号 opsz', note: '1–144，Caption → Display' },
  { key: 'wdth', label: '字宽 wdth', note: '25–151，Condensed → Wide' },
  { key: 'ROND', label: '圆角 ROND', note: '0–100，直角 → 圆角化字形' },
  { key: 'slnt', label: '倾斜 slnt', note: '-10–0，罗马体 → 斜体' },
];

const AXIS_PRESETS: { label: string; axes: AxesState }[] = [
  { label: 'Regular', axes: { ...DEFAULT_AXES } },
  { label: 'Hairline', axes: { ...DEFAULT_AXES, wght: 1 } },
  { label: 'Black', axes: { ...DEFAULT_AXES, wght: 1000 } },
  { label: 'Display', axes: { ...DEFAULT_AXES, wght: 640, opsz: 144 } },
  { label: 'Caption', axes: { ...DEFAULT_AXES, wght: 430, opsz: 1 } },
  { label: 'Condensed', axes: { ...DEFAULT_AXES, wght: 560, wdth: 62 } },
  { label: 'Wide', axes: { ...DEFAULT_AXES, wght: 480, wdth: 151 } },
  { label: 'Rounded', axes: { ...DEFAULT_AXES, wght: 540, ROND: 100 } },
  { label: 'Slanted', axes: { ...DEFAULT_AXES, wght: 500, slnt: -10 } },
];

export const VariableFontPlayground: React.FC<VariableFontPlaygroundProps> = ({
  theme,
}) => {
  const [axes, setAxes] = useState<AxesState>(DEFAULT_AXES);
  const [fontSize, setFontSize] = useState(56);
  const [text, setText] = useState('M3 Expressive 波形');

  const variationCss = useMemo(
    () =>
      `'wght' ${axes.wght}, 'opsz' ${axes.opsz}, 'wdth' ${axes.wdth}, 'ROND' ${axes.ROND}, 'slnt' ${axes.slnt}`,
    [axes]
  );

  const setAxis = (key: keyof AxesState, value: number) =>
    setAxes((prev) => ({ ...prev, [key]: value }));

  const resetAll = () => {
    setAxes(DEFAULT_AXES);
    setFontSize(56);
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            <Type className="h-4 w-4" style={{ color: theme.primary }} />
            Google Sans Flex 可变字体实验室（5 轴 · OFL TTF）
          </h3>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            官方 <code className="font-mono break-all">GoogleSansFlex[ROND,opsz,slnt,wdth,wght].ttf</code>{' '}
            已内置于 <code className="font-mono">/fonts/</code>，通过{' '}
            <code className="font-mono">font-variation-settings</code> 实时驱动全部轴。
          </p>
        </div>
        <button
          type="button"
          onClick={resetAll}
          className="shrink-0 inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          复位
        </button>
      </div>

      <div className="rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 px-6 py-8 overflow-hidden">
        <div
          contentEditable
          suppressContentEditableWarning
          spellCheck={false}
          className="outline-none break-words leading-tight text-slate-900 dark:text-white min-h-[1.3em]"
          style={{
            fontFamily: "'Google Sans Flex', sans-serif",
            fontSize: `${fontSize}px`,
            fontVariationSettings: variationCss,
            fontOpticalSizing: 'auto',
          }}
        >
          {text}
        </div>
        <div className="mt-4">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="输入预览文本"
            style={{ outlineColor: theme.primary }}
            className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-2"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2.5">
        {AXIS_META.map(({ key, label, note }) => (
          <AospExpressiveSlider
            key={key}
            label={label}
            value={axes[key]}
            min={AXIS_LIMITS[key].min}
            max={AXIS_LIMITS[key].max}
            step={AXIS_LIMITS[key].step}
            size="xs"
            compact
            unit=""
            formatValue={(v) => `${Math.round(v)} · ${note.split('，')[0]}`}
            accentHex={theme.primary}
            theme={theme}
            onChange={(v) => setAxis(key, v)}
          />
        ))}
        <AospExpressiveSlider
          label="预览字号"
          value={fontSize}
          min={16}
          max={96}
          step={1}
          size="xs"
          compact
          unit="px"
          accentHex={theme.primary}
          theme={theme}
          onChange={setFontSize}
        />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {AXIS_PRESETS.map((p) => {
          const active = JSON.stringify(p.axes) === JSON.stringify(axes);
          return (
            <button
              key={p.label}
              type="button"
              onClick={() => setAxes(p.axes)}
              style={
                active
                  ? {
                      backgroundColor: theme.primary,
                      borderColor: theme.primary,
                      color: theme.onPrimary,
                    }
                  : undefined
              }
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                active
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {p.label}
            </button>
          );
        })}
      </div>

      <div className="rounded-lg bg-slate-950 dark:bg-slate-950/80 border border-slate-800 px-4 py-3 font-mono text-[11px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre">
        {`.g-sans-flex-demo {\n  font-variation-settings: ${variationCss};\n}`}
      </div>
    </div>
  );
};
