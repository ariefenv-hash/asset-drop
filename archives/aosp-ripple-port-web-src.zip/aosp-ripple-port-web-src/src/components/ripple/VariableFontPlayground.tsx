"use client";
/**
 * Google Sans Flex × 中文可变字体混搭实验室 · 第 20 条（用户方案整合）
 * ============================================================
 * 【用户方案 → 项目融合】用户提供的混排方案（HTML 实验室）原样整合：
 *  - 英文/数字：Google Sans Flex。本项目已内置本地 TTF（/fonts/GoogleSansFlex.ttf，
 *    google/fonts v26，OFL；@font-face 见 globals.css），与用户方案的
 *    Google Fonts CDN 是同一款字体——本地通道更稳，不再外链。
 *  - 中文可变字体：zeoseven fontsapi CDN（layout.tsx 引入，family 名与分片
 *    注册已实测核实）：
 *      414 WenYuan Rounded SC VF（471 分片，wght 100–900 可变）
 *      415 WenYuan Serif SC VF（411 分片）
 *      285 Noto Serif CJK（672 分片）
 *  - 混排机制：font-family 栈英文字体在前，汉字回落中文字体；font-weight
 *    同时驱动中英可变字重（两族 @font-face 均为 wght 全范围注册，联动成立）；
 *    font-variation-settings 仅写 Google Sans Flex 专属轴（ROND/wdth/slnt/opsz），
 *    中文字体无这些轴自动忽略 → 中英联动字重 + 英文独立造型。
 *  - 用户三预设原样保留：圆润未来 UI / 设计杂志混搭 / 高密度窄体海报；
 *    此前第 12 轮的英文单飞轴预设一并保留（历史工作不倒退）。
 * 【全局应用】"应用到全站"写 :root 的 --vf-cn / --vf-rond（globals.css 的
 *    --font-display / --font-sans 栈引用之），并 localStorage('aosp-vf-global')
 *    持久化，挂载时恢复；wght/wdth/opsz/slnt 不全局化（font-variation-settings
 *    会覆盖 font-weight，硬套全站会毁掉组件语义字重——取舍说明见 globals.css）。
 * 【滑块】全部 AospExpressiveSlider（带手柄；全站禁止默认圆点滑块）。
 * ============================================================
 */
import React, { useEffect, useMemo, useState } from 'react';
import { RotateCcw, Type } from '@/components/icons';
import { M3ThemeTokens } from '../../aosp/dynamicColor';
import { AospExpressiveSlider } from './AospExpressiveSlider';

/** 中文可变字体搭配（用户方案三字体 + "仅英文"对照项） */
const CN_FONTS: { label: string; family: string | null }[] = [
  { label: '文渊圆体 SC（圆润现代）', family: 'WenYuan Rounded SC VF' },
  { label: '文渊宋体 SC（衬线人文）', family: 'WenYuan Serif SC VF' },
  { label: '思源宋体 Variable（经典出版）', family: 'Noto Serif CJK' },
  { label: '不搭配中文（仅英文可变）', family: null },
];

const AXIS_LIMITS = {
  wght: { min: 1, max: 1000, step: 1, def: 400 },
  opsz: { min: 6, max: 144, step: 1, def: 36 },
  wdth: { min: 25, max: 151, step: 1, def: 100 },
  ROND: { min: 0, max: 100, step: 1, def: 100 },
  slnt: { min: -10, max: 0, step: 0.5, def: 0 },
} as const;

type AxesState = {
  wght: number;
  opsz: number;
  wdth: number;
  ROND: number;
  slnt: number;
};

const DEFAULT_AXES: AxesState = {
  wght: AXIS_LIMITS.wght.def,
  opsz: AXIS_LIMITS.opsz.def,
  wdth: AXIS_LIMITS.wdth.def,
  ROND: AXIS_LIMITS.ROND.def,
  slnt: AXIS_LIMITS.slnt.def,
};

const AXIS_META: { key: keyof AxesState; label: string; note: string }[] = [
  { key: 'wght', label: '中英联动字重 wght', note: '1–1000，中英 VF 同受 font-weight 驱动' },
  { key: 'ROND', label: '英文圆角 ROND', note: '0–100，直角 → 圆角化字形（GSF 专属）' },
  { key: 'wdth', label: '英文字宽 wdth', note: '25–151，Condensed → Wide（GSF 专属）' },
  { key: 'slnt', label: '英文倾斜 slnt', note: '-10–0，罗马体 → 斜体（GSF 专属）' },
  { key: 'opsz', label: '英文视觉尺寸 opsz', note: '6–144，Caption → Display（GSF 专属）' },
];

/** 用户方案三预设（混搭） */
const MIXED_PRESETS: { label: string; cn: string | null; axes: AxesState }[] = [
  {
    label: '预设 1 · 圆润未来 UI（GSF 圆角 + 文渊圆体）',
    cn: 'WenYuan Rounded SC VF',
    axes: { wght: 550, opsz: 36, wdth: 100, ROND: 100, slnt: 0 },
  },
  {
    label: '预设 2 · 设计杂志混搭（GSF 宽体 + 文渊宋体）',
    cn: 'WenYuan Serif SC VF',
    axes: { wght: 500, opsz: 72, wdth: 114, ROND: 0, slnt: 0 },
  },
  {
    label: '预设 3 · 高密度窄体海报（wdth 65 + 750 粗体）',
    cn: 'WenYuan Rounded SC VF',
    axes: { wght: 750, opsz: 60, wdth: 65, ROND: 20, slnt: -4 },
  },
];

/** 英文单飞轴预设（第 12 轮历史预设，保留） */
const ENGLISH_PRESETS: { label: string; axes: AxesState }[] = [
  { label: 'Regular', axes: { wght: 400, opsz: 18, wdth: 100, ROND: 0, slnt: 0 } },
  { label: 'Hairline', axes: { wght: 1, opsz: 18, wdth: 100, ROND: 0, slnt: 0 } },
  { label: 'Black', axes: { wght: 1000, opsz: 18, wdth: 100, ROND: 0, slnt: 0 } },
  { label: 'Display', axes: { wght: 640, opsz: 144, wdth: 100, ROND: 0, slnt: 0 } },
  { label: 'Caption', axes: { wght: 430, opsz: 6, wdth: 100, ROND: 0, slnt: 0 } },
  { label: 'Condensed', axes: { wght: 560, opsz: 18, wdth: 62, ROND: 0, slnt: 0 } },
  { label: 'Wide', axes: { wght: 480, opsz: 18, wdth: 151, ROND: 0, slnt: 0 } },
  { label: 'Rounded', axes: { wght: 540, opsz: 18, wdth: 100, ROND: 100, slnt: 0 } },
  { label: 'Slanted', axes: { wght: 500, opsz: 18, wdth: 100, ROND: 0, slnt: -10 } },
];

const VF_LS_KEY = 'aosp-vf-global';

const MIXED_BODY_TEXT =
  '在这段混排正文里，所有的英文单词如 Variable Fonts、版本号 Android 17 以及数字 1234567890，' +
  '都会自动使用 Google Sans Flex 渲染；而中文段落的呼吸感与笔画粗细，则由选定的中文可变字体无缝承接。';

interface VariableFontPlaygroundProps {
  theme: M3ThemeTokens;
}

export const VariableFontPlayground: React.FC<VariableFontPlaygroundProps> = ({
  theme,
}) => {
  const [cn, setCn] = useState<string | null>('WenYuan Rounded SC VF');
  const [axes, setAxes] = useState<AxesState>(DEFAULT_AXES);
  const [fontSize, setFontSize] = useState(56);
  const [text, setText] = useState('Hello 2026，探索 Material You 与东方字体的交融之美。');
  const [fontStatus, setFontStatus] = useState<'loading' | 'ready' | 'fail'>('loading');
  const [applied, setApplied] = useState<{ cn: string | null; rond: number } | null>(null);

  const variationCss = useMemo(
    () =>
      `'wdth' ${axes.wdth}, 'ROND' ${axes.ROND}, 'slnt' ${axes.slnt}, 'opsz' ${axes.opsz}`,
    [axes]
  );

  const familyCss = useMemo(
    () => (cn ? `'Google Sans Flex', '${cn}', sans-serif` : `'Google Sans Flex', sans-serif`),
    [cn]
  );

  /* 选中中文 VF 的分片加载探测（提示 CDN 可达性；仅状态提示，不阻塞交互） */
  useEffect(() => {
    if (!cn) {
      setFontStatus('ready');
      return;
    }
    let alive = true;
    setFontStatus('loading');
    document.fonts
      .load(`16px "${cn}"`, '字混排 Variable')
      .then((faces) => {
        if (alive) setFontStatus(faces.length > 0 ? 'ready' : 'fail');
      })
      .catch(() => {
        if (alive) setFontStatus('fail');
      });
    return () => {
      alive = false;
    };
  }, [cn]);

  /* 挂载恢复"应用到全站"的持久化选择 */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(VF_LS_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as { cn: string | null; rond: number };
      const root = document.documentElement;
      if (saved.cn) {
        root.style.setProperty('--vf-cn', `'${saved.cn}'`);
        setCn(saved.cn);
      }
      if (typeof saved.rond === 'number') {
        root.style.setProperty('--vf-rond', String(saved.rond));
        setAxes((p) => ({ ...p, ROND: saved.rond }));
      }
      setApplied({ cn: saved.cn ?? null, rond: saved.rond });
    } catch {
      /* 忽略损坏的持久化数据 */
    }
  }, []);

  const setAxis = (key: keyof AxesState, value: number) =>
    setAxes((prev) => ({ ...prev, [key]: value }));

  const resetAll = () => {
    setAxes({ ...DEFAULT_AXES, ROND: AXIS_LIMITS.ROND.def });
    setFontSize(56);
    setCn('WenYuan Rounded SC VF');
    setText('Hello 2026，探索 Material You 与东方字体的交融之美。');
  };

  /* 应用到全站：写 :root 变量 + localStorage；wght/wdth/opsz/slnt 不全局化 */
  const applyGlobal = () => {
    if (!cn) return;
    const root = document.documentElement;
    root.style.setProperty('--vf-cn', `'${cn}'`);
    root.style.setProperty('--vf-rond', String(axes.ROND));
    try {
      localStorage.setItem(VF_LS_KEY, JSON.stringify({ cn, rond: axes.ROND }));
    } catch {
      /* 无痕模式等存储不可用：本次会话内仍生效 */
    }
    setApplied({ cn, rond: axes.ROND });
  };

  const revertGlobal = () => {
    const root = document.documentElement;
    root.style.removeProperty('--vf-cn');
    root.style.removeProperty('--vf-rond');
    try {
      localStorage.removeItem(VF_LS_KEY);
    } catch {
      /* 同上 */
    }
    setApplied(null);
    setCn('WenYuan Rounded SC VF');
    setAxes((p) => ({ ...p, ROND: AXIS_LIMITS.ROND.def }));
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            <Type className="h-4 w-4" style={{ color: theme.primary }} />
            Google Sans Flex × 中文可变字体混搭实验室
          </h3>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            英文与数字由本地{' '}
            <code className="font-mono break-all">GoogleSansFlex[ROND,opsz,slnt,wdth,wght].ttf</code>{' '}
            渲染，汉字由下方选定的中文可变字体接管；<code className="font-mono">font-weight</code>{' '}
            同时驱动中英可变字重，<code className="font-mono">font-variation-settings</code>{' '}
            仅驱动 Google Sans Flex 专属轴（中文字体无此轴自动忽略）。
          </p>
        </div>
        <button
          type="button"
          onClick={resetAll}
          className="shrink-0 inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          复位
        </button>
      </div>

      {/* 中文字体搭配 + 全站应用 */}
      <div className="flex flex-wrap items-center gap-2">
        {CN_FONTS.map((f) => {
          const active = f.family === cn;
          return (
            <button
              key={f.label}
              type="button"
              onClick={() => setCn(f.family)}
              style={
                active
                  ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary }
                  : undefined
              }
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                active
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {f.label}
            </button>
          );
        })}
        <span
          className="ml-auto inline-flex items-center gap-1.5 font-mono text-[10px]"
          style={{
            color:
              fontStatus === 'ready'
                ? theme.primary
                : fontStatus === 'loading'
                  ? '#92400e'
                  : '#b3261e',
          }}
        >
          {cn
            ? fontStatus === 'ready'
              ? `✓ ${cn} 分片已就绪`
              : fontStatus === 'loading'
                ? `⟳ 正在从 fontsapi.zeoseven.com 拉取 ${cn} 分片…`
                : `✗ ${cn} 分片拉取失败（回退系统字体；请检查网络后重试）`
            : '− 未选择中文字体（汉字将回退系统字体）'}
        </span>
      </div>

      {/* 混排舞台 */}
      <div className="rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 px-6 py-8 overflow-hidden">
        <div
          contentEditable
          suppressContentEditableWarning
          spellCheck={false}
          className="outline-none break-words leading-tight text-slate-900 dark:text-white min-h-[1.3em]"
          style={{
            fontFamily: familyCss,
            fontWeight: axes.wght,
            fontVariationSettings: variationCss,
            fontOpticalSizing: 'auto',
            fontSize: `${fontSize}px`,
          }}
        >
          {text}
        </div>
        <div className="mt-4" style={{ fontFamily: familyCss, fontWeight: axes.wght, fontVariationSettings: variationCss }}>
          <p className="text-sm leading-loose text-slate-600 dark:text-slate-300">{MIXED_BODY_TEXT}</p>
        </div>
        <div className="mt-4">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="修改大标题混排文本..."
            style={{ outlineColor: theme.primary }}
            className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-2"
          />
        </div>
      </div>

      {/* 轴滑块（带手柄） */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2.5">
        {AXIS_META.map(({ key, label, note }) => (
          <AospExpressiveSlider
            key={key}
            label={label}
            value={axes[key]}
            min={AXIS_LIMITS[key].min}
            max={AXIS_LIMITS[key].max}
            step={AXIS_LIMITS[key].step}
            size="xs"
            compact
            unit=""
            formatValue={(v) => `${Math.round(v)} · ${note.split('，')[0]}`}
            accentHex={theme.primary}
            theme={theme}
            onChange={(v) => setAxis(key, v)}
          />
        ))}
        <AospExpressiveSlider
          label="预览字号"
          value={fontSize}
          min={16}
          max={96}
          step={1}
          size="xs"
          compact
          unit="px"
          accentHex={theme.primary}
          theme={theme}
          onChange={setFontSize}
        />
      </div>

      {/* 混搭预设（用户方案） */}
      <div className="flex flex-wrap items-center gap-2">
        {MIXED_PRESETS.map((p) => {
          const active = p.cn === cn && JSON.stringify(p.axes) === JSON.stringify(axes);
          return (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setCn(p.cn);
                setAxes({ ...p.axes });
              }}
              style={
                active
                  ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary }
                  : undefined
              }
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                active
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {p.label}
            </button>
          );
        })}
        <button
          type="button"
          onClick={applyGlobal}
          disabled={!cn}
          title={
            cn
              ? '把中文字体搭配与英文圆角 ROND 写入 :root 变量并持久化（全站所有区块生效）'
              : '请先选择一个中文字体，再应用全站'
          }
          style={
            applied
              ? { backgroundColor: theme.primary, color: theme.onPrimary, borderColor: theme.primary }
              : { borderColor: theme.primary, color: theme.primary }
          }
          className="rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap disabled:cursor-not-allowed disabled:opacity-40"
        >
          {applied ? '已应用到全站（再次点击刷新全局值）' : '应用到全站'}
        </button>
        {applied && (
          <button
            type="button"
            onClick={revertGlobal}
            className="rounded-full border border-slate-200 dark:border-slate-700 px-3 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
          >
            撤销全站应用
          </button>
        )}
      </div>

      {/* 英文单飞轴预设（第 12 轮保留） */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 shrink-0">
          英文单飞预设：
        </span>
        {ENGLISH_PRESETS.map((p) => {
          const active = JSON.stringify(p.axes) === JSON.stringify(axes);
          return (
            <button
              key={p.label}
              type="button"
              onClick={() => setAxes({ ...p.axes })}
              style={
                active
                  ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary }
                  : undefined
              }
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                active
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {p.label}
            </button>
          );
        })}
      </div>

      <div className="rounded-lg bg-slate-950 dark:bg-slate-950/80 border border-slate-800 px-4 py-3 font-mono text-[11px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre">
        {`.mixed-typography {
  font-family: ${familyCss};
  font-weight: ${axes.wght}; /* 同时驱动中英文可变字重 */
  font-variation-settings: ${variationCss}; /* 仅驱动 Google Sans Flex 专属轴 */
  font-synthesis-style: none;
}`}
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        全站应用的范围：中文字体搭配（--vf-cn）与英文圆角 ROND（--vf-rond）写入 :root，
        字重/字宽/视觉尺寸/倾斜不全局化——font-variation-settings 会覆盖 font-weight，
        硬套全站会毁掉所有组件的语义字重层级（取舍说明见 globals.css 注释）。
      </p>
    </div>
  );
};
