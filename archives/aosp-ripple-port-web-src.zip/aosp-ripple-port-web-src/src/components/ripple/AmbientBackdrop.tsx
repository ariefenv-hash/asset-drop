"use client";
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Eraser, ImagePlus, Loader2, Palette } from 'lucide-react';
import {
  argbFromHex,
  contrastRatioHex,
  extractWallpaperSeeds,
  Hct,
  hexFromArgb,
  hexWithAlpha,
  M3ThemeTokens,
  sanitizeDegreesDouble,
} from '../../aosp/dynamicColor';
import { AospExpressiveSlider } from './AospExpressiveSlider';
import { AMBIENT_PRESET_ID, LabConfigState } from './InteractiveLab';

interface AmbientBackdropProps {
  config: LabConfigState;
  onConfigChange: React.Dispatch<React.SetStateAction<LabConfigState>>;
  theme: M3ThemeTokens;
}

interface ColorSchemeCandidate {
  name: string;
  hex: string;
  desc: string;
}

const LS_KEY = 'aosp-ripple-port/ambient';

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

async function compressImage(src: string): Promise<string> {
  const img = await loadImage(src);
  const maxW = 1280;
  const scale = Math.min(1, maxW / img.width);
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  c.getContext('2d')!.drawImage(img, 0, 0, w, h);
  return c.toDataURL('image/jpeg', 0.85);
}

/**
 * Uses official Material Color Utilities QuantizerWsmeans (CIELAB) + Score.score()
 * to extract up to 4 Android wallpaper seed candidates plus HCT hue derivatives.
 */
async function extractMcuSchemes(src: string): Promise<ColorSchemeCandidate[]> {
  const img = await loadImage(src);
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = Math.max(1, Math.round((64 * img.height) / img.width));
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) return [];
  ctx.drawImage(img, 0, 0, c.width, c.height);
  const { data } = ctx.getImageData(0, 0, c.width, c.height);

  const seeds = extractWallpaperSeeds(data, 4);
  const candidates: ColorSchemeCandidate[] = seeds.map((hex, i) => ({
    name: i === 0 ? 'Score 首选主色' : `Score 候选 #${i + 1}`,
    hex,
    desc: 'MCU QuantizerWsmeans + Score.java 评分排序提取的壁纸种子色',
  }));

  if (seeds.length > 0) {
    const baseHct = Hct.fromInt(argbFromHex(seeds[0]));
    const compHct = Hct.from(sanitizeDegreesDouble(baseHct.hue + 180), Math.max(36, baseHct.chroma), 50);
    const triadicHct = Hct.from(sanitizeDegreesDouble(baseHct.hue + 120), Math.max(36, baseHct.chroma), 50);

    candidates.push(
      {
        name: 'HCT 互补主色',
        hex: hexFromArgb(compHct.toInt()),
        desc: '基于 CAM16 HCT 色相旋转 +180° 推导的均衡高对比种子色',
      },
      {
        name: 'HCT 三分点缀',
        hex: hexFromArgb(triadicHct.toInt()),
        desc: '基于 CAM16 HCT 色相旋转 +120° 推导的三分色方案',
      }
    );
  }

  return candidates.slice(0, 6);
}

export const AmbientBackdrop: React.FC<AmbientBackdropProps> = ({
  config,
  onConfigChange,
  theme,
}) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [blur, setBlur] = useState(18);
  const [darken, setDarken] = useState(0.45);
  const [schemes, setSchemes] = useState<ColorSchemeCandidate[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // fixed 背景层宿主：位于全站拉伸形变层之外（App.tsx #stretch-portal-host）。
  // Android 语义：拉伸作用于滚动视图，壁纸不参与拉伸；同时避免 transform 破坏
  // position:fixed（含 transformed 祖先时 fixed 会改挂到该祖先）。
  const [portalHost, setPortalHost] = useState<HTMLElement | null>(null);
  useEffect(() => {
    setPortalHost(document.getElementById('stretch-portal-host'));
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as {
        src?: string;
        blur?: number;
        darken?: number;
        accent?: { hex?: string; label?: string };
      };
      if (saved.src) {
        setImageSrc(saved.src);
        // 重载后重新分析壁纸以恢复种子候选列表（铁律四：供圆形配色预览等消费者；
        // 不覆盖用户已选 accent）
        extractMcuSchemes(saved.src)
          .then((found) => {
            if (found.length > 0) {
              setSchemes(found);
              onConfigChange((prev) => ({ ...prev, wallpaperSeeds: found }));
            }
          })
          .catch(() => {
            /* ignore */
          });
      }
      if (typeof saved.blur === 'number') setBlur(saved.blur);
      if (typeof saved.darken === 'number') setDarken(saved.darken);
      if (saved.accent?.hex) {
        setSchemes((prev) =>
          prev.length
            ? prev
            : [
                {
                  name: saved.accent!.label ?? '环境主题',
                  hex: saved.accent!.hex!,
                  desc: '已保存的壁纸种子色',
                },
              ]
        );
        onConfigChange((prev) => ({
          ...prev,
          presetId: AMBIENT_PRESET_ID,
          customAccentHex: saved.accent!.hex,
          customAccentLabel: saved.accent!.label,
        }));
      }
    } catch {
      /* ignore corrupted storage */
    }
  }, []);

  useEffect(() => {
    try {
      const payload: Record<string, unknown> = { blur, darken };
      if (imageSrc && imageSrc.length < 4_000_000) payload.src = imageSrc;
      if (config.customAccentHex) {
        payload.accent = { hex: config.customAccentHex, label: config.customAccentLabel };
      }
      localStorage.setItem(LS_KEY, JSON.stringify(payload));
    } catch {
      /* storage full */
    }
  }, [imageSrc, blur, darken, config.customAccentHex, config.customAccentLabel]);

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith('image/')) return;
      setAnalyzing(true);
      try {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        const compressed = await compressImage(dataUrl);
        setImageSrc(compressed);
        const found = await extractMcuSchemes(compressed);
        setSchemes(found);
        // 铁律四：种子候选发布到全局 config，供配色方案圆形预览等组件消费，
        // 禁止任何组件另建平行演示输入
        if (found.length > 0) {
          onConfigChange((prev) => ({
            ...prev,
            wallpaperSeeds: found,
            presetId: AMBIENT_PRESET_ID,
            customAccentHex: found[0].hex,
            customAccentLabel: found[0].name,
          }));
        }
      } catch {
        /* ignore decode failures */
      } finally {
        setAnalyzing(false);
      }
    },
    [onConfigChange]
  );

  const applyScheme = (s: ColorSchemeCandidate) => {
    onConfigChange((prev) => ({
      ...prev,
      presetId: AMBIENT_PRESET_ID,
      customAccentHex: s.hex,
      customAccentLabel: s.name,
    }));
  };

  const clearBackdrop = () => {
    setImageSrc(null);
    setSchemes([]);
    onConfigChange((prev) => ({ ...prev, wallpaperSeeds: undefined }));
    try {
      localStorage.removeItem(LS_KEY);
    } catch {
      /* ignore */
    }
  };

  const selectedHex =
    config.presetId === AMBIENT_PRESET_ID ? config.customAccentHex ?? null : null;

  const primaryContrast = contrastRatioHex(theme.primary, theme.onPrimary);
  const containerContrast = contrastRatioHex(
    theme.primaryContainer,
    theme.onPrimaryContainer
  );

  const paletteRows = [
    { key: 'Primary', data: theme.palettes.primary },
    { key: 'Secondary', data: theme.palettes.secondary },
    { key: 'Tertiary', data: theme.palettes.tertiary },
    { key: 'Neutral', data: theme.palettes.neutral },
  ];

  return (
    <>
      {imageSrc && portalHost
        ? createPortal(
            <>
              <div
                aria-hidden="true"
                className="fixed -z-10 overflow-hidden"
                style={{ inset: '-80px' }}
              >
                <div
                  className="absolute inset-0"
                  style={{
                    backgroundImage: `url(${imageSrc})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    filter: `blur(${blur}px)`,
                    transform: 'translateZ(0)',
                  }}
                />
              </div>
              <div
                aria-hidden="true"
                className="fixed -z-10 inset-0"
                style={{ backgroundColor: `rgba(2, 6, 23, ${darken})` }}
              />
            </>,
            portalHost,
          )
        : !imageSrc && (
            <div
              aria-hidden="true"
              className="fixed -z-10 inset-0 transition-colors duration-300"
              style={{ backgroundColor: theme.surface }}
            />
          )}

      <div
        id="ambient"
        className="relative z-10 scroll-mt-24 rounded-xl border border-slate-200/70 dark:border-slate-800/70 bg-white/88 dark:bg-slate-900/88 backdrop-blur-xl p-5 shadow-sm space-y-5"
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
              <Palette className="h-4 w-4" style={{ color: theme.primary }} />
              Android Monet (HCT) 动态主题色与环境壁纸提取
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              基于 Material Color Utilities <code className="font-mono">QuantizerWsmeans</code> +{' '}
              <code className="font-mono">Score.java</code> 从壁纸提取 HCT 种子色，实时生成通过 WCAG ≥ 4.5:1 校验的全套动态色调色阶并注入全站组件。
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
                e.target.value = '';
              }}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-medium transition-opacity hover:opacity-90"
              style={{
                backgroundColor: theme.primary,
                color: theme.onPrimary,
              }}
            >
              {analyzing ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <ImagePlus className="h-3.5 w-3.5" />
              )}
              {analyzing ? 'MCU 分析中…' : imageSrc ? '更换壁纸' : '上传壁纸'}
            </button>
            {imageSrc && (
              <button
                type="button"
                onClick={clearBackdrop}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                <Eraser className="h-3.5 w-3.5" />
                清除
              </button>
            )}
          </div>
        </div>

        {/* Drop zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) handleFile(f);
          }}
          style={
            dragOver
              ? {
                  borderColor: theme.primary,
                  backgroundColor: hexWithAlpha(theme.primary, 0.08),
                  color: theme.primary,
                }
              : undefined
          }
          className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 px-4 py-3 text-xs text-slate-500 dark:text-slate-400 transition-colors"
        >
          {imageSrc
            ? '背景已启用：可将新壁纸拖拽到此处替换（通过 CIELAB Wsmeans 聚类提取种子色）'
            : '支持拖拽图片到此处，或点击右上角上传；提取结果将实时驱动页面底色、波纹、滑块、开关与按钮色板'}
        </div>

        {imageSrc && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2.5">
            <AospExpressiveSlider
              label="模糊程度 (backdrop blur)"
              value={blur}
              min={0}
              max={60}
              step={1}
              size="xs"
              compact
              unit="px"
              accentHex={theme.primary}
              theme={theme}
              onChange={setBlur}
            />
            <AospExpressiveSlider
              label="压暗程度 (overlay)"
              value={Math.round(darken * 100)}
              min={0}
              max={85}
              step={1}
              size="xs"
              compact
              unit="%"
              accentHex={theme.primary}
              theme={theme}
              onChange={(v) => setDarken(v / 100)}
            />
          </div>
        )}

        {/* Extracted wallpaper seeds */}
        {schemes.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-medium text-slate-600 dark:text-slate-300">
              MCU QuantizerWsmeans + Score 提取候选种子色（点击应用）
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              {schemes.map((s) => {
                const active = selectedHex?.toLowerCase() === s.hex.toLowerCase();
                return (
                  <button
                    key={`${s.name}-${s.hex}`}
                    type="button"
                    onClick={() => applyScheme(s)}
                    title={s.desc}
                    className={`rounded-xl border p-2.5 text-left transition-all ${
                      active
                        ? 'border-transparent shadow-sm ring-2 ring-offset-2 ring-slate-900 dark:ring-white dark:ring-offset-slate-900'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                    }`}
                  >
                    <span
                      className="block h-9 w-full rounded-lg mb-2"
                      style={{ backgroundColor: s.hex }}
                    />
                    <span className="block text-[11px] font-medium text-slate-800 dark:text-slate-100 truncate">
                      {s.name}
                    </span>
                    <span className="block font-mono text-[10px] text-slate-500 dark:text-slate-400">
                      {s.hex.toUpperCase()}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Live MCU HCT Tonal Palette Strip */}
        <div className="border-t border-slate-200/80 dark:border-slate-800 pt-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-2 font-mono tabular-nums">
              <span className="font-sans font-medium text-slate-700 dark:text-slate-200">
                实时 HCT 色阶 ({theme.variant === 'expressive' ? 'SchemeExpressive' : 'SchemeTonalSpot'})
              </span>
              <span aria-hidden="true">·</span>
              <span>
                H {Math.round(theme.hct.hue)}° · C {Math.round(theme.hct.chroma)} · T{' '}
                {Math.round(theme.hct.tone)}
              </span>
            </div>
            <div className="font-mono text-[11px] tabular-nums">
              Primary 对比度 {primaryContrast.toFixed(2)}:1 · Container 对比度{' '}
              {containerContrast.toFixed(2)}:1
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {paletteRows.map((row) => (
              <div key={row.key} className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400">
                  <span className="font-sans font-medium text-slate-700 dark:text-slate-300">
                    {row.key}
                  </span>
                  <span>
                    H {Math.round(row.data.hue)}° · C {Math.round(row.data.chroma)}
                  </span>
                </div>
                <div className="grid grid-cols-6 overflow-hidden rounded-lg border border-black/5 dark:border-white/10">
                  {row.data.tones.map((t) => (
                    <div
                      key={t.tone}
                      title={`${row.key} T${t.tone}: ${t.hex}`}
                      className="flex h-8 items-end justify-center pb-1 font-mono text-[9px] tabular-nums"
                      style={{
                        backgroundColor: t.hex,
                        color: t.tone >= 60 ? '#0f172a' : '#f8fafc',
                      }}
                    >
                      {t.tone}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};
