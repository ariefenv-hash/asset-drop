"use client";
/**
 * AOSP / MDC-Android 1.14.0 表达性滑块 —— Web 忠实转译
 *
 * 尺寸令牌（sources/mdc-android/.../slider/res/values/tokens.xml）：
 *  - m3_comp_slider_active_handle_width: 4dp / 高度 44dp（press 时宽度×0.5 = 2dp，
 *    BaseSlider.java L277 THUMB_WIDTH_PRESSED_RATIO=.5f，L3460 updateThumbWidthWhenPressed()
 *    走 setThumbSize + invalidate —— 立即生效，源码无任何宽度过渡动画）
 *  - m3_comp_slider_active_handle_leading_space (thumbTrackGapSize): 6dp
 *  - m3_comp_slider_stop_indicator_size: 4dp
 *  - XS trackHeight 16dp / M 40dp / L 56dp（m3_comp_slider_{xsmall,medium,large}_active_track_height）
 *
 * 【拖动跟手性 · 2026-11-21 修复】BaseSlider.java 中唯一的动画只有标签（TooltipDrawable）
 * 进出场（L285-286：进场 83ms + DECELERATE_INTERPOLATOR；出场 117ms + FAST_OUT_LINEAR_IN），
 * 手柄与填充条位置由触摸事件直接 updateThumbPosition → invalidate，1:1 跟手、零过渡。
 * 旧实现给填充条 width/left 加 75ms、气泡加 150ms 的自创 transition，且每个 pointermove
 * 触发整棵 React 树重渲 —— 快速拖动时视觉永远慢半拍。修复：
 *  1) 移除全部位置/宽度过渡（源码即"即时生效"语义）；
 *  2) 拖动期视觉走 rAF 命令式写 DOM（手柄/两段轨道/气泡位置、数值文本），不等 React 提交；
 *  3) pointermove 事件合并到每帧最多一次（高回报率鼠标 1000Hz 不再排队）；
 *  4) 拖动开始时缓存一次 getBoundingClientRect（每 move 强制重排是卡顿源之一）。
 * 气泡进出场改为源码值：进场 83ms、出场 117ms；曲线为 AnimationUtils.java L43 两个插值器的
 * Web 复刻 —— DECELERATE_INTERPOLATOR（DecelerateInterpolator f(t)=1-(1-t)²）用 CSS linear()
 * 逐点采样精确复刻；FAST_OUT_LINEAR_IN（androidx PathInterpolator(0.4,0,1,1)）即同值贝塞尔。
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { hexWithAlpha, M3ThemeTokens } from '../../aosp/dynamicColor';
import type {
  AospRippleEngineMode,
  RippleColorRGBA,
  SystemUiRippleShape,
} from '../../aosp/RippleEngine';

export type ExpressiveSliderSize = 'xs' | 'm' | 'l';

export interface AospExpressiveSliderProps {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  size?: ExpressiveSliderSize;
  icon?: React.ReactNode;
  showStops?: boolean;
  unit?: string;
  formatValue?: (value: number) => string;
  compact?: boolean;
  mode?: AospRippleEngineMode;
  waveColor?: RippleColorRGBA;
  sparkleColor?: RippleColorRGBA;
  sparkleStrength?: number;
  distortionStrength?: number;
  systemUiShape?: SystemUiRippleShape;
  speedMultiplier?: number;
  densityScale?: number;
  accentHex: string;
  theme?: M3ThemeTokens;
  onChange: (value: number) => void;
}

/**
 * Dimensions directly ported from AOSP / MDC-Android tokens.xml & BaseSlider.java:
 * - m3_comp_slider_active_handle_width: 4dp
 * - BaseSlider.THUMB_WIDTH_PRESSED_RATIO: 0.5f -> 2dp when pressed
 * - m3_comp_slider_active_handle_leading_space (thumbTrackGapSize): 6dp
 * - m3_comp_slider_stop_indicator_size: 4dp
 * - XS trackHeight 16dp / handleHeight 44dp
 * - M  trackHeight 40dp / handleHeight 44dp
 * - L  trackHeight 56dp / handleHeight 68dp
 */
const SIZE_TOKENS: Record<
  ExpressiveSliderSize,
  {
    trackHeight: number;
    handleHeight: number;
    outerRadius: number;
    innerRadius: number;
    iconSize: number;
  }
> = {
  xs: {
    trackHeight: 16,
    handleHeight: 44,
    outerRadius: 8,
    innerRadius: 2,
    iconSize: 0,
  },
  m: {
    trackHeight: 40,
    handleHeight: 44,
    outerRadius: 12,
    innerRadius: 4,
    iconSize: 20,
  },
  l: {
    trackHeight: 56,
    handleHeight: 68,
    outerRadius: 16,
    innerRadius: 4,
    iconSize: 24,
  },
};

const THUMB_WIDTH_REST = 4;
const THUMB_WIDTH_PRESSED = 2;
const THUMB_TRACK_GAP = 6;
const STOP_INDICATOR_SIZE = 4;

/**
 * AnimationUtils.DECELERATE_INTERPOLATOR（AnimationUtils.java L43，DecelerateInterpolator
 * f(t) = 1-(1-t)^2）的 CSS linear() 逐点采样（每 5% 一点，端点固定 0/1）。
 * 【诚实标注】这是源插值器的精确采样复刻，非贝塞尔近似。
 */
const LABEL_IN_EASING =
  'linear(0 0%, 0.0975 5%, 0.19 10%, 0.2775 15%, 0.36 20%, 0.4375 25%, 0.51 30%, ' +
  '0.5775 35%, 0.64 40%, 0.6975 45%, 0.75 50%, 0.7975 55%, 0.84 60%, 0.8775 65%, ' +
  '0.91 70%, 0.9375 75%, 0.96 80%, 0.9775 85%, 0.99 90%, 0.9975 95%, 1 100%)';
/** AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR = androidx PathInterpolator(0.4, 0, 1, 1) */
const LABEL_OUT_EASING = 'cubic-bezier(0.4, 0, 1, 1)';
/** BaseSlider.java L285-286 默认值（motionDurationMedium4 / motionDurationShort3 的默认值） */
const LABEL_IN_DURATION_MS = 83;
const LABEL_OUT_DURATION_MS = 117;

export const AospExpressiveSlider: React.FC<AospExpressiveSliderProps> = ({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  size = 'xs',
  icon,
  showStops = false,
  unit = '%',
  formatValue,
  compact = false,
  accentHex,
  theme,
  onChange,
}) => {
  const trackWrapRef = useRef<HTMLDivElement>(null);
  // 拖动期命令式目标：位置更新不等 React 提交（见文件头"拖动跟手性"注）
  const activeTrackRef = useRef<HTMLDivElement>(null);
  const inactiveTrackRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const valueTextRef = useRef<HTMLSpanElement>(null);

  const [isPressed, setIsPressed] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [trackWidthPx, setTrackWidthPx] = useState(0);

  const dragRef = useRef<{
    active: boolean;
    rect: DOMRect | null;
    raf: number;
    clientX: number;
  }>({ active: false, rect: null, raf: 0, clientX: 0 });
  // 最近一次已提交给父级的值：BaseSlider 仅在值真正变化时才回调 onValueChanged，
  // 重复的同值提交（末帧 + 松手收尾各一次）既浪费也违背源码语义
  const lastEmittedRef = useRef<number | null>(null);

  useEffect(() => {
    const wrap = trackWrapRef.current;
    if (!wrap) return;
    const measure = () => setTrackWidthPx(wrap.getBoundingClientRect().width);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, []);

  const tokens = SIZE_TOKENS[size];
  const clamped = Math.min(max, Math.max(min, value));
  const ratio = max > min ? (clamped - min) / (max - min) : 0;

  const formatDisplay = useCallback(
    (v: number) =>
      formatValue ? formatValue(v) : `${step >= 1 ? Math.round(v) : v.toFixed(2)}${unit}`,
    [formatValue, step, unit]
  );

  // 由 clientX 换算步进后的目标值（使用拖动开始时缓存的 rect，避免每 move 强制重排）
  const computeValueFromClientX = useCallback(
    (clientX: number, rect: DOMRect | null) => {
      if (!rect) return null;
      const rawRatio = Math.min(1, Math.max(0, (clientX - rect.left) / Math.max(1, rect.width)));
      const rawVal = min + rawRatio * (max - min);
      const stepped = Math.round((rawVal - min) / step) * step + min;
      return Number(Math.min(max, Math.max(min, stepped)).toFixed(4));
    },
    [max, min, step]
  );

  /** rAF 帧回调：命令式写全部拖动相关视觉，再向父级提交一次 onChange（每帧至多一次）。 */
  const applyDragFrame = useCallback(() => {
    const drag = dragRef.current;
    drag.raf = 0;
    if (!drag.active || drag.rect === null) return;
    const next = computeValueFromClientX(drag.clientX, drag.rect);
    if (next === null) return;

    const r = max > min ? (next - min) / (max - min) : 0;
    const pct = r * 100;
    const handleWidth = THUMB_WIDTH_PRESSED; // 拖动中 = 按压宽度（BaseSlider PRESSED_RATIO）
    const halfGap = handleWidth * 0.5 + THUMB_TRACK_GAP;

    if (handleRef.current) {
      handleRef.current.style.left = `clamp(2px, ${pct}%, calc(100% - 2px))`;
    }
    if (activeTrackRef.current) {
      activeTrackRef.current.style.width = `max(0px, calc(${pct}% - ${halfGap}px))`;
    }
    if (inactiveTrackRef.current) {
      inactiveTrackRef.current.style.left = `calc(${pct}% + ${halfGap}px)`;
    }
    if (tooltipRef.current) {
      tooltipRef.current.style.left = `clamp(16px, ${pct}%, calc(100% - 16px))`;
    }
    const text = formatDisplay(next);
    if (tooltipRef.current) tooltipRef.current.textContent = text;
    if (valueTextRef.current) valueTextRef.current.textContent = text;

    if (lastEmittedRef.current !== next) {
      lastEmittedRef.current = next;
      onChange(next);
    }
  }, [computeValueFromClientX, formatDisplay, max, min, onChange]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const wrap = trackWrapRef.current;
    if (!wrap) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragRef.current.active = true;
    dragRef.current.clientX = e.clientX;
    dragRef.current.rect = wrap.getBoundingClientRect();
    lastEmittedRef.current = null;
    setIsPressed(true);
    // 首帧立即生效（与 Android onTouchAction DOWN 即 invalidate 一致），不经 rAF 延迟
    applyDragFrame();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag.active) return;
    drag.clientX = e.clientX;
    if (drag.raf === 0) {
      drag.raf = requestAnimationFrame(applyDragFrame);
    }
  };

  const endDrag = () => {
    const drag = dragRef.current;
    if (!drag.active) return;
    if (drag.raf !== 0) {
      // 收尾：取消未决帧，避免松手后画面补帧"追尾"
      cancelAnimationFrame(drag.raf);
      drag.raf = 0;
    }
    // 同步落定最后一次移动的值（applyDragFrame 依赖 active=true，先落定再置 false）
    applyDragFrame();
    drag.active = false;
    drag.rect = null;
    setIsPressed(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    let next: number | null = null;
    if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
      next = Math.min(max, clamped + step);
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
      next = Math.max(min, clamped - step);
    } else if (e.key === 'Home') {
      next = min;
    } else if (e.key === 'End') {
      next = max;
    }
    if (next !== null) {
      e.preventDefault();
      onChange(Number(next.toFixed(4)));
    }
  };

  const handleWidth = isPressed ? THUMB_WIDTH_PRESSED : THUMB_WIDTH_REST;
  const halfGap = handleWidth * 0.5 + THUMB_TRACK_GAP;
  const pct = ratio * 100;

  const activePrimary = theme?.primary ?? accentHex;
  const activeOnPrimary = theme?.onPrimary ?? '#ffffff';
  const inactiveTrackBg = theme?.secondaryContainer;
  const tooltipBg = theme?.inverseSurface;
  const tooltipFg = theme?.inverseOnSurface;

  // BaseSlider.java: trailing 4dp stop indicator is inset by trackHeight * 0.5 from endcap
  // and hidden when the thumb gap would collide with it.
  const stopInsetPx = tokens.trackHeight * 0.5;
  const thumbCenterPx = ratio * trackWidthPx;
  const stopCenterPx = Math.max(0, trackWidthPx - stopInsetPx);
  const showTrailingStop =
    ratio < 0.999 &&
    (trackWidthPx <= 0 ||
      Math.abs(stopCenterPx - thumbCenterPx) > halfGap + STOP_INDICATOR_SIZE * 0.5 + 1);

  const stopPositions: number[] = [];
  if (showStops && step > 0 && (max - min) / step <= 12) {
    const count = Math.round((max - min) / step);
    for (let i = 1; i < count; i++) {
      stopPositions.push(i / count);
    }
  }

  const wrapperHeight = compact
    ? Math.max(32, tokens.trackHeight + 16)
    : Math.max(tokens.handleHeight, 48);
  const effectiveHandleHeight = compact && size === 'xs' ? 32 : tokens.handleHeight;

  return (
    <div className={compact ? 'space-y-1' : 'space-y-2'}>
      <div className="flex items-center justify-between text-xs">
        <span
          className={
            compact
              ? 'text-slate-600 dark:text-slate-300'
              : 'font-medium text-slate-800 dark:text-slate-200'
          }
        >
          {label}
        </span>
        <span
          ref={valueTextRef}
          className="font-mono tabular-nums text-slate-900 dark:text-slate-100"
        >
          {formatDisplay(clamped)}
        </span>
      </div>

      <div
        ref={trackWrapRef}
        role="slider"
        tabIndex={0}
        aria-label={label}
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={clamped}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onLostPointerCapture={endDrag}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        onKeyDown={handleKeyDown}
        style={{ height: `${wrapperHeight}px` }}
        className="relative flex items-center select-none touch-none cursor-pointer focus-visible:outline-none overflow-visible"
      >
        {/* Active Track (Left of Handle - Gap) —— 位置无过渡：BaseSlider 拖动即 invalidate，1:1 跟手 */}
        <div
          ref={activeTrackRef}
          style={{
            height: `${tokens.trackHeight}px`,
            width: `max(0px, calc(${pct}% - ${halfGap}px))`,
            backgroundColor: activePrimary,
            borderTopLeftRadius: `${tokens.outerRadius}px`,
            borderBottomLeftRadius: `${tokens.outerRadius}px`,
            borderTopRightRadius: `${tokens.innerRadius}px`,
            borderBottomRightRadius: `${tokens.innerRadius}px`,
          }}
          className="relative overflow-hidden flex items-center"
        >
          {icon && size !== 'xs' && (
            <span
              className="ml-2.5 shrink-0 pointer-events-none flex items-center justify-center"
              style={{
                width: `${tokens.iconSize}px`,
                height: `${tokens.iconSize}px`,
                color: activeOnPrimary,
              }}
            >
              {icon}
            </span>
          )}
        </div>

        {/* Inactive Track (Right of Handle + Gap) —— 位置无过渡，理由同上 */}
        <div
          ref={inactiveTrackRef}
          style={{
            height: `${tokens.trackHeight}px`,
            left: `calc(${pct}% + ${halfGap}px)`,
            right: 0,
            backgroundColor: inactiveTrackBg,
            borderTopLeftRadius: `${tokens.innerRadius}px`,
            borderBottomLeftRadius: `${tokens.innerRadius}px`,
            borderTopRightRadius: `${tokens.outerRadius}px`,
            borderBottomRightRadius: `${tokens.outerRadius}px`,
          }}
          className={`absolute ${
            inactiveTrackBg ? '' : 'bg-slate-200 dark:bg-slate-700/80'
          }`}
        />

        {/* Trailing End Stop Indicator centered along endcap axis (BaseSlider.java) */}
        {showTrailingStop && (
          <span
            aria-hidden="true"
            style={{
              width: `${STOP_INDICATOR_SIZE}px`,
              height: `${STOP_INDICATOR_SIZE}px`,
              right: `${stopInsetPx - STOP_INDICATOR_SIZE * 0.5}px`,
              backgroundColor: activePrimary,
            }}
            className="pointer-events-none absolute top-1/2 -translate-y-1/2 rounded-full opacity-90"
          />
        )}

        {/* Discrete Tick Dots */}
        {stopPositions.map((posRatio) => {
          const isCovered = posRatio <= ratio;
          if (Math.abs(posRatio - ratio) < 0.04) return null;
          return (
            <span
              key={posRatio}
              aria-hidden="true"
              style={{
                left: `calc(${posRatio * 100}% - 2px)`,
                width: `${STOP_INDICATOR_SIZE}px`,
                height: `${STOP_INDICATOR_SIZE}px`,
                backgroundColor: isCovered ? activeOnPrimary : activePrimary,
              }}
              className="pointer-events-none absolute top-1/2 -translate-y-1/2 rounded-full opacity-90"
            />
          );
        })}

        {/* Floating Value Indicator Pill on Drag —— 进出场 83/117ms 仅动 opacity/transform，
            位置与手柄 1:1（MDC 标签 revealFraction 只作用于淡入淡出与位移，不滞后于拇指） */}
        <div
          ref={tooltipRef}
          aria-hidden="true"
          style={{
            left: `clamp(16px, ${pct}%, calc(100% - 16px))`,
            bottom: `calc(50% + ${effectiveHandleHeight * 0.5 + 8}px)`,
            backgroundColor: tooltipBg,
            color: tooltipFg,
            transition: isPressed
              ? `opacity ${LABEL_IN_DURATION_MS}ms ${LABEL_IN_EASING}, transform ${LABEL_IN_DURATION_MS}ms ${LABEL_IN_EASING}`
              : `opacity ${LABEL_OUT_DURATION_MS}ms ${LABEL_OUT_EASING}, transform ${LABEL_OUT_DURATION_MS}ms ${LABEL_OUT_EASING}`,
          }}
          className={`pointer-events-none absolute -translate-x-1/2 rounded-full px-2.5 py-1 text-[11px] font-mono font-semibold tabular-nums shadow-sm ${
            tooltipBg ? '' : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
          } ${
            isPressed ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-90 translate-y-1'
          }`}
        >
          {formatDisplay(clamped)}
        </div>

        {/* Expressive Vertical Bar Handle (4dp -> 2dp on press) ——
            BaseSlider.updateThumbWidthWhenPressed 即时生效，无宽度动画（L3460-3470） */}
        <div
          ref={handleRef}
          aria-hidden="true"
          style={{
            left: `clamp(2px, ${pct}%, calc(100% - 2px))`,
            width: `${handleWidth}px`,
            height: `${effectiveHandleHeight}px`,
            backgroundColor: activePrimary,
            boxShadow: isFocused
              ? `0 0 0 3px ${hexWithAlpha(activePrimary, 0.35)}`
              : undefined,
          }}
          className="pointer-events-none absolute top-1/2 -translate-x-1/2 -translate-y-1/2 z-30 rounded-full"
        />
      </div>
    </div>
  );
};
