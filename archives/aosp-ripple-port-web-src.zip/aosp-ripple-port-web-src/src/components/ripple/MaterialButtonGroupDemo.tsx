"use client";
/**
 * Material 3 (Expressive) MaterialButtonGroup / MaterialButtonToggleGroup —— Web 忠实转译
 * （MDC-Android 1.14.0，本地真实源码 sources/mdc-android/lib/java/com/google/android/material/）
 *
 * 【三种官方变体】
 * A. Standard MaterialButtonGroup —— 按压展开 + 邻钮让位（width morph）
 *    - 容器：spacing 12dp（button/res/values/button_group_tokens.xml
 *          m3_comp_button_group_standard_small_between_space）；
 *          buttonSizeChange = @xml/m3_button_group_child_size_change
 *          （styles.xml Widget.Material3.MaterialButtonGroup L530-535）
 *    - 尺寸状态列表：state_pressed → widthChange 15%；默认 0%
 *          （button/res/xml/m3_button_group_child_size_change.xml，PERCENT 语义：
 *          StateListSizeChange.java L126 getChange = (int)(amount * baseSize)）
 *    - 让位算法（MaterialButtonGroup.java）：
 *          · onButtonWidthChanged L823-847：双邻各吸收一半（前 n/2、后 (n+1)/2，奇数补偿），
 *            单邻全吸收；setDisplayedWidthDecrease L2052-2056 钳制 min(decrease, allowedWidthDecrease)
 *            且瞬时生效（无动画）
 *          · adjustChildSizeChangeInRange L873-913 两遍扫描：首钮方向 END、尾钮 START、中钮 BOTH；
 *            单边增量 = min(自身 maxWidthChange, 双邻 allowedWidthDecrease 之和)（L921-935），
 *            取全组最小单边值 → widthChangeMax = 单边×2
 *          · calculateEffectiveWidthChangeMax L1992-2002：END/START 方向有效上限减半
 *          · allowedWidthDecrease L611-615 = 测量宽 − 文本布局宽 − 图标及其间距（防文本截断）
 *          · 显示宽 = originalWidth + increase − decrease（L2100-2116，对称 padding 居中）
 *    - 弹簧：Motion.Material3.Spring.Standard.Fast.Spatial
 *          （MaterialButton.createSpringForce L364-369 → motion/res/values/tokens.xml L41-42）
 *          stiffness=1400、dampingRatio=0.9；驱动 displayedWidthIncrease（L2131 FloatProperty）
 *    - 子按钮 Widget.Material3.Button.TonalButton（隐式父级 Widget.Material3.Button）：
 *          容器 colorSecondaryContainer、文字/图标 colorOnSecondaryContainer
 *          （button/res/values/tokens.xml m3_comp_button_tonal_* 宏 +
 *          ThemeOverlay.Material3.Button.TonalButton）；
 *          padding 24dp/6dp、inset 4dp（dimens.xml m3_btn_padding_* / m3_btn_inset）、
 *          icon 18dp、icon-label 8dp（styles.xml Widget.Material3.Button）、
 *          形状 ShapeAppearance.M3.Comp.Button.Small.Container.Shape.Round = Corner.Full（50% pill，
 *          button/res/values/tokens.xml L 内联定义）
 *
 * B. Connected MaterialButtonGroup —— 连体按钮组
 *    - styles.xml Widget.Material3.MaterialButtonGroup.Connected L537-542：
 *          spacing 2dp（m3_comp_button_group_connected_small_between_space）、innerCornerSize 8dp、
 *          shapeAppearance Corner.Full、buttonSizeChange @null（不展开，按压无位移——如实呈现）
 *    - 内角应用规则（MaterialButtonGroup.updateChildShapes L639-701）：首/尾钮保留外侧两角
 *          （组形状 Corner.Full 覆盖首尾外形，L716-727），面向邻钮的角一律被 innerCornerSize 覆盖
 *
 * C. Expressive MaterialButtonToggleGroup（分段按钮，单选）
 *    - styles.xml Widget.Material3Expressive.MaterialButtonToggleGroup L33-37：
 *          innerCornerSize = @xml/m3expressive_connected_buttons_inner_corner_size_state_list
 *          （checkable+pressed → m3_comp_button_group_connected_small_pressed_inner_corner_corner_size
 *          = ?attr/shapeCornerSizeExtraSmall = 4dp；checked → 50%；默认 → shapeCornerSizeSmall = 8dp；
 *          shape/res/values/tokens.xml L97-98）；
 *          spacing 2dp、组形状 Corner.Full
 *    - 子按钮 Widget.Material3Expressive.Button.OutlinedButton（styles.xml L+-）：
 *          · 容器：checked → colorContainerChecked = 宏 m3_comp_button_outlined_selected_container_color
 *            = colorSurfaceInverse；unchecked → colorContainerUnchecked = transparent
 *            （button/res/color/m3expressive_button_outlined_background_color_selector.xml +
 *            ThemeOverlay.Material3Expressive.Button.Outlined + tokens.xml L134）
 *          · 描边 1dp（m3_comp_button_small_outlined_outline_width，button/res/values/tokens.xml）：
 *            checked → transparent、unchecked → colorOutlineVariant
 *            （m3expressive_button_outline_color_selector.xml）
 *          · 文字/图标：checked → colorOnContainerChecked = m3_comp_button_outlined_selected_icon_color
 *            = colorOnSurfaceInverse；unchecked → colorOnContainerUnchecked =
 *            m3_comp_button_outlined_unselected_icon_color = colorOnSurfaceVariant
 *            （color/m3_button_foreground_color_selector.xml + tokens.xml L136-137）
 *          · 尺寸 SizeOverlay.Material3Expressive.Button.Small：padding 16dp/10dp、inset 4dp、
 *            icon 20dp、icon-label 8dp、文字 textAppearanceLabelLarge（14sp/20sp Medium）
 *          · 形状状态列表 @xml/m3expressive_button_shape_state_list：pressed → containerShapePressed
 *            = shapeAppearanceCornerSmall = 8dp；checked → containerShapeChecked =
 *            shapeAppearanceCornerMedium = 12dp；默认 = Round（pill）。
 *            Stateful ShapeAppearance 挂 cornerSpringForce（MaterialButton.java L347-349，
 *            同 Fast Spatial 弹簧 1400/0.9）→ 圆角形变为弹簧动画
 *    - 单选语义（MaterialButtonToggleGroup.checkInternal L476-497）：singleSelection 下勾选新项
 *          先清空其余；点击已勾选项会取消勾选（selectionRequired 默认 false）
 *
 * 【诚实缺口】
 * 1. allowedWidthDecrease 的文本布局宽以 Web 端 label 元素实测宽度近似
 *    （源码为 getTextLayoutWidth() 的 Layout 度量），已尽量等义。
 * 2. 圆角弹簧的作用域：源码弹簧挂在 MaterialShapeDrawable 内部（MaterialButtonHelper），
 *    本转译将四角圆角统一由同一 1400/0.9 弹簧驱动，属于 Web 侧工程近似。
 * 3. 涟漪未接入（同 SplitButton 说明）：Android 侧按压反馈由 RippleDrawable 提供，
 *    本组件按压反馈仅呈现颜色/形状/宽度三个有源可依的状态变化。
 * 4. OVERFLOW_MODE_MENU / OVERFLOW_MODE_WRAP（溢出菜单与换行）未移植，本演示为
 *    OVERFLOW_MODE_NONE 路径。
 * 5. (int) 截断与奇数补偿（n/2、(n+1)/2）按源码逐式保留。
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { MoreHorizontal, Share2, Star } from 'lucide-react';
import type { M3ThemeTokens } from '@/aosp/dynamicColor';
import { M3_SPRING_STANDARD_FAST, stepSpring, type SpringState } from '@/aosp/spring';

/* ======================= 通用：M3 tonal 按钮（inset 结构） ======================= */
/* Android 结构：view 盒（触达 40dp 高，inset 4dp）→ 背面 surface（视觉高 32dp）→ 内容行 */

interface TonalButtonSpec {
  label: string;
  icon: React.ReactNode;
}

const TONAL = {
  height: 40, // 触达盒：内容 32dp + inset 4dp×2
  surfaceHeight: 32, // inset 上下各 4dp → 视觉高
  padX: 24, // m3_btn_padding_left/right
  iconSize: 18, // Widget.Material3.Button iconSize
  gap: 8, // m3_comp_button_small_icon_label_space
  radiusPill: 16, // Corner.Full 50% = 32dp 高之半
} as const;

interface SqueezeState {
  spring: SpringState; // displayedWidthIncrease（弹簧驱动）
  dec: number; // displayedWidthDecrease（瞬时，来自邻钮）
  pressed: boolean;
}

interface StandardGroupProps {
  theme: M3ThemeTokens;
}

/** A. Standard MaterialButtonGroup：按压 +15% 弹簧展开，双邻各让一半（文本保护钳制） */
function StandardGroup({ theme }: StandardGroupProps) {
  const btnRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const labelRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const iconRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const measured = useRef<Array<{ original: number; allowedDec: number }>>([
    { original: 0, allowedDec: 0 },
    { original: 0, allowedDec: 0 },
    { original: 0, allowedDec: 0 },
  ]);
  const states = useRef<Array<SqueezeState>>([
    { spring: { value: 0, velocity: 0, target: 0 }, dec: 0, pressed: false },
    { spring: { value: 0, velocity: 0, target: 0 }, dec: 0, pressed: false },
    { spring: { value: 0, velocity: 0, target: 0 }, dec: 0, pressed: false },
  ]);
  const widthChangeMax = useRef(0);
  const rafRef = useRef<number | null>(null);
  const [, forceRender] = useState(0); // 触发一次重渲以同步 aria

  /** 组级两遍扫描（adjustChildSizeChangeInRange L873-913 + getButtonAllowedWidthIncrease L921-935） */
  const computeGroupConfig = useCallback(() => {
    const m = measured.current;
    const DIRECTIONS = ['END', 'BOTH', 'START'] as const;
    // 第一遍：每钮允许的单边增量
    let singleEdge = Number.MAX_VALUE;
    for (let i = 0; i < m.length; i++) {
      const prevAllowed = i > 0 ? m[i - 1].allowedDec : 0;
      const nextAllowed = i < m.length - 1 ? m[i + 1].allowedDec : 0;
      const increase = Math.min(0.15 * m[i].original, prevAllowed + nextAllowed);
      const perEdge = i !== 0 && i !== m.length - 1 ? increase / 2 : increase;
      singleEdge = Math.min(singleEdge, perEdge);
      void DIRECTIONS[i];
    }
    // 第二遍：widthChangeMax = 单边×2（L909-911）
    widthChangeMax.current = Math.max(0, Math.floor(singleEdge * 2));
  }, []);

  const measure = useCallback(() => {
    const m = measured.current;
    for (let i = 0; i < btnRefs.current.length; i++) {
      const btn = btnRefs.current[i];
      const label = labelRefs.current[i];
      const icon = iconRefs.current[i];
      if (!btn || !label) continue;
      const original = btn.offsetWidth;
      const textLayoutWidth = label.offsetWidth;
      const iconSizeAndPadding = icon ? TONAL.iconSize + TONAL.gap : 0;
      // allowedWidthDecrease = getMeasuredWidth() − getTextLayoutWidth() − 图标及间距（L611-615）
      m[i] = {
        original,
        allowedDec: Math.max(0, original - textLayoutWidth - iconSizeAndPadding),
      };
    }
    computeGroupConfig();
  }, [computeGroupConfig]);

  useEffect(() => {
    measure();
    // 字体加载完成后文本度量可能变化，重测一次
    if (typeof document !== 'undefined' && 'fonts' in document) {
      document.fonts.ready.then(() => measure()).catch(() => {});
    }
    // 视口变化重测（源码 onMeasure 语义）
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, [measure]);

  /** 邻钮让位（onButtonWidthChanged L823-847，逐式保留 int 截断与奇数补偿） */
  const applySqueeze = useCallback((pressedIndex: number, increaseSize: number) => {
    const st = states.current;
    const hasPrev = pressedIndex > 0;
    const hasNext = pressedIndex < st.length - 1;
    if (hasPrev && hasNext) {
      st[pressedIndex - 1].dec = Math.min(Math.trunc(increaseSize / 2), measured.current[pressedIndex - 1].allowedDec);
      st[pressedIndex + 1].dec = Math.min(Math.trunc((increaseSize + 1) / 2), measured.current[pressedIndex + 1].allowedDec);
    } else if (hasNext) {
      st[pressedIndex + 1].dec = Math.min(increaseSize, measured.current[pressedIndex + 1].allowedDec);
    } else if (hasPrev) {
      st[pressedIndex - 1].dec = Math.min(increaseSize, measured.current[pressedIndex - 1].allowedDec);
    }
  }, []);

  const writeFrame = useCallback(() => {
    const st = states.current;
    const m = measured.current;
    for (let i = 0; i < st.length; i++) {
      const btn = btnRefs.current[i];
      if (!btn) continue;
      const inc = st[i].spring.value;
      // 显示宽 = originalWidth + increase − decrease（L2109，(int) 截断）
      const w = Math.trunc(m[i].original + inc - st[i].dec);
      btn.style.width = `${w}px`;
    }
  }, []);

  const tick = useCallback(
    (now: number, last: number) => {
      const st = states.current;
      const dt = Math.min((now - last) / 1000, 0.032);
      let active = false;
      for (let i = 0; i < st.length; i++) {
        const running = stepSpring(st[i].spring, dt, M3_SPRING_STANDARD_FAST, 0.02);
        if (running) active = true;
        // 每帧把当前弹簧值同步为邻钮的瞬时让位（setDisplayedWidthDecrease 无动画）
        applySqueeze(i, Math.trunc(st[i].spring.value));
      }
      writeFrame();
      if (active) {
        rafRef.current = requestAnimationFrame((t) => tick(t, now));
      } else {
        rafRef.current = null;
        writeFrame(); // 收尾同步落定（避免追尾）
      }
    },
    [applySqueeze, writeFrame]
  );

  const startLoop = useCallback(() => {
    if (rafRef.current !== null) return;
    rafRef.current = requestAnimationFrame((t) => tick(t, t - 16));
  }, [tick]);

  const setPressed = useCallback(
    (i: number, pressed: boolean) => {
      const st = states.current;
      if (st[i].pressed === pressed) return;
      st[i].pressed = pressed;
      // maybeAnimateSize L1968-1989：
      // widthChange = min(effectiveMax, sizeChange.getChange(getWidth()))
      // getChange(PERCENT) = (int)(0.15 × 当前宽)；END/START 方向有效上限减半（L1992-2002）
      const effectiveMax =
        i === 0 || i === st.length - 1 ? Math.trunc(widthChangeMax.current / 2) : widthChangeMax.current;
      const currentWidth = measured.current[i].original - st[i].dec;
      const percentChange = Math.trunc(0.15 * currentWidth);
      st[i].spring.target = pressed ? Math.min(effectiveMax, percentChange) : 0;
      startLoop();
      forceRender((n) => n + 1);
    },
    [startLoop]
  );

  useEffect(
    () => () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    },
    []
  );

  const buttons: TonalButtonSpec[] = [
    {
      label: '收藏',
      icon: <Star size={TONAL.iconSize} strokeWidth={2} aria-hidden="true" />,
    },
    {
      label: '分享',
      icon: <Share2 size={TONAL.iconSize} strokeWidth={2} aria-hidden="true" />,
    },
    {
      label: '更多',
      icon: <MoreHorizontal size={TONAL.iconSize} strokeWidth={2} aria-hidden="true" />,
    },
  ];

  const containerColor = theme.secondaryContainer;
  const contentColor = theme.onSecondaryContainer;

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
          A · Standard —— 按压展开 + 邻钮让位
        </h4>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          spacing 12dp · widthChange 15% · spring 1400/0.9
        </span>
      </div>
      <div className="overflow-x-auto rounded-lg py-[10px]" style={{ backgroundColor: theme.surfaceContainerLow }}>
        {/* overflow-x-auto 仅为窄屏查看辅助，组件本体语义为 OVERFLOW_MODE_NONE */}
        <div
          className="mx-auto flex w-max min-w-full items-center justify-center px-4"
          style={{ gap: '12px' }} // m3_comp_button_group_standard_small_between_space 12dp
          role="group"
          aria-label="Standard MaterialButtonGroup 演示"
        >
          {buttons.map((b, i) => {
            const pressed = states.current[i].pressed;
            return (
              <button
                key={b.label}
                type="button"
                ref={(el) => {
                  btnRefs.current[i] = el;
                }}
                aria-pressed={pressed}
                onPointerDown={() => setPressed(i, true)}
                onPointerUp={() => setPressed(i, false)}
                onPointerLeave={() => setPressed(i, false)}
                onPointerCancel={() => setPressed(i, false)}
                style={{
                  position: 'relative',
                  height: `${TONAL.height}px`,
                  background: 'transparent',
                  padding: 0,
                  border: 'none',
                  flex: 'none',
                  touchAction: 'manipulation',
                }}
              >
                {/* Android 背景 inset 4dp → 视觉 surface 高 32dp */}
                <span
                  aria-hidden="true"
                  style={{
                    position: 'absolute',
                    left: 0,
                    right: 0,
                    top: '4px',
                    bottom: '4px',
                    borderRadius: `${TONAL.radiusPill}px`,
                    backgroundColor: containerColor,
                  }}
                />
                <span
                  style={{
                    position: 'relative',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: `${TONAL.gap}px`,
                    height: `${TONAL.surfaceHeight}px`,
                    padding: `0 ${TONAL.padX}px`,
                    fontSize: '14px',
                    lineHeight: '20px',
                    fontWeight: 500,
                    color: contentColor,
                    whiteSpace: 'nowrap',
                  }}
                >
                  <span
                    ref={(el) => {
                      iconRefs.current[i] = el;
                    }}
                    style={{ width: `${TONAL.iconSize}px`, height: `${TONAL.iconSize}px`, display: 'inline-flex', flex: 'none' }}
                  >
                    {b.icon}
                  </span>
                  <span
                    ref={(el) => {
                      labelRefs.current[i] = el;
                    }}
                  >
                    {b.label}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        按住任一按钮：该钮宽 +15%（弹簧 1400/0.9），双邻各瞬时让位一半（前 ⌊n/2⌋、后 ⌊(n+1)⁄2⌋），首尾钮只向内侧展开
        （方向 END/START 有效上限减半）；邻钮让位受「文本布局宽保护」钳制，不会压缩文字。
      </p>
    </div>
  );
}

/* ======================= B. Connected MaterialButtonGroup ======================= */

interface ConnectedGroupProps {
  theme: M3ThemeTokens;
}

function ConnectedGroup({ theme }: ConnectedGroupProps) {
  const buttons: TonalButtonSpec[] = [
    { label: '复制', icon: <svg viewBox="0 0 24 24" width={TONAL.iconSize} height={TONAL.iconSize} fill="currentColor" aria-hidden="true"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1Zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Zm0 16H8V7h11v14Z" /></svg> },
    { label: '粘贴', icon: <svg viewBox="0 0 24 24" width={TONAL.iconSize} height={TONAL.iconSize} fill="currentColor" aria-hidden="true"><path d="M19 2h-4.18C14.4.84 13.3 0 12 0S9.6.84 9.18 2H5a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2Zm-7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm7 18H5V4h2v3h10V4h2v16Z" /></svg> },
    { label: '剪切', icon: <svg viewBox="0 0 24 24" width={TONAL.iconSize} height={TONAL.iconSize} fill="currentColor" aria-hidden="true"><path d="M9.64 7.64A3 3 0 1 0 6 9.92v4.16a3 3 0 1 0 2 0V13l7-7V3h4V1h-6.36L9.64 7.64ZM6 6a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm0 12a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm7.36-4.36L16 11.36V21h4v-2h-2v-9.36l-2.36-2.36L12.36 13.64Z" /></svg> },
  ];
  const containerColor = theme.secondaryContainer;
  const contentColor = theme.onSecondaryContainer;
  // Connected：innerCornerSize 8dp 静态（styles.xml L539）；首/尾外形 = 组形状 Corner.Full（pill）
  const radii = [`${TONAL.radiusPill}px 8px 8px ${TONAL.radiusPill}px`, '8px', `8px ${TONAL.radiusPill}px ${TONAL.radiusPill}px 8px`];

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
          B · Connected —— 连体内角
        </h4>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          spacing 2dp · innerCorner 8dp · sizeChange @null
        </span>
      </div>
      <div className="overflow-x-auto rounded-lg py-[10px]" style={{ backgroundColor: theme.surfaceContainerLow }}>
        <div
          className="mx-auto flex w-max min-w-full items-center justify-center px-4"
          style={{ gap: '2px' }} // m3_comp_button_group_connected_small_between_space 2dp
          role="group"
          aria-label="Connected MaterialButtonGroup 演示"
        >
          {buttons.map((b, i) => (
            <button
              key={b.label}
              type="button"
              style={{
                position: 'relative',
                height: `${TONAL.height}px`,
                background: 'transparent',
                padding: 0,
                border: 'none',
                flex: 'none',
                touchAction: 'manipulation',
              }}
            >
              <span
                aria-hidden="true"
                style={{
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  top: '4px',
                  bottom: '4px',
                  borderRadius: radii[i],
                  backgroundColor: containerColor,
                }}
              />
              <span
                style={{
                  position: 'relative',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: `${TONAL.gap}px`,
                  height: `${TONAL.surfaceHeight}px`,
                  padding: `0 ${TONAL.padX}px`,
                  fontSize: '14px',
                  lineHeight: '20px',
                  fontWeight: 500,
                  color: contentColor,
                  whiteSpace: 'nowrap',
                }}
              >
                <span style={{ width: `${TONAL.iconSize}px`, height: `${TONAL.iconSize}px`, display: 'inline-flex', flex: 'none' }}>
                  {b.icon}
                </span>
                {b.label}
              </span>
            </button>
          ))}
        </div>
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        组形状 Corner.Full 只作用于首/尾钮的外侧两角；面向邻钮的角一律被 innerCornerSize 8dp 覆盖
        （updateChildShapes L639-701）。Connected 样式 buttonSizeChange=@null——按压不展开，这是源码行为而非缺失。
      </p>
    </div>
  );
}

/* ======================= C. Expressive MaterialButtonToggleGroup（分段） ======================= */

const SEGMENT = {
  height: 48, // 触达盒：视觉 40dp + inset 4dp×2
  surfaceHeight: 40, // 10dp padding ×2 + 内容 20dp
  padX: 16, // m3_comp_button_small_leading/trailing_space
  radiusPill: 20, // Corner.Full 50% = 40dp 高之半
  radiusPressed: 8, // containerShapePressed = shapeAppearanceCornerSmall = 8dp
  radiusChecked: 12, // containerShapeChecked = shapeAppearanceCornerMedium = 12dp
  innerDefault: 8, // shapeCornerSizeSmall = 8dp
  innerPressed: 4, // shapeCornerSizeExtraSmall = 4dp
  innerChecked: 20, // 50% 相对角 = 40dp 高之半（选中段邻侧全圆 → 视觉“脱开”）
} as const;

interface SegmentSpringState {
  outer: SpringState; // 整钮四角中“外侧角”的圆角值（状态列表三态）
  inner: SpringState; // “邻侧角”圆角值（组 innerCornerSize 状态列表三态）
}

interface SegmentedGroupProps {
  theme: M3ThemeTokens;
}

function SegmentedGroup({ theme }: SegmentedGroupProps) {
  const labels = ['日', '周', '月'];
  const surfaceRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const [checkedIdx, setCheckedIdx] = useState<number | null>(1); // 初始勾选“周”
  const [pressedIdx, setPressedIdx] = useState<number | null>(null);
  const springs = useRef<Array<SegmentSpringState>>(
    labels.map((_, i) => ({
      outer: { value: SEGMENT.radiusPill, velocity: 0, target: SEGMENT.radiusPill },
      inner: { value: SEGMENT.innerDefault, velocity: 0, target: SEGMENT.innerDefault },
    }))
  );
  const rafRef = useRef<number | null>(null);
  const checkedRef = useRef<number | null>(1);
  const pressedRef = useRef<number | null>(null);

  // 目标圆角（状态列表逐项）
  const outerTargetFor = (i: number) => {
    if (pressedIdx === i) return SEGMENT.radiusPressed; // state_pressed → 8dp
    if (checkedIdx === i) return SEGMENT.radiusChecked; // checked → 12dp
    return SEGMENT.radiusPill; // 默认 Round（pill）
  };
  const innerTargetFor = (i: number) => {
    if (pressedIdx === i) return SEGMENT.innerPressed; // checkable+pressed → 4dp
    if (checkedIdx === i) return SEGMENT.innerChecked; // checked → 50%
    return SEGMENT.innerDefault; // 默认 8dp
  };

  const writeCorners = useCallback(() => {
    for (let i = 0; i < surfaceRefs.current.length; i++) {
      const el = surfaceRefs.current[i];
      if (!el) continue;
      const o = Math.round(springs.current[i].outer.value);
      const n = Math.round(springs.current[i].inner.value);
      if (i === 0) el.style.borderRadius = `${o}px ${n}px ${n}px ${o}px`;
      else if (i === surfaceRefs.current.length - 1) el.style.borderRadius = `${n}px ${o}px ${o}px ${n}px`;
      else el.style.borderRadius = `${n}px`;
    }
  }, []);

  const tick = useCallback(
    (now: number, last: number) => {
      const dt = Math.min((now - last) / 1000, 0.032);
      let active = false;
      for (const s of springs.current) {
        if (stepSpring(s.outer, dt, M3_SPRING_STANDARD_FAST, 0.05)) active = true;
        if (stepSpring(s.inner, dt, M3_SPRING_STANDARD_FAST, 0.05)) active = true;
      }
      writeCorners();
      if (active) rafRef.current = requestAnimationFrame((t) => tick(t, now));
      else {
        rafRef.current = null;
        writeCorners();
      }
    },
    [writeCorners]
  );

  const retarget = useCallback(() => {
    for (let i = 0; i < springs.current.length; i++) {
      springs.current[i].outer.target = outerTargetFor(i);
      springs.current[i].inner.target = innerTargetFor(i);
    }
    if (rafRef.current === null) rafRef.current = requestAnimationFrame((t) => tick(t, t - 16));
  }, [tick, checkedIdx, pressedIdx]);

  useEffect(() => {
    retarget();
  }, [retarget]);

  useEffect(
    () => () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    },
    []
  );

  /** checkInternal L476-497：singleSelection 勾选新项先清空其余；点击已选项取消勾选 */
  const onSelect = (i: number) => {
    setCheckedIdx((cur) => (cur === i ? null : i));
  };

  const setPressed = (i: number, pressed: boolean) => {
    setPressedIdx((cur) => (pressed ? i : cur === i ? null : cur));
    void checkedRef;
    void pressedRef;
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
          C · Expressive 分段按钮 —— 选中脱开 + 弹簧圆角形变
        </h4>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          inner 角 8/4/50% · 整钮角 pill/8/12dp · spring 1400/0.9
        </span>
      </div>
      <div className="overflow-x-auto rounded-lg py-[10px]" style={{ backgroundColor: theme.surfaceContainerLow }}>
        <div
          className="mx-auto flex w-max min-w-full items-center justify-center px-4"
          style={{ gap: '2px' }} // m3_comp_button_group_connected_small_between_space 2dp
          role="radiogroup"
          aria-label="Expressive MaterialButtonToggleGroup 分段演示（单选）"
        >
          {labels.map((label, i) => {
            const checked = checkedIdx === i;
            const pressed = pressedIdx === i;
            // m3expressive_button_outlined_background_color_selector / outline / foreground 三链
            const bg = checked ? theme.inverseSurface : 'transparent';
            const border = checked ? 'transparent' : theme.outlineVariant; // 1dp 描边
            const fg = checked ? theme.inverseOnSurface : theme.onSurfaceVariant;
            return (
              <button
                key={label}
                type="button"
                role="radio"
                aria-checked={checked}
                onPointerDown={() => setPressed(i, true)}
                onPointerUp={() => setPressed(i, false)}
                onPointerLeave={() => setPressed(i, false)}
                onPointerCancel={() => setPressed(i, false)}
                onClick={() => onSelect(i)}
                style={{
                  position: 'relative',
                  height: `${SEGMENT.height}px`,
                  background: 'transparent',
                  padding: 0,
                  border: 'none',
                  flex: 'none',
                  touchAction: 'manipulation',
                }}
              >
                <span
                  ref={(el) => {
                    surfaceRefs.current[i] = el;
                  }}
                  aria-hidden="true"
                  style={{
                    position: 'absolute',
                    left: 0,
                    right: 0,
                    top: '4px',
                    bottom: '4px',
                    borderRadius: `${SEGMENT.radiusPill}px`,
                    backgroundColor: bg,
                    border: `1px solid ${border}`, // m3_comp_button_small_outlined_outline_width 1dp
                    transition: 'none',
                  }}
                />
                <span
                  style={{
                    position: 'relative',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: `${SEGMENT.surfaceHeight}px`,
                    padding: `0 ${SEGMENT.padX}px`,
                    fontSize: '14px',
                    lineHeight: '20px',
                    fontWeight: 500,
                    color: fg,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        点击切换勾选（单选，点击已选项取消勾选——checkInternal L476-497，selectionRequired 默认 false）。
        勾选段：容器 colorSurfaceInverse、描边消失、邻侧角 50%（视觉“脱开”成胶囊）；按压段：整钮角 12→8dp、邻侧角 4dp，
        均为弹簧动画（Stateful ShapeAppearance 挂 cornerSpringForce，MaterialButton.java L347-349）。
      </p>
    </div>
  );
}

/* ======================= 演示卡片 ======================= */

export function MaterialButtonGroupDemo({ theme }: { theme: M3ThemeTokens }) {
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          MaterialButtonGroup 按钮组（M3 / M3 Expressive）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          MDC-Android 1.14.0 · button/MaterialButtonGroup.java · button_group_tokens.xml · xml/m3_button_group_child_size_change.xml
        </span>
      </div>

      <StandardGroup theme={theme} />
      <ConnectedGroup theme={theme} />
      <SegmentedGroup theme={theme} />

      <div className="space-y-1.5 border-t border-slate-100 dark:border-slate-800 pt-4 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          <span className="font-medium text-slate-600 dark:text-slate-300">诚实缺口：</span>
          ① 文本布局宽度保护使用 Web 端 label 实测宽近似源码 <code className="font-mono">getTextLayoutWidth()</code>；
          ② 圆角弹簧作用域为 Web 侧近似（源码弹簧挂于 MaterialShapeDrawable 内部）；
          ③ 涟漪未接入（Android 侧由 RippleDrawable 提供，同 SplitButton 说明）；
          ④ 溢出菜单/换行模式（OVERFLOW_MODE_MENU/WRAP）未移植。
        </p>
        <p>
          全部取值逐条可回溯至文件头注释所引源码路径与行号；(int) 截断与奇数补偿（前 ⌊n/2⌋、后 ⌊(n+1)⁄2⌋）按源码保留。
        </p>
      </div>
    </div>
  );
}
