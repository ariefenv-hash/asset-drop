"use client";
/**
 * M3 官方清单终局补齐 · 第 21 轮
 * ============================================================
 * 【对标基准】m3.material.io/components 当前官方清单 = 6 大类 36 项
 * （Buttons 8 · Date & time pickers 2 · Loading & progress 2 · Navigation 3 ·
 *  Sheets 2 · All other 19；第 21 轮审计重抓，实抓时 All other 含 Toolbars 19 项）。此前项目已覆盖 23 项；本文件补齐最后 12 项：
 *   App bars(TopAppBar) · Navigation bar · Navigation rail · Navigation drawer ·
 *   Bottom sheets · Side sheets · Search(SearchBar/SearchView) · Carousel ·
 *   Date pickers · Time pickers · FABs/Extended FABs · Lists
 * 至此官方 36 项全部落地（Button groups/Split/Segmented/FAB Menu/Toolbars 由
 * ExpressiveControlsGallery 承载，Icon buttons 在 M3CoreComponentsGallery 第 21 轮
 * 审计补齐，Sliders/Switch/Loading/Progress 由
 * 既有组件承载）。
 *
 * 【取证】全部 token 取自 MDC-Android 1.14.0 官方 AAR（dl.google.com 通道）
 *  res/values/values.xml 宏形态解析 + @dimen/@color/@macro 引用链解析到具体值，
 *  转储见 evidence/mdc-1.14.0-tokens/resolved-structural.txt（162 项 + 复核项）。
 *  值尾标注：✓ = AAR/token 逐行核实；◇ = tokens 未覆盖该项，按 M3 规范默认
 *  （如实标注，不冒充源码值）。
 *
 * 【主题映射】AAR 内 ?attr/colorXxx 引用按本项目 Monet HCT 动态主题映射：
 *  colorSurface* → theme.surface* · colorSecondaryContainer → theme.secondaryContainer
 *  等；?attr/textAppearance* → m3GalleryShared.TYPE（M3 字型刻度）。
 * ============================================================
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Archive,
  ArrowLeft,
  Bell,
  Bluetooth,
  ChevronLeft,
  ChevronRight,
  Clock,
  Home,
  Inbox,
  Keyboard,
  Mail,
  Menu,
  MoreVertical,
  Plus,
  Search,
  Star,
  User,
  Wifi,
  X,
} from '@/components/icons';
import { hexToRgbaWave, hexWithAlpha, M3ThemeTokens } from '../../aosp/dynamicColor';
import { AospRippleSurface } from './AospRippleSurface';
import { M3_SPRING_EXPRESSIVE_FAST, SpringState, stepSpring } from '../../aosp/spring';
import {
  Cell,
  errorColors,
  GalleryProps,
  SHAPE,
  SHADOW,
  STATE_LAYER,
  TYPE,
} from './m3GalleryShared';

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* ================= 1. App bars · TopAppBar（m3_comp_app_bar_*） =================
 * 高 64dp ✓ · 容器 surface ✓ · on-scroll 容器 surfaceContainer ✓ ·
 * elevation level0→level2 ✓ · medium 112dp / large 152dp ✓；
 * title titleLarge/onSurface、navigation icon onSurface、action onSurfaceVariant ◇。 */
function TopAppBarDemo({ theme }: { theme: M3ThemeTokens }) {
  const [scrolled, setScrolled] = useState(false);
  const rows = ['WLAN 与网络', '蓝牙与设备', '应用管理', '通知与状态栏', '电池与性能', '存储与备份', '安全与隐私', '辅助功能'];
  return (
    <div className="space-y-3">
      <div className="overflow-hidden rounded-lg border" style={{ borderColor: theme.outlineVariant }}>
        <div
          className="flex items-center gap-4 px-4"
          style={{
            height: 64, /* ✓ m3_comp_app_bar_small_container_height */
            backgroundColor: scrolled ? theme.surfaceContainer : theme.surface,
            boxShadow: scrolled ? SHADOW.level2 : 'none', /* level0→level2 ✓ */
            transition: 'background-color 200ms, box-shadow 200ms',
          }}
        >
          <Menu style={{ width: 24, height: 24, color: theme.onSurface }} />
          <span style={{ ...TYPE.titleLarge, color: theme.onSurface }}>设置</span>
          <div className="ml-auto flex items-center gap-6">
            <Search style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
            <MoreVertical style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
          </div>
        </div>
        <div className="h-56 overflow-y-auto" onScroll={(e) => setScrolled(e.currentTarget.scrollTop > 8)}>
          {rows.map((r) => (
            <div key={r} className="px-4 py-3" style={{ ...TYPE.bodyMedium, color: theme.onSurface, borderBottom: `1px solid ${theme.outlineVariant}` }}>
              {r}
            </div>
          ))}
        </div>
      </div>
      <p className="text-[11px] leading-relaxed" style={{ color: theme.onSurfaceVariant }}>
        滚动右侧列表：容器色 surface→surfaceContainer、海拔 level0→level2（3dp）。medium 形制 112dp / large 152dp 同样取自 AAR。
      </p>
    </div>
  );
}

/* ================= 2. Navigation bar（m3_comp_nav_bar_*） =================
 * 高 64dp ✓（1.14.0 Expressive 值）· 容器 surfaceContainer ✓ · elevation level2=3dp ✓ ·
 * 纵向指示条 56×32dp ✓ · 图标 24dp ✓ · active icon onSecondaryContainer ✓ /
 * inactive onSurfaceVariant ✓ · active 标签 colorSecondary ✓ / inactive onSurfaceVariant ✓ ·
 * 标签 labelMedium ✓ · 项间距 6dp ✓ · state layer onSecondaryContainer@0.08/0.1 ✓。 */
function NavigationBarDemo({ theme, err }: { theme: M3ThemeTokens; err: { error: string; onError: string } }) {
  const [sel, setSel] = useState(0);
  const [hover, setHover] = useState(-1);
  const items = [
    { icon: Home, label: '首页' },
    { icon: Search, label: '探索' },
    { icon: Star, label: '收藏', badge: '99+' },
    { icon: User, label: '我的' },
  ];
  return (
    <div className="space-y-3">
      <div className="overflow-hidden rounded-lg" style={{ backgroundColor: theme.surfaceContainer, boxShadow: SHADOW.level2 }}>
        <div className="flex" style={{ height: 64 }}>
          {items.map((it, i) => {
            const active = i === sel;
            return (
              <button
                key={it.label}
                type="button"
                onClick={() => setSel(i)}
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(-1)}
                className="relative flex flex-1 cursor-pointer flex-col items-center justify-center gap-1"
              >
                {/* 第 25 轮（用户复核）：激活胶囊/hover 层/角标改锚定到精确 24×24 图标盒 ——
                    旧写法胶囊绝对定位静态居中在整个按钮上，而“图标+下方文字”整组居中后
                    图标被文字挤高（内联 svg 基线排版又额外上浮），胶囊与角标都对不准图标。
                    现胶囊中心 = 图标中心（与 M3 “指示条裹住图标”一致），不受下方文字影响 */}
                <span className="relative flex shrink-0 items-center justify-center" style={{ width: 24, height: 24 }}>
                  <span
                    className="absolute left-1/2 top-1/2 rounded-full transition-all duration-200"
                    style={{
                      width: 56, height: 32, /* ✓ vertical indicator 56×32 */
                      backgroundColor: theme.secondaryContainer,
                      opacity: active ? 1 : 0,
                      transform: `translate(-50%, -50%) scale(${active ? 1 : 0.7})`,
                    }}
                  />
                  {(hover === i) && (
                    <span
                      className="absolute left-1/2 top-1/2 rounded-full"
                      style={{ width: 56, height: 32, transform: 'translate(-50%, -50%)', backgroundColor: hexWithAlpha(theme.onSecondaryContainer, STATE_LAYER.hover) }}
                    />
                  )}
                  <it.icon className="relative block" style={{ width: 24, height: 24, color: active ? theme.onSecondaryContainer : theme.onSurfaceVariant }} />
                  {it.badge && (
                    <span
                      className="absolute flex items-center justify-center rounded-full"
                      style={{ minWidth: 16, height: 16, top: -4, right: -8, backgroundColor: err.error, color: err.onError, fontSize: 11, lineHeight: '12px', fontWeight: 500, paddingInline: 4 }}
                    >
                      {it.badge}
                    </span>
                  )}
                </span>
                <span className="relative" style={{ ...TYPE.labelMedium, color: active ? theme.secondary : theme.onSurfaceVariant }}>
                  {it.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <p className="text-[11px] leading-relaxed" style={{ color: theme.onSurfaceVariant }}>
        高 64dp（m3_comp_nav_bar_container_height，1.14.0 Expressive 值）· 指示条 56×32dp 胶囊 · badge 与导航项联动。
      </p>
    </div>
  );
}

/* ================= 3. Navigation rail（m3_comp_nav_rail_*） =================
 * 窄宽 80dp ✓ / 96dp 宽变体 ✓ · 顶部空间 44dp ✓ · 项容器高 64dp ✓ · 项间 6dp ✓ ·
 * 纵向指示条 56×32dp ✓ · 图标 24dp ✓ · 图标-标签距 4dp ✓ · 标签 labelMedium ✓ ·
 * expanded 宽 220–360dp ✓ · 横向指示条高 56dp ✓ · 图标-标签距 8dp ✓ · 标签 labelLarge ✓ ·
 * 容器 surface ✓ elevation 0 ✓；头部 FAB primary 形制 ✓（见 FAB 单元）。 */
function NavigationRailDemo({ theme, err }: { theme: M3ThemeTokens; err: { error: string; onError: string } }) {
  const [sel, setSel] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [hover, setHover] = useState(-1);
  const items = [
    { icon: Home, label: '首页', badge: '99+' },
    { icon: Search, label: '探索' },
    { icon: User, label: '我的' },
  ];
  const railW = expanded ? 280 : 80; /* expanded ∈ [220,360] ✓ */
  return (
    <div className="space-y-3">
      <div className="flex overflow-hidden rounded-lg border" style={{ borderColor: theme.outlineVariant, height: 296 }}>
        <div className="flex flex-col items-center" style={{ width: railW, backgroundColor: theme.surface, transition: 'width 250ms cubic-bezier(0.2,0,0,1)', boxShadow: 'none' }}>
          {/* 头部：FAB small 40dp（m3_comp_fab_small_container_height ✓ · primary/onPrimary ✓ · shape lg 16 ✓ · elevation level3 ✓） */}
          <div style={{ height: 44 }} /> {/* ✓ collapsed_top_space */}
          <button
            type="button"
            aria-label="新建"
            className="flex items-center justify-center"
            style={{ width: 40, height: 40, borderRadius: SHAPE.large, backgroundColor: theme.primary, color: theme.onPrimary, boxShadow: SHADOW.level3 }}
          >
            <Plus style={{ width: 24, height: 24 }} />
          </button>
          <div style={{ height: 24 }} />
          {items.map((it, i) => {
            const active = i === sel;
            return (
              <button
                key={it.label}
                type="button"
                onClick={() => setSel(i)}
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(-1)}
                className="relative flex cursor-pointer flex-col items-center justify-center"
                style={{ height: 64, width: railW, gap: expanded ? 0 : 4 }}
              >
                {expanded ? (
                  <span className="relative flex items-center" style={{ gap: 8, height: 56, borderRadius: SHAPE.full, paddingInline: 16, backgroundColor: active ? theme.secondaryContainer : 'transparent' }}>
                    {hover === i && <span className="absolute inset-0 rounded-full" style={{ backgroundColor: hexWithAlpha(theme.onSecondaryContainer, STATE_LAYER.hover) }} />}
                    {/* 第 25 轮：图标盒化（精确 24×24），横向胶囊内角标锚定到图标本体 */}
                    <span className="relative flex shrink-0 items-center justify-center" style={{ width: 24, height: 24 }}>
                      <it.icon className="block" style={{ width: 24, height: 24, color: active ? theme.onSecondaryContainer : theme.onSurfaceVariant }} />
                      {it.badge && (
                        <span
                          className="absolute flex items-center justify-center rounded-full"
                          style={{ minWidth: 16, height: 16, top: -4, right: -8, backgroundColor: err.error, color: err.onError, fontSize: 11, lineHeight: '12px', fontWeight: 500, paddingInline: 4 }}
                        >
                          {it.badge}
                        </span>
                      )}
                    </span>
                    <span className="relative" style={{ ...TYPE.labelLarge, color: active ? theme.secondary : theme.onSurfaceVariant }}>{it.label}</span>
                  </span>
                ) : (
                  <>
                    {/* 第 25 轮（用户复核）：同 NavigationBarDemo —— 胶囊/hover/角标锚定到
                        精确 24×24 图标盒，不再被下方文字挤偏 */}
                    <span className="relative flex shrink-0 items-center justify-center" style={{ width: 24, height: 24 }}>
                      <span
                        className="absolute left-1/2 top-1/2 rounded-full transition-all duration-200"
                        style={{ width: 56, height: 32, backgroundColor: theme.secondaryContainer, opacity: active ? 1 : 0, transform: `translate(-50%, -50%) scale(${active ? 1 : 0.7})` }}
                      />
                      {hover === i && <span className="absolute left-1/2 top-1/2 rounded-full" style={{ width: 56, height: 32, transform: 'translate(-50%, -50%)', backgroundColor: hexWithAlpha(theme.onSecondaryContainer, STATE_LAYER.hover) }} />}
                      <it.icon className="relative block" style={{ width: 24, height: 24, color: active ? theme.onSecondaryContainer : theme.onSurfaceVariant }} />
                      {it.badge && (
                        <span
                          className="absolute flex items-center justify-center rounded-full"
                          style={{ minWidth: 16, height: 16, top: -4, right: -8, backgroundColor: err.error, color: err.onError, fontSize: 11, lineHeight: '12px', fontWeight: 500, paddingInline: 4 }}
                        >
                          {it.badge}
                        </span>
                      )}
                    </span>
                    <span style={{ ...TYPE.labelMedium, color: active ? theme.secondary : theme.onSurfaceVariant }}>{it.label}</span>
                  </>
                )}
              </button>
            );
          })}
        </div>
        <div className="flex flex-1 items-center justify-center text-xs" style={{ color: theme.onSurfaceVariant, backgroundColor: theme.surfaceContainerLowest }}>
          内容宿主区（rail 停靠左侧，点击切换 折叠/展开 形制）
        </div>
      </div>
      <button type="button" onClick={() => setExpanded((v) => !v)} className="rounded-full border px-4 py-1.5 text-xs font-medium" style={{ borderColor: theme.outlineVariant, color: theme.onSurface }}>
        切换 {expanded ? '折叠（80dp 窄轨）' : '展开（280dp 宽轨）'}
      </button>
    </div>
  );
}

/* ================= 4. Navigation drawer（m3_comp_navigation_drawer_*） =================
 * 宽 360dp ✓ · 图标 24dp ✓ · modal 容器 surfaceContainerLow ✓ elevation level1 ✓ ·
 * standard elevation 0 ✓ · 布局圆角 16dp ✓（m3_navigation_drawer_layout_corner_size）·
 * headline titleSmall/onSurfaceVariant ✓ · 标签 labelLarge ✓ · active 胶囊 secondaryContainer ✓
 * 文字 onSecondaryContainer ✓ / inactive onSurfaceVariant ✓ · item inset 12dp ✓；
 * active 指示条高 56dp 与 modal scrim 32% ◇（规范默认）。 */
function NavigationDrawerDemo({ theme, err }: { theme: M3ThemeTokens; err: { error: string; onError: string } }) {
  const [sel, setSel] = useState(0);
  const [modal, setModal] = useState(false);
  const items = [
    { icon: Inbox, label: '收件箱', badge: '99+' },
    { icon: Mail, label: '已发送' },
    { icon: Archive, label: '归档' },
    { icon: Bell, label: '提醒' },
  ];
  const itemBtn = (Icon: typeof Inbox, label: string, i: number, badge?: string) => {
    const active = i === sel;
    /* 第 25 轮（用户复核）：去掉 w-full —— 100% 宽 + marginInline 12 会把条目盒
     * 撑到容器宽 +24px，滚动容器出现 12px 横向溢出（抽屉"能左右滑"的真根因之一）；
     * 块级 flex 宽度 auto 自动填充扣除边距后的净宽，scrollWidth == clientWidth */
    return (
      <button
        key={label}
        type="button"
        onClick={() => { setSel(i); setModal(false); }}
        onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = hexWithAlpha(active ? theme.onSecondaryContainer : theme.onSurface, STATE_LAYER.hover); }}
        onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = active ? theme.secondaryContainer : 'transparent'; }}
        className="relative flex cursor-pointer items-center"
        style={{
          height: 56, /* ◇ M3 规范默认（tokens 未含几何） */
          borderRadius: SHAPE.full,
          marginInline: 12, /* ✓ m3_navigation_item_shape_inset_start/end */
          paddingInline: 16,
          gap: 12,
          backgroundColor: active ? theme.secondaryContainer : 'transparent',
        }}
      >
        {/* 第 25 轮（用户复核）：图标盒化（精确 24×24 + svg block），内联 svg 的基线排版
            会让图标相对包裹盒上浮，角标因此对不准图标顶角；盒化后角标锚点恒定 */}
        <span className="relative flex shrink-0 items-center justify-center" style={{ width: 24, height: 24 }}>
          <Icon size={24} strokeWidth={2} className="block" style={{ width: 24, height: 24, color: active ? theme.onSecondaryContainer : theme.onSurfaceVariant }} />
          {badge && (
            <span className="absolute flex items-center justify-center rounded-full" style={{ minWidth: 16, height: 16, top: -4, right: -8, backgroundColor: err.error, color: err.onError, fontSize: 11, lineHeight: '12px', fontWeight: 500, paddingInline: 4 }}>
              {badge}
            </span>
          )}
        </span>
        <span style={{ ...TYPE.labelLarge, color: active ? theme.onSecondaryContainer : theme.onSurfaceVariant }}>{label}</span>
      </button>
    );
  };
  const drawerBody = (
    <div className="flex flex-col" style={{ width: 360, maxWidth: '100%', paddingBlock: 12 }}>
      <span className="px-7 py-2" style={{ ...TYPE.titleSmall, color: theme.onSurfaceVariant }}>常规</span>
      {items.map((it, i) => itemBtn(it.icon, it.label, i, it.badge))}
      <div style={{ height: 1, backgroundColor: theme.outlineVariant, marginInline: 28, marginBlock: 8 }} />
      <span className="px-7 py-2" style={{ ...TYPE.titleSmall, color: theme.onSurfaceVariant }}>空间</span>
      {[{ icon: Star, label: '已加星标' }, { icon: Clock, label: '最近' }].map((it, i) => itemBtn(it.icon, it.label, i + 4))}
    </div>
  );
  return (
    <div className="relative space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => setModal(true)} className="rounded-full border px-4 py-1.5 text-xs font-medium" style={{ borderColor: theme.outlineVariant, color: theme.onSurface }}>
          打开 modal 抽屉（scrim + 滑入）
        </button>
        <span className="text-[11px] font-mono" style={{ color: theme.onSurfaceVariant }}>modal: surfaceContainerLow ✓ · elevation level1 ✓ · layout 圆角 16dp ✓</span>
      </div>
      {/* standard：内联同台展示。第 25 轮（用户复核）：滚动容器补 overflow-x hidden ——
          仅写 overflowY:'auto' 时水平轴按 CSS 规范被计算为 auto，触屏上抽屉能左右横滑；
          改 'hidden auto' + touchAction pan-y + overscrollBehavior contain，只保留纵向滚动 */}
      <div className="overflow-hidden rounded-lg border" style={{ borderColor: theme.outlineVariant, display: 'flex', height: 300 }}>
        <div
          style={{
            width: 360, /* ✓ m3_comp_navigation_drawer_container_width */
            maxWidth: '100%',
            minWidth: 0,
            backgroundColor: theme.surfaceContainerLow,
            boxShadow: 'none',
            overflow: 'hidden auto',
            overscrollBehavior: 'contain',
            touchAction: 'pan-y',
          }}
        >
          {drawerBody}
        </div>
        <div className="flex flex-1 items-center justify-center text-xs" style={{ color: theme.onSurfaceVariant, backgroundColor: theme.surfaceContainerLowest }}>
          内容宿主区（standard 抽屉停靠左侧 · elevation level0 ✓）
        </div>
      </div>
      {/* modal：卡片内 overlay（不破坏页面滚动语义）；同修横向滑动问题 */}
      {modal && (
        <div className="absolute inset-0 z-40 flex" style={{ backgroundColor: 'rgba(0,0,0,0.32)' }} onClick={() => setModal(false)}>
          <div
            className="h-full overflow-y-auto overflow-x-hidden"
            style={{
              maxWidth: '100%',
              backgroundColor: theme.surfaceContainerLow,
              boxShadow: SHADOW.level1,
              borderRadius: '0 16px 16px 0',
              animation: 'drawer-in 260ms cubic-bezier(0.05,0.7,0.1,1)',
              overscrollBehavior: 'contain',
              touchAction: 'pan-y',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {drawerBody}
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= 5. Bottom sheets（m3_comp_sheet_bottom_docked_*） =================
 * 容器 surfaceContainerLow ✓ · 顶部圆角 28dp ✓（shapeAppearanceCornerExtraLarge）·
 * 拖拽把手 32×4dp ✓ 色 onSurfaceVariant ✓ · 把手下边距 20dp ✓ · elevation level1 ✓；
 * 锚点 half=0.5 为 BottomSheetBehavior halfExpandedRatio 默认 ✓，peek/expanded 随容器 ◇；
 * 手势锚定与 fling 为 Web 转译 ◇（行为值来自 Behavior 语义，非 token）。 */
const SHEET_ANCHORS = [0.32, 0.5, 0.86] as const;
const SHEET_ANCHOR_NAMES = ['peek（折叠）', 'half（半展）', 'expanded（全展）'] as const;

function useSheetDrag() {
  const [fraction, setFraction] = useState<number>(SHEET_ANCHORS[1]);
  const springRef = useRef<SpringState>({ value: SHEET_ANCHORS[1], velocity: 0, target: SHEET_ANCHORS[1] });
  const rafRef = useRef<number | null>(null);
  const dragRef = useRef<{ startY: number; startF: number; lastY: number; lastT: number; v: number } | null>(null);
  const stageHRef = useRef(1);

  const animateTo = useCallback((target: number, velocity = 0) => {
    springRef.current.target = target;
    springRef.current.velocity = velocity;
    if (rafRef.current !== null) return;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      const alive = stepSpring(springRef.current, dt, M3_SPRING_EXPRESSIVE_FAST);
      springRef.current.value = clamp(springRef.current.value, 0.18, 1);
      setFraction(springRef.current.value);
      if (alive) rafRef.current = requestAnimationFrame(tick);
      else rafRef.current = null;
    };
    rafRef.current = requestAnimationFrame(tick);
  }, []);

  const nearest = (f: number) =>
    SHEET_ANCHORS.reduce((a, b) => (Math.abs(b - f) < Math.abs(a - f) ? b : a));

  const onPointerDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    if (rafRef.current !== null) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    dragRef.current = { startY: e.clientY, startF: springRef.current.value, lastY: e.clientY, lastT: performance.now(), v: 0 };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d) return;
    const f = clamp(d.startF - (e.clientY - d.startY) / stageHRef.current, 0.18, 1);
    springRef.current.value = f;
    setFraction(f);
    const now = performance.now();
    d.v = ((d.lastY - e.clientY) / Math.max(1, now - d.lastT)) / stageHRef.current;
    d.lastY = e.clientY;
    d.lastT = now;
  };
  const onPointerUp = () => {
    const d = dragRef.current;
    if (!d) return;
    dragRef.current = null;
    const v = d.v * 1000; /* fraction/s */
    const predicted = springRef.current.value + v * 0.12; /* fling 预测 ◇ */
    animateTo(nearest(predicted), v);
  };

  return { fraction, setFraction, animateTo, nearest, onPointerDown, onPointerMove, onPointerUp, stageHRef, springRef };
}

function SheetChrome({ theme, fraction, drag, label }: {
  theme: M3ThemeTokens;
  fraction: number;
  drag: { onPointerDown: (e: React.PointerEvent) => void; onPointerMove: (e: React.PointerEvent) => void; onPointerUp: () => void };
  label: string;
}) {
  return (
    <div
      className="absolute inset-x-0 bottom-0 flex flex-col"
      style={{
        height: `${fraction * 100}%`,
        backgroundColor: theme.surfaceContainerLow,
        borderRadius: '28px 28px 0 0',
        boxShadow: SHADOW.level1,
        touchAction: 'none',
      }}
      onPointerDown={drag.onPointerDown}
      onPointerMove={drag.onPointerMove}
      onPointerUp={drag.onPointerUp}
    >
      {/* 拖拽把手 32×4dp ✓ · 下边距 20dp ✓ · 色 onSurfaceVariant ✓ */}
      <div className="flex cursor-grab flex-col items-center pt-3 pb-5" data-handle>
        <span style={{ width: 32, height: 4, borderRadius: 2, backgroundColor: theme.onSurfaceVariant }} />
      </div>
      <div className="flex-1 overflow-y-auto px-6">
        <div style={{ ...TYPE.titleLarge, color: theme.onSurface }}>快照内容</div>
        <p className="mt-2" style={{ ...TYPE.bodyMedium, color: theme.onSurfaceVariant }}>
          上下拖拽把手或面板：释放后吸附最近锚点（弹簧复用项目 spring 引擎 · M3_EXPRESSIVE_FAST k=800 ζ=0.6）。
        </p>
        {['WLAN 与网络', '蓝牙与设备', '应用管理', '电池与性能'].map((r) => (
          <div key={r} className="py-3" style={{ ...TYPE.bodyLarge, color: theme.onSurface, borderBottom: `1px solid ${theme.outlineVariant}` }}>{r}</div>
        ))}
      </div>
      <div className="px-6 pb-3 text-[11px] font-mono" style={{ color: theme.onSurfaceVariant }}>锚点：{label}</div>
    </div>
  );
}

function BottomSheetDemo({ theme }: { theme: M3ThemeTokens }) {
  const std = useSheetDrag();
  const modal = useSheetDrag();
  const [modalOpen, setModalOpen] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);
  useEffect(() => { if (stageRef.current) std.stageHRef.current = stageRef.current.clientHeight; }, [std.stageHRef]);
  const modalStageRef = useRef<HTMLDivElement>(null);
  useEffect(() => { if (modalStageRef.current) modal.stageHRef.current = modalStageRef.current.clientHeight; }, [modal.stageHRef, modalOpen]);
  // modal：拖到 peek 以下（<0.26）→ 关闭（Behavior 语义：peek 下滑关闭）
  const modalUp = () => {
    if (modal.springRef.current.value < 0.26) { setModalOpen(false); return; }
    modal.onPointerUp();
  };
  return (
    <div className="space-y-3">
      <button type="button" onClick={() => { setModalOpen(true); modal.animateTo(SHEET_ANCHORS[1]); }} className="rounded-full px-5 py-2 text-xs font-medium" style={{ backgroundColor: theme.primary, color: theme.onPrimary }}>
        打开 modal 快照（含 scrim）
      </button>
      {/* standard：内联舞台 */}
      <div ref={stageRef} className="relative overflow-hidden rounded-lg border" style={{ borderColor: theme.outlineVariant, height: 280 }}>
        <div className="absolute inset-0 flex items-start justify-center pt-4 text-xs" style={{ color: theme.onSurfaceVariant, backgroundColor: theme.surfaceContainerLowest }}>
          共享内容层（standard sheet 停靠底部 · elevation level1 ✓ · 无 scrim）
        </div>
        <SheetChrome theme={theme} fraction={std.fraction} drag={std} label={SHEET_ANCHOR_NAMES[SHEET_ANCHORS.indexOf(std.nearest(std.fraction) as typeof SHEET_ANCHORS[number])]} />
      </div>
      {/* modal：fixed overlay */}
      {modalOpen && (
        <div className="fixed inset-0 z-[60]">
          <div className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.32)' }} onClick={() => setModalOpen(false)} />
          <div ref={modalStageRef} className="absolute inset-0">
            <SheetChrome theme={theme} fraction={modal.fraction} drag={{ ...modal, onPointerUp: modalUp }} label={SHEET_ANCHOR_NAMES[SHEET_ANCHORS.indexOf(modal.nearest(modal.fraction) as typeof SHEET_ANCHORS[number])]} />
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= 6. Side sheets（m3_comp_sheet_side_docked_*） =================
 * 宽 256dp ✓ · modal 容器 surfaceContainerLow ✓ 形状 cornerLarge(16dp) ✓ elevation level1 ✓ ·
 * standard 容器 surface ✓ elevation 0 ✓ · detached 边距 16dp ✓；
 * 分隔线 outlineVariant 与滑入曲线 ◇（规范默认）。 */
function SideSheetDemo({ theme }: { theme: M3ThemeTokens }) {
  const [open, setOpen] = useState(false);
  const [dx, setDx] = useState(0);
  const dragRef = useRef<{ startX: number } | null>(null);
  const onDown = (e: React.PointerEvent) => { (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId); dragRef.current = { startX: e.clientX }; };
  const onMove = (e: React.PointerEvent) => { if (dragRef.current) setDx(Math.max(0, e.clientX - dragRef.current.startX)); };
  const onUp = () => { const d = dragRef.current; dragRef.current = null; if (d && dx > 96) setOpen(false); else setDx(0); };
  return (
    <div className="space-y-3">
      <button type="button" onClick={() => { setOpen(true); setDx(0); }} className="rounded-full border px-4 py-1.5 text-xs font-medium" style={{ borderColor: theme.outlineVariant, color: theme.onSurface }}>
        打开侧边快照
      </button>
      <div className="relative overflow-hidden rounded-lg border" style={{ borderColor: theme.outlineVariant, height: 300 }}>
        <div className="absolute inset-0 flex items-start justify-center pt-4 text-xs" style={{ color: theme.onSurfaceVariant, backgroundColor: theme.surfaceContainerLowest }}>
          内容宿主区（侧边快照从 end 边滑入）
        </div>
        {open && (
          <>
            <div className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.32)' }} onClick={() => setOpen(false)} />
            <div
              className="absolute flex flex-col overflow-hidden"
              style={{
                top: 16, right: 16, bottom: 16, /* ✓ m3_side_sheet_margin_detached */
                width: 256, /* ✓ m3_comp_sheet_side_docked_container_width */
                backgroundColor: theme.surfaceContainerLow,
                borderRadius: 16, /* ✓ modal shape cornerLarge */
                boxShadow: SHADOW.level1, /* ✓ elevation level1 */
                borderLeft: `1px solid ${theme.outlineVariant}`, /* ◇ 分隔线（规范默认） */
                transform: `translateX(${dx}px)`,
                transition: dragRef.current ? 'none' : 'transform 240ms cubic-bezier(0.05,0.7,0.1,1)',
                touchAction: 'none',
              }}
              onPointerDown={onDown}
              onPointerMove={onMove}
              onPointerUp={onUp}
            >
              <div className="flex items-center justify-between px-4 py-3">
                <span style={{ ...TYPE.titleMedium, color: theme.onSurface }}>侧边快照</span>
                <button type="button" aria-label="关闭" onClick={() => setOpen(false)}>
                  <X style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
                </button>
              </div>
              {['账户与同步', '隐私保护', '备份与恢复', '开发者选项'].map((r) => (
                <div key={r} className="flex items-center justify-between px-4 py-3" style={{ ...TYPE.bodyLarge, color: theme.onSurface, borderTop: `1px solid ${theme.outlineVariant}` }}>
                  {r}
                  <ChevronRight style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
                </div>
              ))}
              <div className="mt-auto px-4 pb-3 text-[11px] font-mono" style={{ color: theme.onSurfaceVariant }}>向右拖拽可关闭（阈值 96px ◇）</div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ================= 7. Search（m3_comp_search_bar_* / m3_comp_search_view_*） =================
 * SearchBar：高 56dp ✓ · 容器 surfaceContainerHigh ✓ · elevation level3=6dp ✓ ·
 * 头像 30dp ✓ · 图标 24dp ✓ · 支撑文字 bodyLarge/onSurfaceVariant ✓；
 * SearchView（docked）：头部高 56dp ✓ · 头部-结果距 2dp ✓ · 结果容器形制 cornerMedium(12dp) ✓ ·
 * 分隔线 outline ✓ · 输入 bodyLarge/onSurface ✓；bar 全圆角形制 ◇（样式层值）；
 * 结果项图标/文字颜色 ◇（规范默认）。 */
const SEARCH_ITEMS = [
  { icon: Wifi, text: 'WLAN 设置' },
  { icon: Bluetooth, text: '蓝牙与设备配对' },
  { icon: Bell, text: '通知与状态栏' },
  { icon: Clock, text: '日期与时间' },
  { icon: User, text: '账户与同步' },
  { icon: Home, text: '主屏幕与壁纸' },
];
function SearchDemo({ theme }: { theme: M3ThemeTokens }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const filtered = SEARCH_ITEMS.filter((i) => i.text.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <div className="space-y-3">
      {/* SearchBar（56dp ✓ · 全圆角 ◇ · elevation level3 ✓） */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center gap-4 pr-3"
        style={{ height: 56, borderRadius: SHAPE.full, backgroundColor: theme.surfaceContainerHigh, boxShadow: SHADOW.level3 }}
      >
        <span className="pl-4">
          <Search style={{ width: 24, height: 24, color: theme.onSurface }} />
        </span>
        <span className="flex-1 text-left" style={{ ...TYPE.bodyLarge, color: theme.onSurfaceVariant }}>搜索设置项…</span>
        <span className="flex items-center justify-center rounded-full" style={{ width: 30, height: 30, backgroundColor: theme.tertiaryContainer, color: theme.onTertiaryContainer }}>
          <User style={{ width: 16, height: 16 }} />
        </span>
      </button>
      <p className="text-[11px] font-mono" style={{ color: theme.onSurfaceVariant }}>↑ SearchBar：56dp ✓ · surfaceContainerHigh ✓ · elevation level3(6dp) ✓ · avatar 30dp ✓ · 圆角 ◇</p>

      {/* SearchView（docked 形制） */}
      {open && (
        <div className="fixed inset-0 z-[60] flex items-start justify-center p-4 sm:p-8" style={{ backgroundColor: 'rgba(0,0,0,0.32)' }} onClick={() => setOpen(false)}>
          <div className="w-full max-w-[560px]" onClick={(e) => e.stopPropagation()}>
            {/* 头部 56dp ✓ */}
            <div className="flex items-center gap-4 px-2" style={{ height: 56, backgroundColor: theme.surfaceContainerHigh, borderRadius: SHAPE.full }}>
              <button type="button" aria-label="返回" onClick={() => setOpen(false)}>
                <ArrowLeft style={{ width: 24, height: 24, color: theme.onSurface }} />
              </button>
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="搜索设置项…"
                className="h-full flex-1 bg-transparent outline-none"
                style={{ ...TYPE.bodyLarge, color: theme.onSurface }}
              />
              {q && (
                <button type="button" aria-label="清空" onClick={() => setQ('')}>
                  <X style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
                </button>
              )}
            </div>
            {/* 头部-结果距 2dp ✓ · 结果容器形制 cornerMedium ✓ */}
            <div className="mt-0.5 overflow-hidden" style={{ borderRadius: SHAPE.medium, backgroundColor: theme.surfaceContainerHigh, boxShadow: SHADOW.level3 }}>
              {filtered.length === 0 ? (
                <div className="px-4 py-6 text-center" style={{ ...TYPE.bodyMedium, color: theme.onSurfaceVariant }}>无匹配结果</div>
              ) : (
                filtered.map((it) => (
                  <button
                    key={it.text}
                    type="button"
                    className="flex w-full items-center gap-4 px-4 py-3 text-left"
                    style={{ ...TYPE.bodyLarge, color: theme.onSurface, borderTop: `1px solid ${theme.outline}` }}
                    onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = hexWithAlpha(theme.onSurface, STATE_LAYER.hover); }}
                    onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                  >
                    <it.icon style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
                    {it.text}
                  </button>
                ))
              )}
            </div>
            <p className="mt-2 text-[11px] font-mono" style={{ color: theme.onSurfaceVariant }}>SearchView docked：header 56dp ✓ · gap 2dp ✓ · results 形制 12dp ✓ · divider outline ✓</p>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= 8. Carousel（m3_carousel_*） =================
 * 小项 40–56dp ✓ · 超小项 10dp ✓ · 消失项 1dp ✓ · 小项圆角 28dp ✓；
 * 焦点项尺寸比、项间距 4dp、焦点圆角 16dp、fling 吸附为 Strategy/规范行为值 ◇；
 * 项容器颜色未 token 化 ◇（取主题容器色系示意）。 */
const CAROUSEL_COLORS = 3;
function CarouselDemo({ theme }: { theme: M3ThemeTokens }) {
  const N = 7;
  const stageRef = useRef<HTMLDivElement>(null);
  const [stageW, setStageW] = useState(0);
  const [center, setCenter] = useState(1);
  const springRef = useRef<SpringState>({ value: 1, velocity: 0, target: 1 });
  const rafRef = useRef<number | null>(null);
  const dragRef = useRef<{ startX: number; startC: number; lastX: number; lastT: number; v: number } | null>(null);
  const [dragging, setDragging] = useState(false);

  const animateTo = useCallback((target: number, velocity = 0) => {
    springRef.current.target = clamp(target, 0, N - 1);
    springRef.current.velocity = velocity;
    if (rafRef.current !== null) return;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      const alive = stepSpring(springRef.current, dt, M3_SPRING_EXPRESSIVE_FAST);
      setCenter(springRef.current.value);
      if (alive) rafRef.current = requestAnimationFrame(tick);
      else rafRef.current = null;
    };
    rafRef.current = requestAnimationFrame(tick);
  }, []);

  const onDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    if (rafRef.current !== null) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    dragRef.current = { startX: e.clientX, startC: springRef.current.value, lastX: e.clientX, lastT: performance.now(), v: 0 };
    setDragging(true);
  };
  const onMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    const stage = stageRef.current;
    if (!d || !stage) return;
    const focal = stage.clientWidth * 0.58; /* ◇ 焦点项尺寸比（Strategy 行为值） */
    const c = clamp(d.startC - (e.clientX - d.startX) / focal, 0, N - 1);
    springRef.current.value = c;
    setCenter(c);
    const now = performance.now();
    d.v = (-(e.clientX - d.lastX) / Math.max(1, now - d.lastT)) / focal;
    d.lastX = e.clientX;
    d.lastT = now;
  };
  const onUp = () => {
    const d = dragRef.current;
    if (!d) return;
    dragRef.current = null;
    setDragging(false);
    const v = d.v * 1000;
    animateTo(Math.round(springRef.current.value + v * 0.12), v); /* 吸附最近项（fling 预测 ◇） */
  };

  /* 容器宽度监听（首帧与窗口缩放时重排） */
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const update = () => setStageW(el.clientWidth);
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  /* 布局：按与焦点中心距离取宽度；焦点项宽 = 58% 容器（◇），小项 clamp(40..56) ✓，
     超小 10 ✓，消失 1 ✓；间距 4dp ◇；焦点圆角 16 ◇ / 小项 28 ✓ */
  const GAP = 4;
  const focal = stageW * 0.58;
  const small = clamp(stageW * 0.16, 40, 56);
  const widths = Array.from({ length: N }, (_, i) => {
    const d = Math.abs(i - center);
    if (d < 0.5) return focal;
    if (d < 1.5) return small;
    if (d < 2.5) return 10;
    return 1;
  });
  const pos: number[] = [];
  let acc = 0;
  for (let i = 0; i < N; i++) { pos[i] = acc; acc += widths[i] + GAP; }
  const i0 = Math.floor(clamp(center, 0, N - 1.0001));
  const frac = center - i0;
  /* 锚点 = 焦点项中心随连续 center 线性移向下一项中心（保证焦点项恒居中） */
  const c0 = pos[i0] + widths[i0] / 2;
  const c1 = i0 + 1 < N ? pos[i0 + 1] + widths[i0 + 1] / 2 : c0;
  const anchor = c0 + frac * (c1 - c0);
  const shift = stageW / 2 - anchor;

  return (
    <div className="space-y-3">
      <div
        ref={stageRef}
        className="relative overflow-hidden rounded-lg border"
        style={{ borderColor: theme.outlineVariant, height: 200, touchAction: 'pan-y', cursor: dragging ? 'grabbing' : 'grab' }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
      >
        {Array.from({ length: N }, (_, i) => {
          const d = Math.abs(i - center);
          const isFocal = d < 0.5;
          const isSmall = d >= 0.5 && d < 1.5;
          if (widths[i] <= 1) return null; /* gone_size 1dp ✓ */
          const bg = [theme.secondaryContainer, theme.tertiaryContainer, theme.surfaceContainerHighest][i % CAROUSEL_COLORS];
          const fg = [theme.onSecondaryContainer, theme.onTertiaryContainer, theme.onSurface][i % CAROUSEL_COLORS];
          return (
            <div
              key={i}
              className="absolute inset-y-2 flex flex-col justify-end overflow-hidden"
              style={{
                left: pos[i] + shift,
                width: widths[i],
                borderRadius: isFocal ? SHAPE.large : SHAPE.extraLarge, /* ◇ / ✓ small 28dp */
                backgroundColor: bg,
                transition: dragging ? 'none' : 'border-radius 200ms',
                padding: isFocal ? 16 : 0, /* 非焦点项（10dp/56dp）不参与内边距，避免撑破 token 宽度 */
              }}
            >
              <span className="whitespace-nowrap" style={{ ...TYPE.titleMedium, color: fg, opacity: isFocal ? 1 : 0 }}>
                每日图集 {i + 1}
              </span>
              {isSmall && <span className="whitespace-nowrap" style={{ ...TYPE.labelMedium, color: fg, position: 'absolute', top: 12, left: 12 }}>{i + 1}</span>}
            </div>
          );
        })}
      </div>
      <p className="text-[11px] leading-relaxed font-mono" style={{ color: theme.onSurfaceVariant }}>
        拖拽切换焦点（MultiBrowse 转译）。小项 40–56dp ✓ · 超小 10dp ✓ · 消失 1dp ✓ · 小项圆角 28dp ✓ · 焦点尺寸比/间距/吸附 ◇
      </p>
    </div>
  );
}

/* ================= 9. Date pickers（m3_comp_date_picker_*） =================
 * 容器 surfaceContainerHigh ✓ · 形制 cornerExtraLarge(28dp) ✓ · 头部高 120dp ✓ ·
 * 头部标题 headlineLarge/onSurfaceVariant ✓ · 支撑文字 labelLarge ✓ ·
 * 日期 bodyLarge ✓：选中 primary/onPrimary ✓ · 今日 outline 1dp primary ✓ 文字 primary ✓ ·
 * 未选中 onSurface ✓ · 星期行 bodyLarge/onSurface ✓ · 年份选中 primary/onPrimary ✓ ·
 * 未选中 onSurfaceVariant ✓；范围选择头部 128dp ✓（未演示）；网格 40dp 格 ◇。 */
function DatePickerDemo({ theme }: { theme: M3ThemeTokens }) {
  const [view, setView] = useState<'calendar' | 'year'>('calendar');
  const [ym, setYm] = useState({ y: 2026, m: 10 }); /* 2026-11（0 基月） */
  const [sel, setSel] = useState('2026-11-22');
  const today = '2026-11-22';
  const yearOf = (ymd: string) => Number(ymd.slice(0, 4));
  const monthOf = (ymd: string) => Number(ymd.slice(5, 7));
  const firstDay = new Date(ym.y, ym.m, 1).getDay();
  const days = new Date(ym.y, ym.m + 1, 0).getDate();
  const weeks = ['日', '一', '二', '三', '四', '五', '六'];
  const years = Array.from({ length: 13 }, (_, i) => 2019 + i);
  const fmt = (d: number) => `${ym.y}年${ym.m + 1}月${d}日`;
  return (
    <div className="flex justify-center">
      <div className="w-full max-w-[360px] overflow-hidden" style={{ backgroundColor: theme.surfaceContainerHigh, borderRadius: SHAPE.extraLarge }}>
        {/* 头部 120dp ✓ */}
        <button type="button" onClick={() => setView(view === 'calendar' ? 'year' : 'calendar')} className="block w-full px-6 pb-5 pt-6 text-left" style={{ height: 120 }}>
          <div style={{ ...TYPE.labelLarge, color: theme.onSurfaceVariant }}>{view === 'calendar' ? `${ym.y} 年 ${ym.m + 1} 月 ▾` : '选择日期'}</div>
          <div className="mt-1" style={{ ...TYPE.headlineLarge, color: theme.onSurfaceVariant }}>
            {view === 'calendar' ? fmt(Number(sel.slice(8, 10))) : `${ym.y}`}
          </div>
        </button>
        {view === 'calendar' ? (
          <div className="px-4 pb-4">
            <div className="flex items-center justify-between px-2 pb-2">
              <button type="button" aria-label="上一月" onClick={() => setYm((p) => ({ y: p.m === 0 ? p.y - 1 : p.y, m: p.m === 0 ? 11 : p.m - 1 }))}>
                <ChevronLeft style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
              </button>
              <span style={{ ...TYPE.titleSmall, color: theme.onSurfaceVariant }}>{ym.y} 年 {ym.m + 1} 月</span>
              <button type="button" aria-label="下一月" onClick={() => setYm((p) => ({ y: p.m === 11 ? p.y + 1 : p.y, m: p.m === 11 ? 0 : p.m + 1 }))}>
                <ChevronRight style={{ width: 24, height: 24, color: theme.onSurfaceVariant }} />
              </button>
            </div>
            <div className="grid grid-cols-7">
              {weeks.map((w) => (
                <div key={w} className="flex h-8 items-center justify-center" style={{ ...TYPE.bodyLarge, color: theme.onSurface }}>{w}</div>
              ))}
              {Array.from({ length: firstDay }).map((_, i) => <span key={`b${i}`} />)}
              {Array.from({ length: days }, (_, i) => i + 1).map((d) => {
                const ymd = `${ym.y}-${String(ym.m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                const selected = ymd === sel;
                const isToday = ymd === today;
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setSel(ymd)}
                    className="mx-auto flex items-center justify-center rounded-full"
                    style={{
                      width: 40, height: 40, /* ◇ 网格格 40dp（规范默认） */
                      ...TYPE.bodyLarge,
                      backgroundColor: selected ? theme.primary : 'transparent',
                      color: selected ? theme.onPrimary : isToday ? theme.primary : theme.onSurface,
                      boxShadow: isToday && !selected ? `inset 0 0 0 1px ${theme.primary}` : 'none', /* ✓ outline 1dp primary */
                    }}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="max-h-[240px] overflow-y-auto px-4 pb-4">
            {years.map((y) => {
              const active = y === ym.y;
              return (
                <button
                  key={y}
                  type="button"
                  onClick={() => { setYm((p) => ({ ...p, y })); setView('calendar'); }}
                  className="flex w-full items-center justify-center"
                  style={{ height: 40, borderRadius: SHAPE.full, backgroundColor: active ? theme.primary : 'transparent', ...TYPE.bodyLarge, color: active ? theme.onPrimary : theme.onSurfaceVariant }}
                >
                  {y}
                </button>
              );
            })}
          </div>
        )}
        <div className="flex items-center justify-end gap-2 px-4 pb-4">
          <button type="button" onClick={() => setSel(today)} className="rounded-full px-4 py-2.5" style={{ ...TYPE.labelLarge, color: theme.primary }}>取消</button>
          <button type="button" className="rounded-full px-4 py-2.5" style={{ ...TYPE.labelLarge, color: theme.primary }}>确定</button>
        </div>
      </div>
    </div>
  );
}

/* ================= 10. Time pickers（m3_comp_time_picker_*） =================
 * 容器 surfaceContainerHigh ✓ 形制 28dp ✓ elevation level3=6dp ✓ ·
 * headline labelMedium/onSurfaceVariant ✓ · 表盘 surfaceContainerHighest ✓ ·
 * 表盘选中柄 primary ✓ · 时间选择器：未选中容器 surfaceContainerHighest/文字 onSurface ✓ ·
 * 选中容器 primaryContainer/文字 onPrimaryContainer ✓ · 分隔符 DisplayLarge/onSurface ✓ ·
 * 形制 cornerSmall ✓ · 时段选择器：选中 tertiaryContainer/onTertiaryContainer ✓ ·
 * 未选中文字 onSurfaceVariant ✓ · outline 1dp outline ✓ · 形制 cornerSmall ✓ ·
 * label titleMedium ✓；表盘直径/数字排布/指针几何 ◇（规范默认）。 */
const HOUR_ANGLES = Array.from({ length: 12 }, (_, i) => -90 + i * 30);
function TimePickerDemo({ theme }: { theme: M3ThemeTokens }) {
  const [mode, setMode] = useState<'hour' | 'minute'>('hour');
  const [hour, setHour] = useState(10);
  const [minute, setMinute] = useState(30);
  const [period, setPeriod] = useState<'AM' | 'PM'>('PM');
  const [inputMode, setInputMode] = useState<'clock' | 'text'>('clock');
  const pad = (n: number) => String(n).padStart(2, '0');
  const pick = (v: number) => {
    if (mode === 'hour') { setHour(v); setMode('minute'); } else setMinute(v);
  };
  const values = mode === 'hour' ? Array.from({ length: 12 }, (_, i) => i + 1) : Array.from({ length: 12 }, (_, i) => i * 5);
  return (
    <div className="flex justify-center">
      <div className="w-full max-w-[420px] overflow-hidden p-6" style={{ backgroundColor: theme.surfaceContainerHigh, borderRadius: SHAPE.extraLarge, boxShadow: SHADOW.level3 }}>
        <div style={{ ...TYPE.labelMedium, color: theme.onSurfaceVariant }}>选择时间</div>
        {/* 时间显示（text 形制的 time selector ✓：形状 sm ✓ / 未选中 surfaceContainerHighest ✓ / 分隔符 DisplayLarge ✓） */}
        <div className="mt-2 flex items-center gap-2">
          {[{ v: hour, label: '时', mode: 'hour' as const }, { v: minute, label: '分', mode: 'minute' as const }].map((f) => {
            const active = mode === f.mode && inputMode === 'clock';
            return (
              <button
                key={f.mode}
                type="button"
                onClick={() => setMode(f.mode)}
                className="flex items-center justify-center"
                style={{
                  minWidth: 64, height: 56, borderRadius: SHAPE.small,
                  backgroundColor: active ? theme.primaryContainer : theme.surfaceContainerHighest,
                  ...TYPE.headlineLarge, fontSize: 36, lineHeight: '44px',
                  color: active ? theme.onPrimaryContainer : theme.onSurface,
                }}
              >
                {pad(f.v)}
              </button>
            );
          })}
          <span style={{ ...TYPE.displayLarge, fontSize: 36, lineHeight: '44px', color: theme.onSurface }}>:</span>
          <span style={{ ...TYPE.titleMedium, color: theme.onSurfaceVariant }}>{period}</span>
          <div className="ml-auto flex gap-1">
            <button type="button" aria-label="时钟输入" onClick={() => setInputMode('clock')} style={{ color: inputMode === 'clock' ? theme.primary : theme.onSurfaceVariant }}>
              <Clock style={{ width: 24, height: 24 }} />
            </button>
            <button type="button" aria-label="键盘输入" onClick={() => setInputMode('text')} style={{ color: inputMode === 'text' ? theme.primary : theme.onSurfaceVariant }}>
              <Keyboard style={{ width: 24, height: 24 }} />
            </button>
          </div>
        </div>
        {inputMode === 'clock' ? (
          <div className="mt-4 flex items-center gap-4">
            {/* 表盘 200dp ◇ · dial 色 surfaceContainerHighest ✓ */}
            <div className="relative shrink-0 rounded-full" style={{ width: 200, height: 200, backgroundColor: theme.surfaceContainerHighest }}>
              <span className="absolute rounded-full" style={{ width: 6, height: 6, left: '50%', top: '50%', transform: 'translate(-50%,-50%)', backgroundColor: theme.primary }} />
              {values.map((v, i) => {
                const a = (HOUR_ANGLES[i] * Math.PI) / 180;
                const R = 76; /* ◇ 数字排布半径 */
                const active = mode === 'hour' ? v === hour : v === minute;
                return (
                  <button
                    key={v}
                    type="button"
                    onClick={() => pick(mode === 'hour' ? v : values[i])}
                    className="absolute flex items-center justify-center rounded-full"
                    style={{
                      width: 32, height: 32, /* ◇ 选中柄 32dp（规范默认） */
                      left: `calc(50% + ${Math.cos(a) * R}px - 16px)`,
                      top: `calc(50% + ${Math.sin(a) * R}px - 16px)`,
                      backgroundColor: active ? theme.primary : 'transparent', /* ✓ 柄 primary */
                      ...TYPE.bodyLarge, fontSize: 14,
                      color: active ? theme.onPrimary : theme.onSurface,
                    }}
                  >
                    {mode === 'hour' ? v : pad(v)}
                  </button>
                );
              })}
            </div>
            {/* 时段选择器：形制 sm ✓ · outline 1dp ✓ · 选中 tertiaryContainer ✓ · label titleMedium ✓ */}
            <div className="flex flex-col gap-2">
              {(['AM', 'PM'] as const).map((p) => {
                const active = period === p;
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPeriod(p)}
                    className="flex items-center justify-center"
                    style={{
                      width: 52, height: 40, borderRadius: SHAPE.small,
                      backgroundColor: active ? theme.tertiaryContainer : theme.surfaceContainerHighest,
                      border: active ? 'none' : `1px solid ${theme.outline}`, /* ✓ outline 1dp ✓ */
                      ...TYPE.titleMedium,
                      color: active ? theme.onTertiaryContainer : theme.onSurfaceVariant,
                    }}
                  >
                    {p}
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="mt-4 flex items-center justify-center gap-3">
            {[hour, minute].map((v, idx) => (
              <React.Fragment key={idx}>
                {idx === 1 && <span style={{ ...TYPE.displayLarge, fontSize: 44, lineHeight: '52px', color: theme.onSurface }}>:</span>}
                <button
                  type="button"
                  className="flex items-center justify-center"
                  style={{
                    minWidth: 72, height: 72, borderRadius: SHAPE.small,
                    backgroundColor: theme.surfaceContainerHighest,
                    ...TYPE.displayLarge, fontSize: 44, lineHeight: '52px', color: theme.onSurface,
                  }}
                >
                  {pad(v)}
                </button>
              </React.Fragment>
            ))}
          </div>
        )}
        <div className="mt-4 flex items-center justify-end gap-2">
          <button type="button" className="rounded-full px-4 py-2.5" style={{ ...TYPE.labelLarge, color: theme.primary }}>取消</button>
          <button type="button" className="rounded-full px-4 py-2.5" style={{ ...TYPE.labelLarge, color: theme.primary }}>确定</button>
        </div>
      </div>
    </div>
  );
}

/* ================= 11. FABs / Extended FABs（m3_comp_fab_* / m3_comp_extended_fab_*） =================
 * 四尺寸高 40/56/80/96dp ✓ · 图标 24/24/28/36dp ✓ · 容器 primary ✓（1.14.0 Expressive
 * 更新：由 colorPrimaryContainer 改 colorPrimary）· 图标 onPrimary ✓ · 形制 cornerLarge(16dp) ✓ ·
 * elevation level3(6dp) ✓ hover level4(8dp) ✓ · state layer pressed 0.1 ✓；
 * Extended：S/M/L 高 56/80/96dp ✓ · 图标 24/28/36dp ✓ · 图标-文字距 8/12/16dp ✓ ·
 * leading/trailing 16/26/28dp ✓；extended 颜色/字型未 token 化 ◇（随 FAB primary 形制 + labelLarge）。 */
function FabDemo({ theme }: { theme: M3ThemeTokens }) {
  const fabRipple = hexToRgbaWave(theme.onPrimary, STATE_LAYER.hover);
  const fabBase = { borderRadius: SHAPE.large, backgroundColor: theme.primary, color: theme.onPrimary, boxShadow: SHADOW.level3 };
  const sizes = [
    { h: 40, icon: 24, tag: 'Small 40dp' }, /* ✓ */
    { h: 56, icon: 24, tag: '默认 56dp' }, /* ✓ */
    { h: 80, icon: 28, tag: 'Medium 80dp' }, /* ✓ */
    { h: 96, icon: 36, tag: 'Large 96dp' }, /* ✓ */
  ];
  const ext = [
    { h: 56, icon: 24, space: 8, pad: 16, tag: 'S 56dp' }, /* ✓ */
    { h: 80, icon: 28, space: 12, pad: 26, tag: 'M 80dp' }, /* ✓ */
    { h: 96, icon: 36, space: 16, pad: 28, tag: 'L 96dp' }, /* ✓ */
  ];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-5">
        {sizes.map((s) => (
          <div key={s.tag} className="flex flex-col items-center gap-2">
            <AospFab h={s.h} iconSize={s.icon} rippleColor={fabRipple} style={fabBase} />
            <span className="text-[10px] font-mono" style={{ color: theme.onSurfaceVariant }}>{s.tag}</span>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap items-end gap-5 border-t pt-4" style={{ borderColor: theme.outlineVariant }}>
        {ext.map((s) => (
          <div key={s.tag} className="flex flex-col items-center gap-2">
            <AospRippleSurface
              ariaLabel="新建"
              maskRadius={SHAPE.large}
              color={fabRipple}
              className="flex items-center"
              style={{ height: s.h, borderRadius: SHAPE.large, backgroundColor: theme.primary, color: theme.onPrimary, boxShadow: SHADOW.level3, paddingLeft: s.pad, paddingRight: s.pad, gap: s.space }}
            >
              <Plus style={{ width: s.icon, height: s.icon }} />
              <span style={{ ...TYPE.labelLarge }}>新建</span>
            </AospRippleSurface>
            <span className="text-[10px] font-mono" style={{ color: theme.onSurfaceVariant }}>Extended {s.tag} · 图标-文字 {s.space}dp ✓</span>
          </div>
        ))}
      </div>
    </div>
  );
}
/** FAB 圆钮（AospRippleSurface 载体，涟漪色 onPrimary@0.08 = hover state layer ✓） */
function AospFab({ h, iconSize, rippleColor, style }: { h: number; iconSize: number; rippleColor: { r: number; g: number; b: number; a: number }; style: React.CSSProperties }) {
  return (
    <AospRippleSurface ariaLabel="新建" maskRadius={SHAPE.large} color={rippleColor} className="flex items-center justify-center" style={{ ...style, width: h, height: h }}>
      <Plus style={{ width: iconSize, height: iconSize }} />
    </AospRippleSurface>
  );
}

/* ================= 12. Lists（m3_comp_list_*） =================
 * 容器 surface ✓ · 选中容器 secondaryContainer ✓ 文字/图标 onSecondaryContainer ✓ ·
 * state layer onSurface@{hover 0.08/focus 0.1/pressed 0.1} ✓ · leading/trailing 16dp ✓ ·
 * 上下 10dp ✓；Expressive 形状形变（1.14.0 新增 ✓）：hovered cornerMedium(12dp) ✓ ·
 * pressed/focused cornerLarge(16dp) ✓ · selected cornerLarge(16dp) ✓；
 * 行高 56/72/88dp · 头像 40dp · 图标 24dp ◇（规范默认）。 */
function ListsDemo({ theme }: { theme: M3ThemeTokens }) {
  const [selIdx, setSelIdx] = useState(3);
  const [hoverIdx, setHoverIdx] = useState(-1);
  const [pressIdx, setPressIdx] = useState(-1);
  const rows = [
    { h: 56, leading: 'avatar' as const, overline: null, headline: '单行列表项', supporting: null },
    { h: 72, leading: 'icon' as const, overline: null, headline: '双行列表项', supporting: '支持文字 bodyMedium ◇' },
    { h: 88, leading: 'avatar' as const, overline: 'OVERLINE', headline: '三行列表项', supporting: '含 overline labelSmall ◇ 与支撑文字' },
    { h: 72, leading: 'icon' as const, overline: null, headline: '选中态列表项', supporting: '容器 secondaryContainer ✓ · 文字 onSecondaryContainer ✓' },
  ];
  return (
    <div className="space-y-1">
      {rows.map((r, i) => {
        const selected = i === selIdx;
        const hovered = i === hoverIdx;
        const pressed = i === pressIdx;
        const radius = pressed ? SHAPE.large : hovered ? SHAPE.medium : selected ? SHAPE.large : 0; /* ✓ Expressive 形状状态 */
        const fg = selected ? theme.onSecondaryContainer : theme.onSurface;
        const fgSub = selected ? theme.onSecondaryContainer : theme.onSurfaceVariant;
        return (
          <button
            key={i}
            type="button"
            onClick={() => setSelIdx(i)}
            onMouseEnter={() => setHoverIdx(i)}
            onMouseLeave={() => { setHoverIdx(-1); setPressIdx(-1); }}
            onMouseDown={() => setPressIdx(i)}
            onMouseUp={() => setPressIdx(-1)}
            className="flex w-full cursor-pointer items-center text-left"
            style={{
              height: r.h,
              paddingInline: 16, /* ✓ */
              paddingBlock: 10, /* ✓ */
              gap: 16,
              borderRadius: radius,
              backgroundColor: selected ? theme.secondaryContainer : hovered || pressed ? hexWithAlpha(theme.onSurface, pressed ? STATE_LAYER.pressed : STATE_LAYER.hover) : 'transparent',
              transition: 'border-radius 150ms, background-color 100ms',
            }}
          >
            {r.leading === 'avatar' ? (
              <span className="flex shrink-0 items-center justify-center rounded-full" style={{ width: 40, height: 40, backgroundColor: selected ? theme.onSecondaryContainer : theme.surfaceContainerHighest, color: selected ? theme.secondaryContainer : theme.onSurfaceVariant }}>
                <User style={{ width: 20, height: 20 }} />
              </span>
            ) : (
              <span className="flex shrink-0 items-center justify-center" style={{ width: 24, height: 24 }}>
                <Mail style={{ width: 24, height: 24, color: selected ? theme.onSecondaryContainer : theme.onSurfaceVariant }} />
              </span>
            )}
            <span className="min-w-0 flex-1">
              {r.overline && <div style={{ ...{ fontSize: 10, lineHeight: '14px', fontWeight: 500, letterSpacing: '0.08em' }, color: fgSub }}>{r.overline}</div>}
              <div className="truncate" style={{ ...TYPE.bodyLarge, color: fg }}>{r.headline}</div>
              {r.supporting && <div className="truncate" style={{ ...TYPE.bodyMedium, color: fgSub }}>{r.supporting}</div>}
            </span>
            <ChevronRight style={{ width: 24, height: 24, color: fgSub }} />
          </button>
        );
      })}
      <p className="pt-2 text-[11px] leading-relaxed font-mono" style={{ color: theme.onSurfaceVariant }}>
        悬停→圆角 12dp · 按压/选中→16dp（Expressive 形状状态 ✓）· leading/trailing 16dp ✓ · 上下 10dp ✓
      </p>
    </div>
  );
}

/* ================= 画廊装配 ================= */
export const M3StructuralComponentsGallery: React.FC<GalleryProps> = ({ theme, config }) => {
  const err = errorColors(theme.isDark);
  return (
    <section id="m3-structural" className="scroll-mt-24 space-y-6">
      <div className="max-w-3xl space-y-2">
        <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
          官方清单终局补齐 · 12 类组件（第 21 轮）
        </h2>
        <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
          对照 m3.material.io/components 六大类 36 项官方清单（第 21 轮重抓）逐项审计后的最后一批缺口补齐：
          App bars · Navigation bar/rail/drawer · Bottom/Side sheets · Search · Carousel ·
          Date/Time pickers · FABs/Extended FABs · Lists。至此官方 36 项全部落地
          （Icon buttons 于第 21 轮审计补齐至 M3CoreComponentsGallery；Toolbars 由 ExpressiveControlsGallery 承载）。
          取值全部核实自 MDC-Android 1.14.0 官方 AAR（dl.google.com 通道，宏形态解析 +
          引用链解析，转储见 evidence/mdc-1.14.0-tokens/resolved-structural.txt）。
          <span className="font-mono">✓</span> = AAR/token 逐行核实，
          <span className="font-mono">◇</span> = tokens 未覆盖、按 M3 规范默认（如实标注）。
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Cell span="lg:col-span-2" title="App bars 顶部应用栏" note="m3_comp_app_bar_small_container_height=64dp ✓ · on-scroll 容器 surface→surfaceContainer ✓ · elevation level0→level2 ✓ · medium 112dp/large 152dp ✓；title/nav/action 颜色 ◇（规范默认）">
          <TopAppBarDemo theme={theme} />
        </Cell>
        <Cell title="Navigation bar 底部导航" note="m3_comp_nav_bar_*：高 64dp ✓（Expressive 值）· 容器 surfaceContainer ✓ · elevation level2 ✓ · 指示条 56×32dp ✓ · active onSecondaryContainer/inactive onSurfaceVariant ✓ · label labelMedium ✓ · badge 联动 ✓">
          <NavigationBarDemo theme={theme} err={err} />
        </Cell>
        <Cell title="Navigation rail 侧边导航轨" note="m3_comp_nav_rail_*：窄 80dp/宽变体 96dp ✓ · 顶部空间 44dp ✓ · 项高 64dp ✓ · 纵向指示条 56×32dp ✓ · expanded 220–360dp ✓ 横向指示条 56dp ✓ · 容器 surface ✓ elevation 0 ✓ · badge 锚定图标本体 ✓；头部 FAB primary 形制 ✓">
          <NavigationRailDemo theme={theme} err={err} />
        </Cell>
        <Cell span="lg:col-span-2" title="Navigation drawer 导航抽屉（standard + modal）" note="m3_comp_navigation_drawer_*：宽 360dp ✓ · 图标 24dp ✓ · modal 容器 surfaceContainerLow ✓ elevation level1 ✓ · layout 圆角 16dp ✓ · standard elevation 0 ✓ · headline titleSmall/onSurfaceVariant ✓ · 标签 labelLarge ✓ · 胶囊 secondaryContainer ✓ · inset 12dp ✓；指示条高 56dp/scrim 32% ◇">
          <NavigationDrawerDemo theme={theme} err={err} />
        </Cell>
        <Cell span="lg:col-span-2" title="Bottom sheets 底部快照（standard + modal）" note="m3_comp_sheet_bottom_docked_*：容器 surfaceContainerLow ✓ · 顶圆角 28dp ✓ · 把手 32×4dp onSurfaceVariant ✓ 下距 20dp ✓ · elevation level1 ✓；half=0.5 锚点为 Behavior 默认 ✓；手势吸附/fling 预测 ◇（Web 转译，弹簧复用项目 spring 引擎）">
          <BottomSheetDemo theme={theme} />
        </Cell>
        <Cell title="Side sheets 侧边快照" note="m3_comp_sheet_side_docked_*：宽 256dp ✓ · modal 容器 surfaceContainerLow ✓ 形制 cornerLarge(16dp) ✓ elevation level1 ✓ · standard 容器 surface ✓ elevation 0 ✓ · detached 边距 16dp ✓；分隔线/滑入曲线 ◇">
          <SideSheetDemo theme={theme} />
        </Cell>
        <Cell span="lg:col-span-2" title="Search 搜索（SearchBar + SearchView）" note="m3_comp_search_bar_*：高 56dp ✓ · 容器 surfaceContainerHigh ✓ · elevation level3 ✓ · 头像 30dp ✓ · 支撑文字 bodyLarge ✓；m3_comp_search_view_*：docked 头部 56dp ✓ · 头部-结果距 2dp ✓ · 结果形制 cornerMedium ✓ · 分隔线 outline ✓；bar 全圆角 ◇">
          <SearchDemo theme={theme} />
        </Cell>
        <Cell span="lg:col-span-2" title="Carousel 多浏览轮播" note="m3_carousel_*：小项 40–56dp ✓ · 超小项 10dp ✓ · 消失项 1dp ✓ · 小项圆角 28dp ✓；焦点尺寸比/项间距/焦点圆角/吸附为 Strategy 行为值 ◇（未 token 化，如实标注）">
          <CarouselDemo theme={theme} />
        </Cell>
        <Cell span="lg:col-span-2" title="Date pickers 日期选择器" note="m3_comp_date_picker_*：容器 surfaceContainerHigh ✓ · 形制 28dp ✓ · 头部 120dp ✓ headlineLarge/onSurfaceVariant ✓ · 日期 bodyLarge ✓ 选中 primary/onPrimary ✓ 今日 outline 1dp primary ✓ · 星期行 onSurface ✓ · 年份选中 primary ✓；40dp 格 ◇；范围头部 128dp ✓（未演示）">
          <DatePickerDemo theme={theme} />
        </Cell>
        <Cell span="lg:col-span-2" title="Time pickers 时间选择器（表盘 + 键盘双模式）" note="m3_comp_time_picker_*：容器 surfaceContainerHigh ✓ 28dp ✓ elevation level3 ✓ · headline labelMedium ✓ · 表盘 surfaceContainerHighest ✓ 选中柄 primary ✓ · time selector 未选 surfaceContainerHighest/选中 primaryContainer ✓ 分隔符 DisplayLarge ✓ 形制 sm ✓ · 时段选择器选中 tertiaryContainer ✓ outline 1dp ✓ titleMedium ✓；表盘几何 ◇">
          <TimePickerDemo theme={theme} />
        </Cell>
        <Cell title="FABs / Extended FABs（Expressive 四尺寸）" note="m3_comp_fab_*：高 40/56/80/96dp ✓ 图标 24/24/28/36dp ✓ · 容器 primary ✓（1.14.0 Expressive 更新）· onPrimary ✓ · 形制 16dp ✓ · elevation level3 ✓；m3_comp_extended_fab_*：S/M/L 高 56/80/96dp ✓ 图标 24/28/36dp ✓ 图标-文字距 8/12/16dp ✓ leading/trailing 16/26/28dp ✓；extended 颜色/字型 ◇">
          <FabDemo theme={theme} />
        </Cell>
        <Cell span="lg:col-span-2" title="Lists 列表（Expressive 形状形变）" note="m3_comp_list_*：容器 surface ✓ · 选中 secondaryContainer/onSecondaryContainer ✓ · state layer onSurface@0.08/0.1 ✓ · leading/trailing 16dp ✓ 上下 10dp ✓ · Expressive 形变 hovered=cornerMedium ✓ pressed/selected=cornerLarge ✓（1.14.0 新增）；行高 56/72/88dp、头像 40dp、图标 24dp ◇">
          <ListsDemo theme={theme} />
        </Cell>
      </div>

      <style>{`
        @keyframes drawer-in {
          from { transform: translateX(-24px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>
    </section>
  );
};
