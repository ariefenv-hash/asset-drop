"use client";
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BatteryCharging,
  Bluetooth,
  Flashlight,
  Heart,
  Moon,
  Pause,
  Plane,
  Play,
  SkipBack,
  SkipForward,
  Wifi,
} from 'lucide-react';
import { hexToRgbaWave, M3ThemeTokens } from '../../aosp/dynamicColor';
import {
  M3_SPRING_EXPRESSIVE_FAST,
  M3_SPRING_STANDARD_FAST,
  SpringState,
  stepSpring,
} from '../../aosp/spring';
import { AospRippleSurface } from './AospRippleSurface';
import { LabConfigState } from './InteractiveLab';

interface RowSqueezeGalleryProps {
  isDark: boolean;
  config: LabConfigState;
  theme: M3ThemeTokens;
}

type SpringPresetKey = 'expressive' | 'standard';

export const RowSqueezeGallery: React.FC<RowSqueezeGalleryProps> = ({
  isDark,
  config,
  theme,
}) => {
  const [springPreset, setSpringPreset] = useState<SpringPresetKey>('expressive');
  const [bounceAmplitudeDp, setBounceAmplitudeDp] = useState<number>(8);

  const [smallActive, setSmallActive] = useState<boolean[]>([
    true,
    true,
    false,
    false,
  ]);
  const [smallPressedIdx, setSmallPressedIdx] = useState<number | null>(null);
  const [smallBounces, setSmallBounces] = useState<number[]>([0, 0, 0, 0]);

  const [largeActive, setLargeActive] = useState<boolean[]>([false, true]);
  const [largePressedIdx, setLargePressedIdx] = useState<number | null>(null);
  const [largeBounces, setLargeBounces] = useState<number[]>([0, 0]);

  const [groupSelectedIdx, setGroupSelectedIdx] = useState<number>(1);
  const [groupPressedIdx, setGroupPressedIdx] = useState<number | null>(null);
  const [groupPlaying, setGroupPlaying] = useState<boolean>(false);
  const [groupLiked, setGroupLiked] = useState<boolean>(false);
  const [groupIncreases, setGroupIncreases] = useState<number[]>([0, 0, 0, 0]);
  const groupRowRef = useRef<HTMLDivElement>(null);

  const smallSpringsRef = useRef<SpringState[]>(
    [0, 1, 2, 3].map(() => ({ value: 0, velocity: 0, target: 0 }))
  );
  const smallPeakTimersRef = useRef<number[]>([]);

  const largeSpringsRef = useRef<SpringState[]>(
    [0, 1].map(() => ({ value: 0, velocity: 0, target: 0 }))
  );
  const largePeakTimersRef = useRef<number[]>([]);

  const groupSpringsRef = useRef<SpringState[]>(
    [0, 1, 2, 3].map(() => ({ value: 0, velocity: 0, target: 0 }))
  );

  const rafRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  const springConfig =
    springPreset === 'expressive'
      ? M3_SPRING_EXPRESSIVE_FAST
      : M3_SPRING_STANDARD_FAST;
  const springConfigRef = useRef(springConfig);
  const speedRef = useRef(config.speedMultiplier);

  useEffect(() => {
    springConfigRef.current = springConfig;
    speedRef.current = config.speedMultiplier;
  });

  const runSpringLoop = useCallback(() => {
    if (rafRef.current !== null) return;
    lastTimeRef.current = performance.now();

    const tick = (now: number) => {
      const dt =
        ((now - lastTimeRef.current) / 1000) * Math.max(0.15, speedRef.current);
      lastTimeRef.current = now;
      const cfg = springConfigRef.current;

      let anyActive = false;

      for (let i = 0; i < smallSpringsRef.current.length; i++) {
        if (stepSpring(smallSpringsRef.current[i], dt, cfg)) anyActive = true;
      }
      for (let i = 0; i < largeSpringsRef.current.length; i++) {
        if (stepSpring(largeSpringsRef.current[i], dt, cfg)) anyActive = true;
      }
      for (let i = 0; i < groupSpringsRef.current.length; i++) {
        if (stepSpring(groupSpringsRef.current[i], dt, cfg)) anyActive = true;
      }

      setSmallBounces(smallSpringsRef.current.map((s) => s.value));
      setLargeBounces(largeSpringsRef.current.map((s) => s.value));
      setGroupIncreases(groupSpringsRef.current.map((s) => s.value));

      if (anyActive) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        rafRef.current = null;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  }, []);

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      smallPeakTimersRef.current.forEach((id) => window.clearTimeout(id));
      largePeakTimersRef.current.forEach((id) => window.clearTimeout(id));
    };
  }, []);

  const triggerSmallTileDown = (index: number) => {
    setSmallPressedIdx(index);
    if (smallPeakTimersRef.current[index]) {
      window.clearTimeout(smallPeakTimersRef.current[index]);
    }
    smallSpringsRef.current[index].target = bounceAmplitudeDp;
    runSpringLoop();
  };

  const triggerSmallTileUp = (index: number, toggle: boolean) => {
    setSmallPressedIdx((cur) => (cur === index ? null : cur));
    if (toggle) {
      setSmallActive((prev) => prev.map((v, i) => (i === index ? !v : v)));
    }
    const holdDelay = Math.max(
      40,
      Math.round(90 / Math.max(0.2, config.speedMultiplier))
    );
    smallPeakTimersRef.current[index] = window.setTimeout(() => {
      smallSpringsRef.current[index].target = 0;
      runSpringLoop();
    }, holdDelay);
  };

  const triggerLargeTileDown = (index: number) => {
    setLargePressedIdx(index);
    if (largePeakTimersRef.current[index]) {
      window.clearTimeout(largePeakTimersRef.current[index]);
    }
    largeSpringsRef.current[index].target = bounceAmplitudeDp;
    runSpringLoop();
  };

  const triggerLargeTileUp = (index: number, toggle: boolean) => {
    setLargePressedIdx((cur) => (cur === index ? null : cur));
    if (toggle) {
      setLargeActive((prev) => prev.map((v, i) => (i === index ? !v : v)));
    }
    const holdDelay = Math.max(
      40,
      Math.round(90 / Math.max(0.2, config.speedMultiplier))
    );
    largePeakTimersRef.current[index] = window.setTimeout(() => {
      largeSpringsRef.current[index].target = 0;
      runSpringLoop();
    }, holdDelay);
  };

  const handleGroupPressDown = (index: number) => {
    setGroupPressedIdx(index);
    const rowWidth = groupRowRef.current?.getBoundingClientRect().width ?? 520;
    const baseBtnWidth = (rowWidth - 8 * 3) / 4;
    const rawIncrease = baseBtnWidth * 0.15 * (bounceAmplitudeDp / 8);
    const maxSafeSingleEdge = baseBtnWidth * 0.25;
    const isEdge = index === 0 || index === 3;
    const singleEdgeIncrease = Math.min(rawIncrease * 0.5, maxSafeSingleEdge);
    const targetIncrease = isEdge ? singleEdgeIncrease : singleEdgeIncrease * 2;

    groupSpringsRef.current.forEach((s, i) => {
      s.target = i === index ? targetIncrease : 0;
    });
    runSpringLoop();
  };

  const handleGroupPressRelease = (index: number, commitClick: boolean) => {
    setGroupPressedIdx((cur) => (cur === index ? null : cur));
    groupSpringsRef.current[index].target = 0;
    runSpringLoop();
    if (commitClick) {
      setGroupSelectedIdx(index);
      if (index === 1) setGroupPlaying((p) => !p);
      if (index === 3) setGroupLiked((l) => !l);
    }
  };

  const handleGroupKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleGroupPressDown(index);
      window.setTimeout(() => handleGroupPressRelease(index, true), 120);
    }
  };

  const handleSmallKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      triggerSmallTileDown(index);
      window.setTimeout(() => triggerSmallTileUp(index, true), 80);
    }
  };

  const handleLargeKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      triggerLargeTileDown(index);
      window.setTimeout(() => triggerLargeTileUp(index, true), 80);
    }
  };

  const waveColor = hexToRgbaWave(
    theme.primary,
    Math.max(isDark ? 0.24 : 0.22, config.waveAlpha)
  );
  const filledWave = { r: 1, g: 1, b: 1, a: 0.28 };
  const sparkleColor = { r: 1, g: 1, b: 1, a: config.sparkleAlpha };

  const computeBounceDeltas = (bounces: number[]) => {
    return bounces.map((b, i) => {
      const prevB = i > 0 ? bounces[i - 1] : null;
      const nextB = i < bounces.length - 1 ? bounces[i + 1] : null;
      const sizePrevious = prevB !== null ? b - prevB : 0;
      const sizeNext = nextB !== null ? b - nextB : 0;
      return {
        widthDelta: sizePrevious + sizeNext,
        offsetX: -sizePrevious,
      };
    });
  };

  const computeGroupDeltas = (increases: number[]) => {
    const decreases = increases.map(() => 0);
    for (let i = 0; i < increases.length; i++) {
      const inc = increases[i];
      if (Math.abs(inc) < 0.01) continue;
      const hasPrev = i > 0;
      const hasNext = i < increases.length - 1;
      if (!hasPrev && hasNext) {
        decreases[i + 1] += inc;
      } else if (hasPrev && !hasNext) {
        decreases[i - 1] += inc;
      } else if (hasPrev && hasNext) {
        decreases[i - 1] += inc * 0.5;
        decreases[i + 1] += inc * 0.5;
      }
    }
    return increases.map((inc, i) => inc - decreases[i]);
  };

  const smallDeltas = computeBounceDeltas(smallBounces);
  const largeDeltas = computeBounceDeltas(largeBounces);
  const groupDeltas = computeGroupDeltas(groupIncreases);

  const smallTiles = [
    { label: 'WLAN', icon: Wifi },
    { label: '蓝牙', icon: Bluetooth },
    { label: '手电筒', icon: Flashlight },
    { label: '勿扰', icon: Moon },
  ];

  const largeTiles = [
    { label: '飞行模式', subOff: '已关闭', subOn: '已开启', icon: Plane },
    { label: '省电模式', subOff: '正常性能', subOn: '延长续航', icon: BatteryCharging },
  ];

  const groupButtons = [
    { label: '上一首', icon: SkipBack },
    { label: groupPlaying ? '暂停' : '播放', icon: groupPlaying ? Pause : Play },
    { label: '下一首', icon: SkipForward },
    { label: groupLiked ? '已喜欢' : '喜欢', icon: Heart },
  ];

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            QS 磁贴与 ButtonGroup 整排联动挤压效果 (Bounceable &amp; MaterialButtonGroup)
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            移植自 AOSP <code className="font-mono">Bounceable.kt</code> /{' '}
            <code className="font-mono">BounceableTileViewModel.kt</code> 与 MDC{' '}
            <code className="font-mono">MaterialButtonGroup.java</code>：点击或按住任一按钮，整排总宽保持守恒，当前项横向扩张并将形变实时挤压给左右相邻按钮。
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 min-w-0 w-full lg:w-auto">
          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1 max-w-full">
            <button
              type="button"
              onClick={() => setSpringPreset('expressive')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                springPreset === 'expressive'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Expressive (k=800, ζ=0.6)
            </button>
            <button
              type="button"
              onClick={() => setSpringPreset('standard')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                springPreset === 'standard'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Standard (k=1400, ζ=0.9)
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1 max-w-full">
            {[8, 14].map((amp) => (
              <button
                key={amp}
                type="button"
                onClick={() => setBounceAmplitudeDp(amp)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap font-mono ${
                  bounceAmplitudeDp === amp
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {amp}dp {amp === 8 ? '(AOSP)' : '(增强)'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 space-y-5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-slate-800 dark:text-slate-200">
              1. SystemUI QS 快捷设置整排挤压 (Bounceable.kt · TileArrangementPadding = 6dp)
            </span>
            <span className="font-mono text-slate-500 dark:text-slate-400">
              点击或长按任意磁贴
            </span>
          </div>

          <div className="space-y-2">
            <div className="grid grid-cols-4 gap-[6px] overflow-visible">
              {smallTiles.map((tile, i) => {
                const Icon = tile.icon;
                const active = smallActive[i];
                const pressed = smallPressedIdx === i;
                const { widthDelta, offsetX } = smallDeltas[i];
                const baseRadius = active ? 24 : 36;
                const targetRadius = pressed ? Math.min(baseRadius, 18) : baseRadius;

                return (
                  <div key={tile.label} className="relative h-[72px]">
                    <div
                      onPointerDown={() => triggerSmallTileDown(i)}
                      onPointerUp={() => triggerSmallTileUp(i, true)}
                      onPointerCancel={() => triggerSmallTileUp(i, false)}
                      onPointerLeave={() => {
                        if (smallPressedIdx === i) triggerSmallTileUp(i, false);
                      }}
                      onKeyDown={(e) => handleSmallKeyDown(e, i)}
                      style={{
                        width: `calc(100% + ${widthDelta.toFixed(2)}px)`,
                        transform: `translateX(${offsetX.toFixed(2)}px)`,
                      }}
                      className="h-full will-change-transform"
                    >
                      <AospRippleSurface
                        role="button"
                        tabIndex={0}
                        ariaLabel={tile.label}
                        ariaPressed={active}
                        mode={config.mode}
                        color={active ? filledWave : waveColor}
                        sparkleColor={sparkleColor}
                        sparkleStrength={config.sparkleStrength}
                        distortionStrength={config.distortionStrength}
                        systemUiShape={config.systemUiShape}
                        speedMultiplier={config.speedMultiplier}
                        densityScale={config.densityScale}
                        maskRadius={targetRadius}
                        style={{
                          borderRadius: `${targetRadius}px`,
                          backgroundColor: active ? theme.primary : undefined,
                          color: active ? theme.onPrimary : undefined,
                        }}
                        className={`flex h-full w-full items-center justify-center transition-[background-color,border-radius] duration-200 ease-[cubic-bezier(0.2,0,0,1)] ${
                          active
                            ? ''
                            : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200'
                        }`}
                      >
                        <div className="flex h-[72px] w-full items-center justify-center">
                          <Icon className="h-6 w-6 shrink-0" />
                        </div>
                      </AospRippleSurface>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="grid grid-cols-4 gap-[6px] text-center font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
              {smallDeltas.map((d, idx) => (
                <div key={idx}>
                  {d.widthDelta >= 0 ? `+${d.widthDelta.toFixed(1)}` : d.widthDelta.toFixed(1)}px
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-[6px] overflow-visible">
              {largeTiles.map((tile, i) => {
                const Icon = tile.icon;
                const active = largeActive[i];
                const pressed = largePressedIdx === i;
                const { widthDelta, offsetX } = largeDeltas[i];
                const baseRadius = active ? 24 : 36;
                const targetRadius = pressed ? Math.min(baseRadius, 18) : baseRadius;

                return (
                  <div key={tile.label} className="relative h-[72px]">
                    <div
                      onPointerDown={() => triggerLargeTileDown(i)}
                      onPointerUp={() => triggerLargeTileUp(i, true)}
                      onPointerCancel={() => triggerLargeTileUp(i, false)}
                      onPointerLeave={() => {
                        if (largePressedIdx === i) triggerLargeTileUp(i, false);
                      }}
                      onKeyDown={(e) => handleLargeKeyDown(e, i)}
                      style={{
                        width: `calc(100% + ${widthDelta.toFixed(2)}px)`,
                        transform: `translateX(${offsetX.toFixed(2)}px)`,
                      }}
                      className="h-full will-change-transform"
                    >
                      <AospRippleSurface
                        role="button"
                        tabIndex={0}
                        ariaLabel={tile.label}
                        ariaPressed={active}
                        mode={config.mode}
                        color={active ? filledWave : waveColor}
                        sparkleColor={sparkleColor}
                        sparkleStrength={config.sparkleStrength}
                        distortionStrength={config.distortionStrength}
                        systemUiShape={config.systemUiShape}
                        speedMultiplier={config.speedMultiplier}
                        densityScale={config.densityScale}
                        maskRadius={targetRadius}
                        style={{
                          borderRadius: `${targetRadius}px`,
                          backgroundColor: active ? theme.primary : undefined,
                          color: active ? theme.onPrimary : undefined,
                        }}
                        className={`flex h-full w-full items-center px-4 transition-[background-color,border-radius] duration-200 ease-[cubic-bezier(0.2,0,0,1)] ${
                          active
                            ? ''
                            : 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-100'
                        }`}
                      >
                        <div className="flex h-[72px] w-full items-center gap-3 min-w-0">
                          <Icon className="h-6 w-6 shrink-0" />
                          <div className="min-w-0">
                            <div className="text-sm font-medium truncate">{tile.label}</div>
                            <div
                              className={`text-xs truncate ${
                                active ? 'opacity-85' : 'text-slate-500 dark:text-slate-400'
                              }`}
                            >
                              {active ? tile.subOn : tile.subOff}
                            </div>
                          </div>
                        </div>
                      </AospRippleSurface>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="grid grid-cols-2 gap-[6px] text-center font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
              {largeDeltas.map((d, idx) => (
                <div key={idx}>
                  {d.widthDelta >= 0 ? `+${d.widthDelta.toFixed(1)}` : d.widthDelta.toFixed(1)}px
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 flex flex-col justify-between gap-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/50 p-4">
          <div>
            <div className="text-xs font-medium text-slate-800 dark:text-slate-200">
              2. MDC MaterialButtonGroup 按下整排挤压
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              对应 <code className="font-mono">m3_button_group_child_size_change.xml</code>（
              <code className="font-mono">widthChange=&quot;15%&quot;</code>）与{' '}
              <code className="font-mono">calculateEffectiveWidthChangeMax()</code>：中间按钮向两侧扩张，首尾按钮仅向内侧半幅扩张，确保邻接按钮受力一致且不被过度挤压。
            </p>
          </div>

          <div className="space-y-2.5 py-2">
            <div ref={groupRowRef} className="flex w-full items-center gap-2">
              {groupButtons.map((btn, i) => {
                const Icon = btn.icon;
                const pressed = groupPressedIdx === i;
                const selected = groupSelectedIdx === i;
                const deltaPx = groupDeltas[i];
                const radiusPx = pressed ? 10 : selected ? 14 : 24;

                return (
                  <div
                    key={btn.label}
                    onPointerDown={() => handleGroupPressDown(i)}
                    onPointerUp={() => handleGroupPressRelease(i, true)}
                    onPointerCancel={() => handleGroupPressRelease(i, false)}
                    onPointerLeave={() => {
                      if (groupPressedIdx === i) handleGroupPressRelease(i, false);
                    }}
                    onKeyDown={(e) => handleGroupKeyDown(e, i)}
                    style={{
                      flex: '0 0 auto',
                      width: `calc((100% - 24px) / 4 + ${deltaPx.toFixed(2)}px)`,
                    }}
                    className="min-w-0 h-12"
                  >
                    <AospRippleSurface
                      role="button"
                      tabIndex={0}
                      ariaLabel={btn.label}
                      ariaPressed={selected}
                      mode={config.mode}
                      color={selected ? filledWave : waveColor}
                      sparkleColor={sparkleColor}
                      sparkleStrength={config.sparkleStrength}
                      distortionStrength={config.distortionStrength}
                      systemUiShape={config.systemUiShape}
                      speedMultiplier={config.speedMultiplier}
                      densityScale={config.densityScale}
                      maskRadius={radiusPx}
                      style={{
                        borderRadius: `${radiusPx}px`,
                        backgroundColor: selected ? theme.primary : undefined,
                        color: selected ? theme.onPrimary : undefined,
                      }}
                      className={`flex h-12 w-full items-center justify-center px-2 text-xs font-medium transition-[background-color,border-radius] duration-150 ease-[cubic-bezier(0.2,0,0,1)] ${
                        selected
                          ? ''
                          : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <div className="flex h-12 items-center justify-center gap-1.5 whitespace-nowrap overflow-hidden">
                        <Icon
                          className={`h-4 w-4 shrink-0 ${
                            i === 3 && groupLiked ? 'fill-current' : ''
                          }`}
                        />
                        <span className="truncate">{btn.label}</span>
                      </div>
                    </AospRippleSurface>
                  </div>
                );
              })}
            </div>

            <div className="flex w-full gap-2 text-center font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
              {groupDeltas.map((d, idx) => (
                <div
                  key={idx}
                  style={{
                    flex: '0 0 auto',
                    width: `calc((100% - 24px) / 4 + ${d.toFixed(2)}px)`,
                  }}
                >
                  {d >= 0 ? `+${d.toFixed(1)}` : d.toFixed(1)}px
                </div>
              ))}
            </div>
          </div>

          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
            提示：长按中间按钮 vs 首尾按钮，观察双侧与单侧挤压及圆角形变
          </div>
        </div>
      </div>
    </div>
  );
};
