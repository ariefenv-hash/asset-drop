"use client";
/**
 * 边界拉伸 Overscroll（Stretch Edge Effect）—— Android 12+ 拉伸过滚 1:1 移植演示
 * （第七轮重做：形变从"逐行平移"改为"单容器整块形变"，与真机位图 warp 形态一致）
 *
 * 【源码依据】tmp/fb17/core/java/android/widget/EdgeEffect.java（TYPE_STRETCH 路径，
 * Android 17 android-17.0.0_r1）+ tmp/fb17/libs/hwui/effects/StretchEffect.cpp（SkSL
 * 形变着色器与 CPU 逆映射）。引擎移植见 src/aosp/edgeStretch.ts 头注释（含全部
 * 常量行号）。本文件只做 Web 侧交互与形变应用：
 *
 * 【标准形变形态（对照真机位图 warp）】
 *  Android 的 stretch 是 RenderNode 位图整体 warp：可见内容区间 [0, 1/(1+|o|)] 被拉伸
 *  铺满视口，锚定边（被拉的边）位移 0，行高随内容一起拉长、行间无缝隙。因此本组件不再
 *  逐行平移（旧方案行高不变形、行间开缝，用户裁定"不标准"），改为单容器形变：
 *    transform = translateY(-offset) scale(1+|o|)，origin 置于锚定边；
 *  与源码精确映射在可见区间两端逐位一致（p=0 → 屏幕 0；p=1/(1+|o|) → 屏幕 1），
 *  中段偏差 <0.6% 视口高（o≤0.032）。
 *
 * 【交互模型 → 源码语义】
 *  - 指针拖拽 = ScrollView 触摸拖动：1:1 跟手；到边界后继续拖动 → delta(位移/容器高)
 *    送 EdgeEffect.onPullDistance（L426-443），clamp ≤1（L368-372）；
 *  - 松手有速度 → 简化甩动（见诚实声明）继续滚动，撞击边界时
 *    EdgeEffect.onAbsorb(velocity)（L495-499，×ON_ABSORB_VELOCITY_ADJUSTMENT=13）；
 *  - 滚轮：越界 delta 同样送 onPullDistance；滚轮停止 120ms 后 onRelease（L465-482）
 *    —— 源码 onRelease 由触摸抬起触发，滚轮无对应事件，此为 Web 适配；
 *  - 释放弹簧：updateSpring L749-798（ω=24.657、ζ=0.98 解析解 + 200px/s/8px 线性接管）。
 *
 * 【形变应用（标准整块形变）】
 *  overscroll = dampStretchVector（EdgeEffect L831-838，最大约 ±0.032）；
 *  scale = 1+|o|（src/aosp/edgeStretch.ts stretchScaleFor），origin 锚定边。
 *
 * 【浏览器默认行为阻拦（用户明确要求）】
 *  - 容器 overscroll-behavior: contain —— 阻断 Chromium/Edge 原生过滚 glow 与滚动链；
 *  - 容器 touch-action 按轴授权 + Pointer Events 自管拖拽：垂直列表 pan-x（只授权
 *    浏览器横向 pan——页面无横向可滚，横向手势交还父级，真机语义；垂直手势
 *    由本组件接管，用于拉伸）；胶囊条 pan-y（横向手势本组件接管，纵向手势交还
 *    页面滚动）。不用 'none'：它会把双轴手势全部吃掉，手机上 Demo 区域变成
 *    页面滚动死区（第 16 条移动端问题）；
 *  - wheel 非 passive 监听并 preventDefault —— 阻断浏览器的滚轮平滑滚动/链接链。
 *  全站滚动容器的同一效果见 src/aosp/globalStretch.ts（useGlobalStretchOverscroll）。
 *
 * 【诚实声明】
 *  - 甩动（fling）减速：Android 用 SplineOverScroller 样条摩擦模型（Hidden API），
 *    此处以指数衰减近似（仅用于把动量带到边界），撞击边界的 onAbsorb 参数为源码语义；
 *  - 滚轮停止→onRelease 的 120ms 空闲判定为 Web 适配；
 *  - prefers-reduced-motion → 效果禁用（对应源码 animators disabled → TYPE_NONE，
 *    EdgeEffect.java L260-262）；
 *  - 源码形变为 GPU 逐像素非线性 warp（近锚边拉伸强、远端弱，0.7 插值）；Web 单容器
 *    scale 在可见区间两端与源码逐位一致，中段为线性近似（<0.6% 视口高）。
 */
import React, { useCallback, useEffect, useRef } from 'react';
import {
  EdgeStretchEffect,
  stretchScaleFor,
} from '@/aosp/edgeStretch';
import type { M3ThemeTokens } from '@/aosp/dynamicColor';

/* ---------- 演示数据（Android Settings 风格列表，视觉走当前 M3 主题令牌） ---------- */
const ROW_H = 60;
const ROWS = [
  '网络和互联网', '已连接的设备', '应用', '通知', '电池', '存储', '声音和振动', '显示',
  '壁纸和样式', '安全和隐私', '位置', '账户', '辅助功能', '手势', '数字健康', '系统',
];
const CHIP_W = 108;
const CHIP_GAP = 12;
const CHIPS = ['壁纸', '配色', '时钟', '锁屏', '图标', '网格', '字体', '迷你表盘'];

const VIEWPORT_H = 324; // 视口高（≈5.4 行）
const FLING_FRICTION = 4.2; // 指数衰减系数（1/s）——工程近似，源码为样条摩擦
const WHEEL_SETTLE_MS = 120; // 滚轮空闲→onRelease（Web 适配）
const MIN_ABSORB_VELOCITY = 100; // 低于此速度不触发 absorb（贴近源码 MIN_VELOCITY 语义）

interface StretchDemoProps {
  theme: M3ThemeTokens;
}

interface AxisEngine {
  top: EdgeStretchEffect;
  bottom: EdgeStretchEffect;
  offset: number;
  maxOffset: number;
}

/** 水平内容总宽（胶囊 8×(108+12)−12 = 948px）；可滚距离 = 总宽 − 容器实测宽（mount/resize 时测量） */
const H_CONTENT_W = CHIPS.length * (CHIP_W + CHIP_GAP) - CHIP_GAP;

export function StretchOverscrollDemo({ theme }: StretchDemoProps) {
  const verticalRef = useRef<HTMLDivElement>(null);
  const vContentRef = useRef<HTMLDivElement>(null);
  const horizontalRef = useRef<HTMLDivElement>(null);
  const hContentRef = useRef<HTMLDivElement>(null);
  const statusRef = useRef<HTMLSpanElement>(null);
  const reducedMotionRef = useRef(false);

  // 两个轴各持一对 EdgeEffect（start = 顶/左，end = 底/右，与 ScrollView 两实例一致）
  const vEngine = useRef<AxisEngine>({
    top: new EdgeStretchEffect('start'),
    bottom: new EdgeStretchEffect('end'),
    offset: 0,
    maxOffset: ROWS.length * ROW_H - VIEWPORT_H,
  });
  const hEngine = useRef<AxisEngine>({
    top: new EdgeStretchEffect('start'),
    bottom: new EdgeStretchEffect('end'),
    offset: 0,
    // 容器宽需实测（响应式列宽），mount/resize 时写入；先置 0 防止误判边界
    maxOffset: 0,
  });

  const fling = useRef({ vx: 0, vy: 0 }); // px/s（滚动坐标：vy>0 = 内容上移）
  const dragging = useRef(false);
  const pointerLast = useRef({ x: 0, y: 0, t: 0 });
  const pointerVel = useRef({ x: 0, y: 0 }); // 指针速度 px/s
  const wheelTimer = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    vEngine.current.top.size = VIEWPORT_H;
    vEngine.current.bottom.size = VIEWPORT_H;
    reducedMotionRef.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    // 水平轴几何量随容器实测（fix：maxOffset 必须是“内容宽−容器宽”，旧代码误用内容总宽，
    // 导致可拖出 850px 空白条）；ResizeObserver 跟随响应式列宽变化
    const measureH = () => {
      const el = horizontalRef.current;
      if (!el) return;
      const w = Math.max(1, el.clientWidth);
      hEngine.current.top.size = w;
      hEngine.current.bottom.size = w;
      const next = Math.max(0, H_CONTENT_W - w);
      hEngine.current.maxOffset = next;
      if (hEngine.current.offset > next) {
        hEngine.current.offset = next;
        hEngine.current.top.onRelease(performance.now());
        hEngine.current.bottom.onRelease(performance.now());
      }
    };
    measureH();
    const ro = new ResizeObserver(measureH);
    if (horizontalRef.current) ro.observe(horizontalRef.current);
    return () => ro.disconnect();
  }, []);

  /** 把两轴的整块形变写到内容容器 transform（rAF 内调用） */
  const applyTransforms = useCallback(() => {
    const v = vEngine.current;
    const oV = v.top.stretchVec + v.bottom.stretchVec; // 仅一条边非零
    const vEl = vContentRef.current;
    if (vEl) {
      // transform 从右向左应用：先 scale（origin=锚定边），后平移滚动偏移。
      // 拉伸只发生在 offset=0（顶）或 offset=maxOffset（底），此时锚定边与视口边重合。
      if (oV > 0) {
        vEl.style.transformOrigin = '50% 0';
        vEl.style.transform = `translate3d(0, ${-v.offset}px, 0) scale3d(1, ${stretchScaleFor(oV)}, 1)`;
      } else if (oV < 0) {
        vEl.style.transformOrigin = '50% 100%';
        vEl.style.transform = `translate3d(0, ${-v.offset}px, 0) scale3d(1, ${stretchScaleFor(oV)}, 1)`;
      } else {
        vEl.style.transformOrigin = '50% 0';
        vEl.style.transform = `translate3d(0, ${-v.offset}px, 0)`;
      }
    }
    const h = hEngine.current;
    const oH = h.top.stretchVec + h.bottom.stretchVec;
    const hEl = hContentRef.current;
    if (hEl) {
      if (oH > 0) {
        hEl.style.transformOrigin = '0 50%';
        hEl.style.transform = `translate3d(${-h.offset}px, 0, 0) scale3d(${stretchScaleFor(oH)}, 1, 1)`;
      } else if (oH < 0) {
        hEl.style.transformOrigin = '100% 50%';
        hEl.style.transform = `translate3d(${-h.offset}px, 0, 0) scale3d(${stretchScaleFor(oH)}, 1, 1)`;
      } else {
        hEl.style.transformOrigin = '0 50%';
        hEl.style.transform = `translate3d(${-h.offset}px, 0, 0)`;
      }
    }
    if (statusRef.current) {
      const vecY = oV;
      statusRef.current.textContent =
        `mDistance 顶 ${(v.top.distance).toFixed(3)} / 底 ${(v.bottom.distance).toFixed(3)}` +
        ` · vecY ${vecY.toFixed(4)} · ${vecY !== 0 ? '拉伸中' : '静止'}`;
    }
  }, []);

  /** 主循环：fling 积分（真实 dt）+ 弹簧推进 + 形变应用 */
  const lastFrameRef = useRef(0);
  const tick = useCallback(() => {
    const now = performance.now();
    const dt = Math.min(0.032, Math.max(0.001, (now - lastFrameRef.current) / 1000));
    lastFrameRef.current = now;
    const step = (vel: number): number => {
      if (Math.abs(vel) > 1) {
        return vel * Math.exp(-FLING_FRICTION * dt);
      }
      return vel;
    };
    // 垂直甩动 → 边界吸收
    const v = vEngine.current;
    if (Math.abs(fling.current.vy) > 1) {
      v.offset += fling.current.vy * dt;
      fling.current.vy = step(fling.current.vy);
    }
    if (v.offset < 0) {
      if (Math.abs(fling.current.vy) > MIN_ABSORB_VELOCITY) {
        v.top.onAbsorb(Math.abs(fling.current.vy), now);
      } else {
        v.top.onRelease(now);
        v.top.tick(now);
      }
      v.offset = 0;
      fling.current.vy = 0;
    } else if (v.offset > v.maxOffset) {
      if (Math.abs(fling.current.vy) > MIN_ABSORB_VELOCITY) {
        v.bottom.onAbsorb(Math.abs(fling.current.vy), now);
      } else {
        v.bottom.onRelease(now);
        v.bottom.tick(now);
      }
      v.offset = v.maxOffset;
      fling.current.vy = 0;
    } else if (!dragging.current) {
      v.top.tick(now);
      v.bottom.tick(now);
    }
    // 水平甩动 → 边界吸收
    const h = hEngine.current;
    if (Math.abs(fling.current.vx) > 1) {
      h.offset += fling.current.vx * dt;
      fling.current.vx = step(fling.current.vx);
    }
    if (h.offset < 0) {
      if (Math.abs(fling.current.vx) > MIN_ABSORB_VELOCITY) {
        h.top.onAbsorb(Math.abs(fling.current.vx), now);
      } else {
        h.top.onRelease(now);
        h.top.tick(now);
      }
      h.offset = 0;
      fling.current.vx = 0;
    } else if (h.offset > h.maxOffset) {
      if (Math.abs(fling.current.vx) > MIN_ABSORB_VELOCITY) {
        h.bottom.onAbsorb(Math.abs(fling.current.vx), now);
      } else {
        h.bottom.onRelease(now);
        h.bottom.tick(now);
      }
      h.offset = h.maxOffset;
      fling.current.vx = 0;
    } else if (!dragging.current) {
      h.top.tick(now);
      h.bottom.tick(now);
    }
    applyTransforms();
    const active =
      Math.abs(fling.current.vy) > 1 ||
      Math.abs(fling.current.vx) > 1 ||
      v.top.active || v.bottom.active || h.top.active || h.bottom.active;
    rafRef.current = active ? requestAnimationFrame(tick) : null;
  }, [applyTransforms]);

  const ensureRaf = useCallback(() => {
    if (rafRef.current == null) rafRef.current = requestAnimationFrame(tick);
  }, [tick]);

  /* ---------- 指针拖拽（1:1 跟手 + 越界送 onPullDistance） ---------- */
  const onPointerDown = (e: React.PointerEvent) => {
    dragging.current = true;
    fling.current.vy = 0;
    fling.current.vx = 0;
    pointerLast.current = { x: e.clientX, y: e.clientY, t: performance.now() };
    pointerVel.current = { x: 0, y: 0 };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging.current) return;
    const now = performance.now();
    const dy = e.clientY - pointerLast.current.y;
    const dx = e.clientX - pointerLast.current.x;
    const dt = Math.max(1, now - pointerLast.current.t);
    pointerVel.current = { x: dx / dt * 1000, y: dy / dt * 1000 };
    pointerLast.current = { x: e.clientX, y: e.clientY, t: now };

    const v = vEngine.current;
    const next = v.offset - dy; // 手指向下拖 → 内容下移
    if (next < 0) {
      v.offset = 0;
      if (!reducedMotionRef.current) v.top.onPullDistance(-next, now); // 越界量
      v.bottom.onRelease(now);
    } else if (next > v.maxOffset) {
      v.offset = v.maxOffset;
      if (!reducedMotionRef.current) v.bottom.onPullDistance(next - v.maxOffset, now);
      v.top.onRelease(now);
    } else {
      v.offset = next;
      v.top.onRelease(now);
      v.bottom.onRelease(now);
      v.top.tick(now);
      v.bottom.tick(now);
    }
    const h = hEngine.current;
    const nextH = h.offset - dx;
    if (nextH < 0) {
      h.offset = 0;
      if (!reducedMotionRef.current) h.top.onPullDistance(-nextH, now);
      h.bottom.onRelease(now);
    } else if (nextH > h.maxOffset) {
      h.offset = h.maxOffset;
      if (!reducedMotionRef.current) h.bottom.onPullDistance(nextH - h.maxOffset, now);
      h.top.onRelease(now);
    } else {
      h.offset = nextH;
      h.top.onRelease(now);
      h.bottom.onRelease(now);
      h.top.tick(now);
      h.bottom.tick(now);
    }
    ensureRaf();
  };
  const onPointerUp = () => {
    dragging.current = false;
    const now = performance.now();
    // 指针速度 → 滚动速度（拖拽方向取反），过低则交给 onRelease 弹簧
    const vy = -pointerVel.current.y;
    const vx = -pointerVel.current.x;
    fling.current.vy = Math.abs(vy) > 120 ? Math.max(-6000, Math.min(6000, vy)) : 0;
    fling.current.vx = Math.abs(vx) > 120 ? Math.max(-6000, Math.min(6000, vx)) : 0;
    if (fling.current.vy === 0) {
      vEngine.current.top.onRelease(now);
      vEngine.current.bottom.onRelease(now);
    }
    if (fling.current.vx === 0) {
      hEngine.current.top.onRelease(now);
      hEngine.current.bottom.onRelease(now);
    }
    ensureRaf();
  };

  /* ---------- 滚轮（越界 delta → onPullDistance；空闲 → onRelease） ---------- */
  useEffect(() => {
    const onWheel = (e: WheelEvent) => {
      const target = e.currentTarget as HTMLElement;
      const inVertical = target === verticalRef.current;
      const eng = inVertical ? vEngine.current : hEngine.current;
      let delta = e.deltaY;
      if (e.deltaMode === 1) delta *= 16; // line → px（Chrome 默认行模式换算）
      else if (e.deltaMode === 2) delta *= target.clientHeight;
      e.preventDefault(); // 阻拦浏览器原生平滑滚动/滚动链（用户指令）
      const now = performance.now();
      const next = eng.offset + delta;
      if (next < 0) {
        eng.offset = 0;
        if (!reducedMotionRef.current) eng.top.onPullDistance(-next, now);
        eng.bottom.onRelease(now);
      } else if (next > eng.maxOffset) {
        eng.offset = eng.maxOffset;
        if (!reducedMotionRef.current) eng.bottom.onPullDistance(next - eng.maxOffset, now);
        eng.top.onRelease(now);
      } else {
        eng.offset = next;
        eng.top.onRelease(now);
        eng.bottom.onRelease(now);
      }
      if (wheelTimer.current != null) window.clearTimeout(wheelTimer.current);
      wheelTimer.current = window.setTimeout(() => {
        const n = performance.now();
        vEngine.current.top.onRelease(n);
        vEngine.current.bottom.onRelease(n);
        hEngine.current.top.onRelease(n);
        hEngine.current.bottom.onRelease(n);
        ensureRaf();
      }, WHEEL_SETTLE_MS);
      ensureRaf();
    };
    const elV = verticalRef.current;
    const elH = horizontalRef.current;
    elV?.addEventListener('wheel', onWheel, { passive: false });
    elH?.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      elV?.removeEventListener('wheel', onWheel);
      elH?.removeEventListener('wheel', onWheel);
      if (wheelTimer.current != null) window.clearTimeout(wheelTimer.current);
    };
  }, [ensureRaf]);

  useEffect(() => {
    applyTransforms();
  }, [applyTransforms]);

  const rowBg = { backgroundColor: theme.surfaceContainer };
  const chipColors = [theme.primary, theme.secondary, theme.tertiary, theme.primaryContainer, theme.secondaryContainer, theme.tertiaryContainer, theme.outlineVariant, theme.inverseSurface];
  // fix（第 16 条）：每枚胶囊用 M3 规范的 on-色配对（此前三枚主色胶囊全用 onPrimary，
  // 次色/三色胶囊文字对比度错误）；outlineVariant 无 on- 色令牌（边框色），按最近
  // 配对用 onSurface；inverseSurface 按 M3 规范配 inversePrimary。
  const chipOnColors = [theme.onPrimary, theme.onSecondary, theme.onTertiary, theme.onPrimaryContainer, theme.onSecondaryContainer, theme.onTertiaryContainer, theme.onSurface, theme.inversePrimary];

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          边界拉伸 Overscroll（Stretch Edge Effect · Android 12+）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          EdgeEffect.java TYPE_STRETCH {'{'}L98-148 常量 · L426-443 onPullDistance · L749-798 弹簧 · L820-838 阻尼向量{'}'} · StretchEffect.cpp {'{'}SkSL warp L29-185 · 逆映射 L248-303 · strength 0.7{'}'} · android-17.0.0_r1
        </span>
      </div>

      <div className="space-y-4 rounded-lg p-5" style={{ backgroundColor: theme.surfaceContainerLow }}>
        <div className="flex flex-col sm:flex-row gap-5 items-start">
          {/* 垂直：手机框内设置列表（单容器整块形变，与真机位图 warp 形态一致）。
              fix：列宽必须约束在外层列（sm:w-[340px] shrink-0），旧代码约束在内层手机框
              （max-w-[300px]），列本身被下方长文案的 max-content 撑到 ~1100px，
              flex-1 右列被挤到只剩 ~200px（胶囊被切断、文案挤成窄条）——桌面端布局混乱根因 */}
          <div className="w-full sm:w-[340px] sm:shrink-0">
            <div
              className="w-full max-w-[300px] rounded-[28px] border-8 border-slate-300 dark:border-slate-700 overflow-hidden shadow-sm"
              style={{ height: VIEWPORT_H + 48 + 16 }}
            >
              <div
                className="flex items-center gap-2 px-4"
                style={{ height: 48, backgroundColor: theme.surface }}
              >
                <span className="text-xs font-medium" style={{ color: theme.onSurface }}>
                  设置 · 壁纸和样式
                </span>
              </div>
              <div
                ref={verticalRef}
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerUp}
                className="relative select-none cursor-grab active:cursor-grabbing overflow-hidden"
                style={{
                  height: VIEWPORT_H,
                  backgroundColor: theme.surface,
                  // 浏览器默认行为阻拦：Chromium/Edge 原生过滚 + 滚动链（用户明确要求）；
                  // pan-x：横向手势交还父级（真机语义），垂直手势由本组件接管用于拉伸
                  // （不用 'none'：双轴全吞 → 手机上 Demo 区成为页面滚动死区）
                  overscrollBehavior: 'contain' as const,
                  touchAction: 'pan-x' as const,
                }}
                // 全局拉伸（src/aosp/globalStretch.ts）看到此标记会跳过，避免双重拉伸
                data-stretch-local="true"
                role="region"
                aria-label="边界拉伸演示列表（拖拽或滚轮到边界继续）"
              >
                {/* 单容器承载全部行：scale 作用于整块内容，行高随内容一起拉长、无行缝 */}
                <div ref={vContentRef} className="will-change-transform">
                  {ROWS.map((label, i) => (
                    <div
                      key={label}
                      role="presentation"
                      className="flex items-center gap-3 px-4"
                      style={{ height: ROW_H, ...rowBg }}
                    >
                      <span
                        className="h-8 w-8 rounded-full shrink-0"
                        style={{ backgroundColor: i % 3 === 0 ? theme.primaryContainer : i % 3 === 1 ? theme.secondaryContainer : theme.tertiaryContainer }}
                      />
                      <span className="text-sm truncate" style={{ color: theme.onSurface }}>
                        {label}
                      </span>
                      <span className="ml-auto text-xs shrink-0" style={{ color: theme.onSurfaceVariant }}>
                        &rsaquo;
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <p className="mt-2 text-[10px] text-slate-500 dark:text-slate-400 max-w-full break-all">
              拖拽/滚轮到顶或底继续用力 → 整块内容按 hwui 曲线拉伸（锚定边固定、行高随内容
              一起拉长、无行缝，与真机位图 warp 一致）；松手回弹（ω=24.657，ζ=0.98）；
              快速甩动撞击边界 → onAbsorb（×13）。
            </p>
          </div>

          {/* 水平：样式胶囊条（同轴同源，单容器 scaleX）。
              fix（第 18 条）：内容层显式 948px 后，其固有宽度会沿 fit-content 上传——
              移动端 flex-col + items-start 使右列宽度收缩为 fit-content，容器被撑到
              948px 造成页面横向溢出（实测 scrollW 1017 > 390）。max-w-full 上限把
              flex item 的交叉轴宽度压回列宽，桌面 sm:flex-row 行为不变。 */}
          <div className="flex-1 min-w-0 max-w-full space-y-3">
            <div
              ref={horizontalRef}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              className="relative overflow-hidden rounded-lg select-none cursor-grab active:cursor-grabbing"
              style={{
                height: 64,
                backgroundColor: theme.surface,
                // pan-y：纵向手势交还页面滚动（消除移动端死区），横向手势本组件接管
                overscrollBehavior: 'contain' as const,
                touchAction: 'pan-y' as const,
              }}
              data-stretch-local="true"
              role="region"
              aria-label="边界拉伸演示横向胶囊条（拖拽或滚轮到边界继续）"
            >
              {/* fix（第 18 条，用户报告"右缘继续拉伸方向反了"）：显式宽度 = 内容总宽。
                  此 div 是普通 block，宽度被父容器压成容器宽，而胶囊全部 position:absolute
                  不撑宽 —— transform-origin '100% 50%' 曾解析到容器右缘而非内容右缘
                  （H_CONTENT_W=948px），右缘过滚锚点失真：scale 固定点落在视口中部，
                  左半被推出屏、右半伸出屏外，视觉呈"从左往右拉伸"（真机应为锚定右缘、
                  从右往左拉伸）。显式宽度后 origin '100%' 精确落在内容右缘：p=948 →
                  屏幕 w（逐位一致），与左缘 '0' 对称，四向锚点齐全。 */}
              <div
                ref={hContentRef}
                className="will-change-transform h-full"
                style={{ width: H_CONTENT_W }}
              >
                {CHIPS.map((label, i) => (
                  <div
                    key={label}
                    role="presentation"
                    className="absolute top-2 flex items-center justify-center rounded-full will-change-transform"
                    style={{
                      width: CHIP_W,
                      height: 48,
                      left: i * (CHIP_W + CHIP_GAP),
                      backgroundColor: chipColors[i % chipColors.length],
                    }}
                  >
                    <span
                      className="text-xs font-medium"
                      style={{ color: chipOnColors[i % chipOnColors.length] }}
                    >
                      {label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400 break-all">
              双轴同源：每条边一个 EdgeEffect 实例（与 ScrollView 顶/底两实例一致，源码
              onPullDistance 的 max(0,·) 即单边恒正语义）；release 弹簧为解析欠阻尼解，
              近平衡处 200px/s + 8px 阈值切换线性插值速达（updateSpring L757-774）。
            </p>
            <div className="rounded-md px-3 py-2" style={{ backgroundColor: theme.surfaceContainer }}>
              <span
                ref={statusRef}
                className="font-mono text-[10px]"
                style={{ color: theme.onSurfaceVariant }}
              >
                mDistance 顶 0.000 / 底 0.000 · vecY 0.0000 · 静止
              </span>
            </div>
            <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
              <span className="font-medium">浏览器阻拦说明：</span>
              容器已设 <code className="font-mono">overscroll-behavior: contain</code>（阻断
              Windows Edge / Chrome 原生过滚动画与页面滚动链）、
              按轴 <code className="font-mono">touch-action</code>（垂直列表 pan-x、胶囊条
              pan-y，手势按真机语义仲裁，不产生页面滚动死区）+ Pointer Events 自管拖拽、
              wheel 非 passive + preventDefault（阻断原生滚轮平滑滚动）——缺一，原生动画
              就会盖住本效果。
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          <span className="font-medium text-slate-700 dark:text-slate-300">强度来源：</span>
          vecY = dampStretchVector(clamp(mDistance, −1, 1))，= 0.016·|v|（线性）+
          0.016·(1−e^(−|v|·e/0.33))（指数），最大约 ±0.032——内容拉伸上限为容器高的约
          3.2%（源码恒定常量，不随容器缩放）。
        </p>
        <p>
          <span className="font-medium text-slate-700 dark:text-slate-300">标准形变形态：</span>
          真机为 RenderNode 位图整体 warp：可见内容区间 [0, 1/(1+|o|)] 被拉伸铺满视口，
          锚定边（被拉的边）位移 0、远端被推出视口外，行高随内容一起拉长、行间无缝隙。
          本组件以单容器 <code className="font-mono">scale(1+|o|)</code>（origin=锚定边）
          复现：与源码精确映射在可见区间两端逐位一致（p=0→屏幕 0；p=1/(1+|o|)→屏幕 1），
          中段偏差 &lt;0.6% 视口高。
        </p>
        <p>
          <span className="text-amber-600 dark:text-amber-400">诚实声明：</span>
          ① Android 侧形变为 GPU 逐像素非线性 warp（近锚边拉伸强、远端弱，插值强度 0.7），
          Web 单容器 scale 在可见区间中段为线性近似（&lt;0.6% 视口高，人眼不可分辨）；
          ② 甩动减速为指数衰减近似（源码 SplineOverScroller 样条摩擦未移植），仅用于把
          动量带到边界；③ 滚轮空闲 120ms 触发 onRelease 为 Web 适配（源码由触摸抬起触发）；
          ④ prefers-reduced-motion 下效果禁用（对应源码 animators disabled → TYPE_NONE）。
          拉伸常量、弹簧参数、阻尼向量均为源码原值。
        </p>
      </div>
    </div>
  );
}
