"use client";
/**
 * M3 Expressive LoadingIndicator 演示区 —— 三变体 + show/hide 控制
 *
 * 变体依据（loadingindicator/res/values/styles.xml）：
 *  - 默认 Widget.Material3.LoadingIndicator：indicatorSize 34dp、容器 48dp、
 *    指示器色 = m3_comp_loading_indicator_active_indicator_color（colorPrimary）、容器透明
 *  - Contained 变体：容器 = m3_comp_loading_indicator_contained_container_color（colorPrimaryContainer）、
 *    指示器 = m3_comp_loading_indicator_contained_active_indicator_color（colorOnPrimaryContainer）
 *  - 多色序列：LoadingIndicator_indicatorColor 属性支持 int[]（LoadingIndicatorSpec.loadIndicatorColors），
 *    动画按 morphFactorTarget 逐色过渡（AnimatorDelegate L147-153）。
 *    演示取主题 primary → tertiary → secondary 三色，属于"属性能力演示"，非默认样式取值。
 */
import React, { useEffect, useState } from 'react';
import { Pause, Play } from '@/components/icons';
import { M3LoadingIndicator } from './M3LoadingIndicator';
import type { M3ThemeTokens } from '@/aosp/dynamicColor';

interface LoadingIndicatorDemoProps {
  theme: M3ThemeTokens;
}

export function LoadingIndicatorDemo({ theme }: LoadingIndicatorDemoProps) {
  const [running, setRunning] = useState(true);
  // 切换 pause/resume 时组件按 LoadingIndicator.show()/hide() 语义整体重启（resetPropertiesForNewStart）
  const [runKey, setRunKey] = useState(0);

  useEffect(() => {
    if (running) setRunKey((k) => k + 1);
  }, [running]);

  const cellLabel =
    'font-mono text-[10px] text-slate-500 dark:text-slate-400 whitespace-nowrap';
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          LoadingIndicator 加载指示器（M3 Expressive）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          MDC-Android 1.14.0 · loadingindicator/{'Spec · DrawingDelegate · AnimatorDelegate'}
        </span>
      </div>

      {/* Android 组件默认置于 48dp 容器内；外层底色仅为展示对比，非组件样式 */}
      <div
        className="flex flex-wrap items-center justify-center gap-10 rounded-lg py-8"
        style={{ backgroundColor: theme.surfaceContainerLow }}
      >
        <div className="flex flex-col items-center gap-3">
          <M3LoadingIndicator
            key={`default-${runKey}`}
            theme={theme}
            running={running}
          />
          <span className={cellLabel}>默认 · 34dp/48dp · colorPrimary</span>
        </div>
        <div className="flex flex-col items-center gap-3">
          <M3LoadingIndicator
            key={`contained-${runKey}`}
            theme={theme}
            running={running}
            contained
          />
          <span className={cellLabel}>Contained · onPrimaryContainer 容器</span>
        </div>
        <div className="flex flex-col items-center gap-3">
          <M3LoadingIndicator
            key={`multi-${runKey}`}
            theme={theme}
            running={running}
            indicatorColors={[theme.primary, theme.tertiary, theme.secondary]}
          />
          <span className={cellLabel}>多色序列 · primary→tertiary→secondary</span>
        </div>
        <div className="flex flex-col items-center gap-3">
          <button
            type="button"
            onClick={() => setRunning((r) => !r)}
            aria-pressed={!running}
            style={{
              backgroundColor: theme.primary,
              color: theme.onPrimary,
            }}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-full px-5 text-xs font-medium"
          >
            {running ? (
              <>
                <Pause size={16} strokeWidth={2} aria-hidden="true" />
                hide() 暂停
              </>
            ) : (
              <>
                <Play size={16} strokeWidth={2} aria-hidden="true" />
                show() 播放
              </>
            )}
          </button>
          <span className={cellLabel}>对应 show()/hide()：重启即 resetPropertiesForNewStart</span>
        </div>
      </div>

      <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          七形循环 SoftBurst→Cookie9→Pentagon→Pill→Sunny→Cookie4→Oval（normalize 到
          RectF(-1,-1,1,1)），每形 650ms 线性推进；每循环边界以弹簧（stiffness 200 / damping 0.6）
          驱动形变与附加 90° 旋转，欠阻尼回弹即 Android 真机上的"果冻感"来源；旋转公式
          140°·已成形数 + 50°·线性进度 + 90°·弹簧进度，mod 360。
        </p>
        <p>
          <span className="font-medium text-slate-600 dark:text-slate-300">诚实缺口：</span>
          Canvas.drawPath → SVG &lt;path&gt; 为 Web 适配（贝塞尔数据同源
          androidx.graphics.shapes 移植，见 aosp/materialShapes.ts）；颜色过渡按
          ArgbEvaluatorCompat 在线性空间插值；系统"移除动画"（prefers-reduced-motion）时绘制
          静态 ic_mtrl_arrow_circle 矢量并取指示器主色，对应源码 isSystemAnimatorDisabled 分支。
          多色序列为属性能力演示（属性支持 int[]），默认样式只有单一 colorPrimary。
        </p>
      </div>
    </div>
  );
}
