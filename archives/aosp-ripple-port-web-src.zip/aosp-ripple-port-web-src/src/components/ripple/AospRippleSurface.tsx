"use client";
import React, { useEffect, useRef } from 'react';
import {
  AOSP_MAX_RIPPLES,
  AospRippleEngineMode,
  effectiveRasterDpr,
  getSharedRippleRenderer,
  RippleColorRGBA,
  RippleSession,
  SystemUiRippleShape,
} from '../../aosp/RippleEngine';

export interface AospRippleSurfaceProps {
  children: React.ReactNode;
  className?: string;
  mode?: AospRippleEngineMode;
  color?: RippleColorRGBA;
  sparkleColor?: RippleColorRGBA;
  sparkleStrength?: number;
  distortionStrength?: number;
  systemUiShape?: SystemUiRippleShape;
  hasMask?: boolean;
  maskRadius?: number;
  maskRadii?: [number, number, number, number];
  maxRadiusOverride?: number | null;
  speedMultiplier?: number;
  densityScale?: number;
  centered?: boolean;
  unboundedPadding?: number;
  style?: React.CSSProperties;
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  role?: string;
  tabIndex?: number;
  ariaLabel?: string;
  ariaPressed?: boolean;
}

const DEFAULT_WAVE_COLOR: RippleColorRGBA = { r: 0.31, g: 0.27, b: 0.9, a: 0.22 };
const DEFAULT_SPARKLE_COLOR: RippleColorRGBA = {
  r: 1.0,
  g: 1.0,
  b: 1.0,
  a: 0x8d / 255,
};

function parseCssRadiusPx(raw: string, w: number, h: number, fallback: number): number {
  if (!raw) return fallback;
  const trimmed = raw.trim().split(' ')[0];
  if (trimmed.endsWith('%')) {
    const pct = parseFloat(trimmed);
    return Number.isFinite(pct) ? (pct / 100) * Math.min(w, h) : fallback;
  }
  const px = parseFloat(trimmed);
  return Number.isFinite(px) ? px : fallback;
}

function readLiveCornerRadii(
  host: HTMLElement,
  w: number,
  h: number,
  fallbackRadii: [number, number, number, number]
): [number, number, number, number] {
  const cs = getComputedStyle(host);
  return [
    parseCssRadiusPx(cs.borderTopLeftRadius, w, h, fallbackRadii[0]),
    parseCssRadiusPx(cs.borderTopRightRadius, w, h, fallbackRadii[1]),
    parseCssRadiusPx(cs.borderBottomRightRadius, w, h, fallbackRadii[2]),
    parseCssRadiusPx(cs.borderBottomLeftRadius, w, h, fallbackRadii[3]),
  ];
}

export const AospRippleSurface: React.FC<AospRippleSurfaceProps> = ({
  children,
  className = '',
  mode = 'framework',
  color = DEFAULT_WAVE_COLOR,
  sparkleColor = DEFAULT_SPARKLE_COLOR,
  sparkleStrength = 0.3,
  distortionStrength = 1.0,
  systemUiShape = 'circle',
  hasMask = true,
  maskRadius = 16,
  maskRadii,
  maxRadiusOverride = null,
  speedMultiplier = 1.0,
  densityScale = 2.1,
  centered = false,
  unboundedPadding = 24,
  style,
  onClick,
  role,
  tabIndex,
  ariaLabel,
  ariaPressed,
}) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionsRef = useRef<RippleSession[]>([]);
  const touchNormMapRef = useRef<WeakMap<RippleSession, { nx: number; ny: number }>>(
    new WeakMap()
  );
  const activePointerSessionRef = useRef<RippleSession | null>(null);
  const rafRef = useRef<number | null>(null);
  const nextIdRef = useRef(1);

  const propsRef = useRef({
    mode,
    color,
    sparkleColor,
    sparkleStrength,
    distortionStrength,
    systemUiShape,
    hasMask,
    maskRadius,
    maskRadii,
    maxRadiusOverride,
    speedMultiplier,
    densityScale,
    centered,
    unboundedPadding,
  });

  useEffect(() => {
    propsRef.current = {
      mode,
      color,
      sparkleColor,
      sparkleStrength,
      distortionStrength,
      systemUiShape,
      hasMask,
      maskRadius,
      maskRadii,
      maxRadiusOverride,
      speedMultiplier,
      densityScale,
      centered,
      unboundedPadding,
    };
  });

  const startLoop = () => {
    if (rafRef.current !== null) return;

    const tick = () => {
      const host = hostRef.current;
      const canvas = canvasRef.current;
      if (!host || !canvas) {
        rafRef.current = null;
        return;
      }

      const p = propsRef.current;
      const now = performance.now();
      const sessions = sessionsRef.current;
      const rect = host.getBoundingClientRect();
      const pad = p.hasMask ? 0 : p.unboundedPadding;
      const width = Math.max(1, rect.width + pad * 2);
      const height = Math.max(1, rect.height + pad * 2);
      // 第 26 轮：涟漪面为小画布（24-96dp+pad），逐帧重设缓冲代价可忽略，
      // 改按真实 dpr×捏合缩放重建（cap 8）——与状态层/形变指示器同口径
      const dpr = effectiveRasterDpr(8);

      const fallbackRadii: [number, number, number, number] = p.maskRadii ?? [
        p.maskRadius,
        p.maskRadius,
        p.maskRadius,
        p.maskRadius,
      ];
      const liveRadii = p.hasMask
        ? readLiveCornerRadii(host, rect.width, rect.height, fallbackRadii)
        : fallbackRadii;

      for (const s of sessions) {
        s.config.dpr = dpr;
        s.config.width = width;
        s.config.height = height;
        s.config.originX = width * 0.5;
        s.config.originY = height * 0.5;
        s.config.hasMask = p.hasMask;
        s.config.maskRadius = liveRadii[0];
        s.config.maskRadii = liveRadii;
        s.config.color = p.color;
        s.config.sparkleColor = p.sparkleColor;
        s.config.sparkleStrength = p.sparkleStrength;
        s.config.distortionStrength = p.distortionStrength;
        s.config.speedMultiplier = p.speedMultiplier;
        s.config.densityScale = p.densityScale;
        const norm = touchNormMapRef.current.get(s);
        if (norm) {
          s.config.touchX = p.centered ? width * 0.5 : norm.nx * width;
          s.config.touchY = p.centered ? height * 0.5 : norm.ny * height;
        }
      }

      const pw = Math.round(width * dpr);
      const ph = Math.round(height * dpr);
      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
      }

      const renderer = getSharedRippleRenderer();
      renderer.renderSessions(sessions, width, height, dpr, now);

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, pw, ph);
        if (sessions.length > 0 && renderer.isSupported()) {
          ctx.drawImage(renderer.canvas, 0, 0, pw, ph, 0, 0, pw, ph);
        }
      }

      sessionsRef.current = sessions.filter((s) => !s.finished);

      if (sessionsRef.current.length > 0) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        if (ctx) ctx.clearRect(0, 0, pw, ph);
        rafRef.current = null;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  };

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  const spawnRipple = (touchX: number, touchY: number, hostWidth: number, hostHeight: number) => {
    const p = propsRef.current;
    const host = hostRef.current;
    // 与 tick 同口径：session dpr 必须等于渲染循环 dpr（tick 每帧会重写 config.dpr）
    const dpr = effectiveRasterDpr(8);
    const pad = p.hasMask ? 0 : p.unboundedPadding;
    const canvasW = Math.max(1, hostWidth + pad * 2);
    const canvasH = Math.max(1, hostHeight + pad * 2);
    const originX = canvasW * 0.5;
    const originY = canvasH * 0.5;

    const fallbackRadii: [number, number, number, number] = p.maskRadii ?? [
      p.maskRadius,
      p.maskRadius,
      p.maskRadius,
      p.maskRadius,
    ];
    const initialRadii =
      p.hasMask && host
        ? readLiveCornerRadii(host, hostWidth, hostHeight, fallbackRadii)
        : fallbackRadii;

    if (sessionsRef.current.length >= AOSP_MAX_RIPPLES) {
      sessionsRef.current.shift();
    }

    const resolvedTouchX = p.centered ? originX : touchX + pad;
    const resolvedTouchY = p.centered ? originY : touchY + pad;

    const session = new RippleSession(
      nextIdRef.current++,
      {
        mode: p.mode,
        touchX: resolvedTouchX,
        touchY: resolvedTouchY,
        originX,
        originY,
        width: canvasW,
        height: canvasH,
        dpr,
        maxRadiusOverride: p.maxRadiusOverride,
        color: p.color,
        sparkleColor: p.sparkleColor,
        sparkleStrength: p.sparkleStrength,
        distortionStrength: p.distortionStrength,
        systemUiShape: p.systemUiShape,
        hasMask: p.hasMask,
        maskRadius: initialRadii[0],
        maskRadii: initialRadii,
        densityScale: p.densityScale,
        speedMultiplier: p.speedMultiplier,
      },
      performance.now()
    );

    touchNormMapRef.current.set(session, {
      nx: resolvedTouchX / canvasW,
      ny: resolvedTouchY / canvasH,
    });

    sessionsRef.current.push(session);
    activePointerSessionRef.current = session;
    startLoop();
    return session;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const host = hostRef.current;
    if (!host) return;
    const rect = host.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    spawnRipple(x, y, rect.width, rect.height);
  };

  const releaseActive = () => {
    if (activePointerSessionRef.current) {
      activePointerSessionRef.current.release(performance.now());
      activePointerSessionRef.current = null;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      const host = hostRef.current;
      if (!host) return;
      const rect = host.getBoundingClientRect();
      const session = spawnRipple(
        rect.width * 0.5,
        rect.height * 0.5,
        rect.width,
        rect.height
      );
      window.setTimeout(() => session.release(performance.now()), 120);
      if (onClick) {
        onClick(e as unknown as React.MouseEvent<HTMLDivElement>);
      }
    }
  };

  const pad = hasMask ? 0 : unboundedPadding;

  return (
    <div
      ref={hostRef}
      role={role}
      tabIndex={tabIndex}
      aria-label={ariaLabel}
      aria-pressed={ariaPressed}
      onPointerDown={handlePointerDown}
      onPointerUp={releaseActive}
      onPointerCancel={releaseActive}
      onPointerLeave={releaseActive}
      onKeyDown={handleKeyDown}
      onClick={onClick}
      style={style}
      className={`relative select-none cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--md-sys-color-primary)] ${
        hasMask ? 'overflow-hidden' : 'overflow-visible'
      } ${className}`}
    >
      <div className="relative z-10">{children}</div>
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        style={{
          top: -pad,
          left: -pad,
          width: `calc(100% + ${pad * 2}px)`,
          height: `calc(100% + ${pad * 2}px)`,
        }}
        className="pointer-events-none absolute z-20"
      />
    </div>
  );
};
