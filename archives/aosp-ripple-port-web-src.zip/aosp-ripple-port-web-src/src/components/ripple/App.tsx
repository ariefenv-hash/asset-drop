"use client";
import { useEffect, useMemo, useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import { FrameworkUniformSnapshot } from '@/aosp/RippleEngine';
import { AmbientBackdrop } from './AmbientBackdrop';
import { ComponentGallery } from './ComponentGallery';
import { CurveAndMathPanel } from './CurveAndMathPanel';
import {
  DEFAULT_LAB_CONFIG,
  InteractiveLab,
  LabConfigState,
  resolveTheme,
} from './InteractiveLab';
import { SourceInspector } from './SourceInspector';
import { VariableFontPlayground } from './VariableFontPlayground';
import { SplitButtonDemo } from './SplitButtonDemo';
import { WavyProgressDemo } from './WavyLinearProgressDemo';
import { WavyCircularDemo } from './WavyCircularProgressDemo';
import { LoadingIndicatorDemo } from './LoadingIndicatorDemo';
import { MaterialButtonGroupDemo } from './MaterialButtonGroupDemo';
import { StretchOverscrollDemo } from './StretchOverscrollDemo';
import { useGlobalStretchOverscroll } from '@/aosp/globalStretch';
import { withBasePath } from '@/lib/publicPath';
import { ColorSchemePreviewDemo } from './ColorSchemePreviewDemo';
import { M3CoreComponentsGallery } from './M3CoreComponentsGallery';
import { M3StructuralComponentsGallery } from './M3StructuralComponentsGallery';

export default function App() {
  const [isDark, setIsDark] = useState(false);
  const [config, setConfig] = useState<LabConfigState>(DEFAULT_LAB_CONFIG);
  const [telemetry, setTelemetry] = useState<FrameworkUniformSnapshot | null>(null);

  // 全站边界拉伸：ref 挂到内容包裹层；监听/形变见 src/aosp/globalStretch.ts
  const setStretchTarget = useGlobalStretchOverscroll();

  const theme = useMemo(() => resolveTheme(config, isDark), [config, isDark]);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.style.setProperty('--md-sys-color-primary', theme.primary);
    root.style.setProperty('--md-sys-color-on-primary', theme.onPrimary);
    root.style.setProperty('--md-sys-color-primary-container', theme.primaryContainer);
    root.style.setProperty('--md-sys-color-on-primary-container', theme.onPrimaryContainer);
    root.style.setProperty('--md-sys-color-secondary-container', theme.secondaryContainer);
    root.style.setProperty('--md-sys-color-on-secondary-container', theme.onSecondaryContainer);
    root.style.setProperty('--md-sys-color-surface', theme.surface);
    root.style.setProperty('--md-sys-color-on-surface', theme.onSurface);
    root.style.setProperty('--md-sys-color-outline', theme.outline);
    root.style.setProperty('--md-sys-color-outline-variant', theme.outlineVariant);
  }, [isDark, theme]);

  return (
    <div className="relative z-10 min-h-screen text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Bar Contract: 3 zones (wordmark, 5 concise single-line links, 1 action)。
          顶栏置于形变层之外（Android 语义：拉伸只作用于滚动视图内容，AppBar 不参与拉伸）。
          修复（第 16 条）：header 原在形变层内，全局 overscroll 拉伸的 scale3d 以整页为
          origin 基准，会把 sticky 顶栏推离视口顶（实测 transform 生效瞬间 header.top =
          -242px，滚动内容整体跳变——页面级"混乱"根因），并使 sticky 定位失效。 */}
      <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-6 py-4">
            <a
              href="#lab"
              className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
            >
              AOSP Ripple Port
            </a>

            <nav
              aria-label="主导航"
              className="hidden md:flex min-w-0 overflow-x-auto items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
            >
              <a
                href="#lab"
                className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                交互实验
              </a>
              <a
                href="#ambient"
                className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                动态配色
              </a>
              <a
                href="#gallery"
                className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                组件移植
              </a>
              <a
                href="#additions"
                className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                新增组件
              </a>
              <a
                href="#official"
                className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                官方对照
              </a>
              <a
                href="#source"
                className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                源码对照
              </a>
            </nav>

            <div className="flex items-center shrink-0">
              <button
                type="button"
                onClick={() => setIsDark((d) => !d)}
                style={{
                  backgroundColor: theme.primary,
                  color: theme.onPrimary,
                }}
                className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-medium hover:opacity-90 transition-opacity whitespace-nowrap shrink-0"
              >
                {isDark ? (
                  <>
                    <Sun className="h-3.5 w-3.5" />
                    浅色模式
                  </>
                ) : (
                  <>
                    <Moon className="h-3.5 w-3.5" />
                    深色模式
                  </>
                )}
              </button>
            </div>
          </div>
      </header>

      {/* 全站边界拉伸形变层（Stretch Edge Effect, Android 12+）：拉伸只作用于滚动内容
           main+footer；fixed 壁纸背景层经 portal 渲染在本层之外（Android 语义：壁纸与
           AppBar 不参与拉伸，被拉伸的是滚动视图本身） */}
      <div ref={setStretchTarget}>
        <main className="mx-auto max-w-7xl px-6 py-10 space-y-16">
          <section className="max-w-3xl space-y-3">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span>AOSP Android 12–17</span>
              <span aria-hidden="true">·</span>
              <span>RippleShader &amp; Expressive Controls</span>
              <span aria-hidden="true">·</span>
              <span>Monet HCT &amp; RoundedPolygon Cubic Morph</span>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white [text-wrap:balance]">
              Android 12–17 表达性涟漪、曲线形变与动态色彩移植
            </h1>
            <p className="text-base leading-relaxed text-slate-600 dark:text-slate-300">
              完整对照 AOSP <code className="font-mono text-xs">RippleShader.java</code>、SystemUI{' '}
              <code className="font-mono text-xs">RippleShader.kt</code>、<code className="font-mono text-xs">androidx.graphics.shapes</code>{' '}
              多边形圆角三次贝塞尔插值，以及 Material Color Utilities HCT 动态色彩与对比度校验引擎。
            </p>
          </section>

          <AmbientBackdrop
            config={config}
            onConfigChange={setConfig}
            theme={theme}
          />

          <InteractiveLab
            isDark={isDark}
            config={config}
            theme={theme}
            onConfigChange={setConfig}
            onTelemetryUpdate={setTelemetry}
          />

          <ComponentGallery isDark={isDark} config={config} theme={theme} />

          {/* 新增组件：本阶段从 MDC-Android 1.14.0 源码忠实转译 */}
          <section id="additions" className="scroll-mt-24 space-y-6">
            <div className="max-w-3xl space-y-2">
              <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                新增组件 · 源码忠实转译
              </h2>
              <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                依据工作日志三条铁律：不自造样式、保证视觉语言、没有的诚实说明。
                以下组件的全部几何、颜色与动画参数均逐项取自本地真实源码（MDC-Android 1.14.0、
                AOSP frameworks/base EdgeEffect/hwui/monet、ThemePicker 壁纸取色 UI，
                全部锁 android-17.0.0_r1 manifest），源文件路径与取值在组件头部注释与页面标注中可核查。
              </p>
            </div>
            <SplitButtonDemo theme={theme} />
            <MaterialButtonGroupDemo theme={theme} />
            <WavyProgressDemo theme={theme} config={config} />
            <WavyCircularDemo theme={theme} config={config} />
            <LoadingIndicatorDemo theme={theme} />
            <StretchOverscrollDemo theme={theme} />
            {/* 第 25 轮：圆形预览接入明暗双向（点击浅/深行 = 应用该风格 + 该行明暗模式） */}
            <ColorSchemePreviewDemo theme={theme} config={config} onConfigChange={setConfig} isDark={isDark} onDarkChange={setIsDark} />
            {/* 第 18 轮：M3 官方 24 类对标缺口补齐（Badges/Checkbox/Radio/Chips/
                Snackbar/Tabs/Cards/Dialogs/Divider/Menus/Tooltips/Text fields），
                全部 token 接线自 MDC-Android 1.14.0 官方 AAR + tokens.xml（取证
                通道矩阵见组件头注释与工作日志）
                第 21 轮：官方清单终局补齐（App bars/Navigation×3/Sheets×2/Search/
                Carousel/Date/Time/FABs/Lists），m3.material.io 六大类 35 项全覆盖 */}
            <M3CoreComponentsGallery theme={theme} config={config} />
            <M3StructuralComponentsGallery theme={theme} config={config} />
          </section>

          {/* 修正记录：本阶段按 Android 17 (android-17.0.0_r1) 修正的三处偏差 */}
          <section id="corrections" className="scroll-mt-24 space-y-4">
            <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              修正记录 · 按 Android 17 真实源码
            </h2>
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full min-w-[620px] text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300">
                  <tr>
                    <th className="px-4 py-2.5 font-medium">偏差项</th>
                    <th className="px-4 py-2.5 font-medium">Android 17 真实值</th>
                    <th className="px-4 py-2.5 font-medium">修正动作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  <tr>
                    <td className="px-4 py-2.5 font-mono">SystemUI 涟漪时长</td>
                    <td className="px-4 py-2.5">
                      <code className="font-mono">DEFAULT_RIPPLE_EFFECT_DURATION = 3000</code>
                    </td>
                    <td className="px-4 py-2.5">
                      750ms（A13/14 旧值）→ 3000ms，并在 SystemUI 模式下暴露 A17/旧版对照切换
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-mono">像素密度来源</td>
                    <td className="px-4 py-2.5">
                      <code className="font-mono">resources.displayMetrics.density</code>
                    </td>
                    <td className="px-4 py-2.5">
                      <code className="font-mono">densityScale/0.8</code> 反推 → 改取 devicePixelRatio，
                      <span className="text-amber-600 dark:text-amber-400">已如实标注为 Web 适配近似</span>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-mono">最大扩散半径</td>
                    <td className="px-4 py-2.5">调用方传入视图实际尺寸</td>
                    <td className="px-4 py-2.5">
                      自创 <code className="font-mono">hypot(w,h)×1.65</code> → 改取视图最大边
                      <code className="font-mono">max(w,h)</code>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-mono">滑块拖动跟手性</td>
                    <td className="px-4 py-2.5">
                      <code className="font-mono">BaseSlider</code> 手柄/轨道位置无任何过渡动画（拖动即
                      <code className="font-mono">invalidate</code>），唯一动画是标签进出场 83/117ms
                    </td>
                    <td className="px-4 py-2.5">
                      移除自创的 75ms/150ms 位置·宽度过渡；拖动期改 rAF 命令式写 DOM +
                      pointermove 逐帧合并 + rect 缓存，快速拖动不再滞后；气泡进出场改为源码值
                      83ms（Decelerate）/117ms（FastOutLinearIn）
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
              其余工程缺陷（依赖冲突、AI Studio 模板残留、页脚 ZIP 404、遥测滞后一帧）已在本次
              Next.js 重建中一并处理；完整评估见《Gemini移植包展示质量评估报告》与工作日志。
            </p>
          </section>

          {/* 官方 md-ripple 同台对照（真实 @material/web 2.5.0，importmap 脱管运行） */}
          <section id="official" className="scroll-mt-24 space-y-4">
            <div className="max-w-3xl space-y-2">
              <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                官方 Web 版对照 · @material/web 2.5.0
              </h2>
              <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                以下为真实 npm 包 @material/web 2.5.0（md-ripple 走 Web Components + WAAPI
                状态机：PRESS_GROW 450ms · MINIMUM_PRESS 225ms · TOUCH_DELAY 150ms ·
                RELEASE 300ms），与本页的 AOSP 系统级星斑涟漪属两条技术路线，可在同一预览中直接对比
                按压手感。
              </p>
              <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                <strong className="text-slate-900 dark:text-white">开关按压的源码实证（第 22 轮核对）：</strong>
                md-switch 的 md-ripple 实例挂在 handle-container 内随小球移动（switch.js L116），并被
                <code className="mx-1 rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[12px] dark:bg-slate-800">_handle.scss L134-140</code>
                钉死为 40×40（state-layer-size）、border-radius: full 的圆形状态层（inset: unset）——
                按压涟漪从触点生长但被裁进这只贴着小球的小圆（pressed 透明度 0.12），
                <strong>永远不会扩散过整条轨道</strong>；小球本体则 24→28px（100ms linear）。
                据此本页移植版开关已撤掉按全局无界涟漪的"滥用"写法，改为同几何的约束状态层。
              </p>
            </div>
            <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800">
              <iframe
                src={withBasePath('/official-md-ripple/index.html')}
                title="官方 @material/web md-ripple / md-switch 按压对照"
                className="h-[860px] w-full bg-white"
                loading="lazy"
              />
            </div>
          </section>

          <CurveAndMathPanel mode={config.mode} telemetry={telemetry} theme={theme} />

          <section id="typography" className="scroll-mt-24">
            <VariableFontPlayground theme={theme} />
          </section>
          <SourceInspector />
        </main>

        <footer id="about" className="scroll-mt-24 border-t border-slate-200 dark:border-slate-800">
          {/* 第 22 轮（用户要求）：页尾新增项目性质说明 */}
          <div className="mx-auto max-w-7xl px-6 py-10">
            <h2 className="font-display text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              关于本项目 · 项目性质说明
            </h2>
            <div className="mt-5 grid gap-6 md:grid-cols-3">
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">性质与定位</h3>
                <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                  本页是<b>学习 / 研究性质的开源移植复现演示</b>，不是 Google 官方产品，也与
                  Google、AOSP、Material Design 团队无任何隶属、合作或背书关系。
                  Material、Android 及相关标志是其各自所有者（Google LLC）的商标，此处仅作
                  技术性指称。演示内容以复现手感与核对参数为目的，不承诺与任何官方实现逐像素一致。
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">数据与代码溯源</h3>
                <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                  涟漪着色器与动画时序移植自 AOSP frameworks（RippleShader /
                  RippleAnimationSession，Apache-2.0）；组件 token 逐项核对
                  MDC-Android 1.14.0 AAR 与官方 @material/web 2.5.0 npm 包（页内 vendor/
                  与 pkg/ 即其原文，Apache-2.0）。凡无法核实或属 Web 适配近似的参数，
                  一律在源码对照区如实标注，不以讹传讹。
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">交互与分发说明</h3>
                <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                  本站开关支持<b>按压微放大、按住左右拖拽、松手自动吸附判定</b>（越过行程中点即切换，
                  未过则回弹），可通过上方组件移植区体验；官方按压行为可在"官方对照"区的
                  md-switch 上直接对比。整站源码可从下方 ZIP 下载包获取，遵循各上游项目的
                  Apache-2.0 / OFL 许可证分发。
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-200 dark:border-slate-800 py-8">
            <div className="mx-auto flex max-w-7xl flex-col sm:flex-row items-center justify-between gap-4 px-6 text-xs text-slate-500 dark:text-slate-400">
              <span>
                Shader math, HCT color tokens &amp; animation timings ported from AOSP / MDC-Android (Apache-2.0)
              </span>
              <div className="flex flex-wrap items-center gap-4">
                <a
                  href={withBasePath('/aosp-ripple-port-src.zip')}
                  download="aosp-ripple-port-src.zip"
                  style={{ color: theme.primary }}
                  className="font-medium hover:underline whitespace-nowrap"
                >
                  下载源码包 (ZIP)
                </a>
                <span aria-hidden="true">·</span>
                <span className="font-mono">
                  ENTER 450ms · EXIT 375ms · NOISE 7000ms · SYSTEMUI 3000ms (A17)
                </span>
              </div>
            </div>
          </div>
        </footer>
      </div>
      {/* 拉伸层之外宿主：AmbientBackdrop 的 fixed 壁纸背景经 createPortal 渲染于此，
           避免 transform 破坏 position:fixed / 壁纸被拉变形（拉伸只作用于滚动视图） */}
      <div id="stretch-portal-host" aria-hidden="true" />
    </div>
  );
}
