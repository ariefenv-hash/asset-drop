"use client";
/**
 * M3 画廊共享壳层 · 第 21 轮代码质量整合
 * ============================================================
 * 【目的】把 M3CoreComponentsGallery 与 M3StructuralComponentsGallery
 *  两个画廊的公共基建（token 常量、类型、组件卡片壳、涟漪公共参数）
 *  收敛到单一来源，消除跨文件复制，便于整包迁移到其他工程。
 *
 * 【取值来源】全部常量逐项核实自 MDC-Android 1.14.0 官方发布 AAR
 *  （dl.google.com 通道，res/values/values.xml 宏形态）：
 *   · SHADOW  ← m3_sys_elevation_level0..5（0/1/3/6/8/12dp，Web 阴影为适配 ◇）
 *   · SHAPE   ← m3_sys_shape_corner_value_*（xs4/sm8/md12/lg16/lgInc20/
 *               xl28/xlInc32/xxl48，full = 半径取短边一半）
 *   · STATE_LAYER ← m3_sys_state_{hover,focus,pressed,disabled,dragged}
 *               _state_layer_opacity（0.08/0.10/0.10/0.38/0.16 ✓）
 *   · TYPE    ← M3 字型规范（与各组件 tokens.xml 的 ?attr/textAppearance*
 *               引用对应；labelMedium 12/500 · labelLarge 14/500 ·
 *               titleSmall 14/500 · titleMedium 16/500 · titleLarge 22/400 ·
 *               bodyLarge 16/400 · bodyMedium 14/400 · bodySmall 12/400 ·
 *               headlineLarge 32/400 · displayLarge 57/400）
 * ============================================================
 */
import React from 'react';
import { hexToRgbaWave, M3ThemeTokens } from '../../aosp/dynamicColor';
import { AospRippleSurface } from './AospRippleSurface';
import { LabConfigState } from './InteractiveLab';

export interface GalleryProps {
  theme: M3ThemeTokens;
  config: LabConfigState;
}

/** AospRippleSurface 全量 props 类型（两个画廊统一引用） */
export type RippleCommon = Parameters<typeof AospRippleSurface>[0];

/** M3 字型刻度（tokens.xml 经 ?attr/textAppearance* 引用） */
export const TYPE = {
  labelMedium: { fontSize: 12, lineHeight: '16px', fontWeight: 500 } as const,
  labelLarge: { fontSize: 14, lineHeight: '20px', fontWeight: 500 } as const,
  bodySmall: { fontSize: 12, lineHeight: '16px', fontWeight: 400 } as const,
  bodyMedium: { fontSize: 14, lineHeight: '20px', fontWeight: 400 } as const,
  bodyLarge: { fontSize: 16, lineHeight: '24px', fontWeight: 400 } as const,
  titleSmall: { fontSize: 14, lineHeight: '20px', fontWeight: 500 } as const,
  titleMedium: { fontSize: 16, lineHeight: '24px', fontWeight: 500 } as const,
  titleLarge: { fontSize: 22, lineHeight: '28px', fontWeight: 400 } as const,
  headlineSmall: { fontSize: 24, lineHeight: '32px', fontWeight: 400 } as const,
  headlineLarge: { fontSize: 32, lineHeight: '40px', fontWeight: 400 } as const,
  displayLarge: { fontSize: 57, lineHeight: '64px', fontWeight: 400 } as const,
};

/** m3_sys_elevation_level0..5 ✓（CSS box-shadow 为 Web 适配 ◇） */
export const SHADOW = {
  level0: 'none',
  level1: '0 1px 2px rgba(0,0,0,0.30), 0 1px 3px 1px rgba(0,0,0,0.15)',
  level2: '0 1px 3px rgba(0,0,0,0.30), 0 4px 8px 3px rgba(0,0,0,0.15)',
  level3: '0 3px 5px rgba(0,0,0,0.30), 0 6px 10px 4px rgba(0,0,0,0.15)',
  level4: '0 5px 7px rgba(0,0,0,0.30), 0 8px 12px 6px rgba(0,0,0,0.15)',
  level5: '0 7px 10px rgba(0,0,0,0.30), 0 12px 18px 8px rgba(0,0,0,0.15)',
} as const;

/** m3_sys_shape_corner_value_* ✓（MDC-Android 1.14.0 AAR 逐项核实） */
export const SHAPE = {
  none: 0,
  extraSmall: 4,
  small: 8,
  medium: 12,
  large: 16,
  largeIncreased: 20,
  extraLarge: 28,
  extraLargeIncreased: 32,
  extraExtraLarge: 48,
  full: 9999,
} as const;

/** m3_sys_state_*_state_layer_opacity ✓（AAR 宏形态逐项核实） */
export const STATE_LAYER = {
  hover: 0.08,
  focus: 0.1,
  pressed: 0.1,
  disabled: 0.38,
  dragged: 0.16,
} as const;

/** M3 规范静态 error 色板（AAR m3_ref_palette_error* 逐位核实 ✓） */
export function errorColors(isDark: boolean) {
  return isDark
    ? { error: '#F2B8B5', onError: '#601410' } // error80 / error20 ✓
    : { error: '#B3261E', onError: '#FFFFFF' }; // error40 / error100 ✓
}

/** 组件卡片壳：标题 + token 出处标注 + 内容（两个画廊统一外观） */
export const SECTION_TITLE: React.CSSProperties = { fontSize: 15, fontWeight: 600 };

export function Cell({ title, note, children, span }: { title: string; note: string; children: React.ReactNode; span?: string }) {
  return (
    <div className={`rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-4 ${span ?? ''}`}>
      <div>
        <h4 className="font-display" style={SECTION_TITLE}>{title}</h4>
        <p className="mt-1 font-mono text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">{note}</p>
      </div>
      {children}
    </div>
  );
}

/** AospRippleSurface 公共参数（涟漪色 = primary@16%，其余随实验室配置）。
 *  两个画廊统一取值，避免每处手写遗漏配置项。 */
export function makeRipple(theme: M3ThemeTokens, config: LabConfigState) {
  return {
    mode: config.mode,
    color: hexToRgbaWave(theme.primary, 0.16),
    sparkleColor: { r: 1, g: 1, b: 1, a: config.sparkleAlpha },
    sparkleStrength: config.sparkleStrength,
    distortionStrength: config.distortionStrength,
    systemUiShape: config.systemUiShape,
    speedMultiplier: config.speedMultiplier,
    densityScale: config.densityScale,
  };
}
