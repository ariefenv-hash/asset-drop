"use client";
/**
 * Wavy CircularProgressIndicator（确定态 + 不定态 retreat）—— 按官方 m3.material.io 展示规格对齐重写
 *
 * 本轮按用户指令「一一对照官方展示网站规格」实现。官方规格的参考实现为 Android 官方
 * Compose M3 Expressive 源码（本地 sources/androidx-m3-android，2025 Copyright AOSP），
 * 令牌与 MDC-Android 1.14.0 一致（WaveSize 48dp / thickness 4dp / gap 4dp / λ 15dp）。
 *
 * 【为什么改掉旧版】旧版照抄 MDC-Android CircularDrawingDelegate.createWavyPath
 * （锚点只向内压 2×1.6dp 的 9 点内凹波、恒定满幅、相位静止）——静止时呈"齿轮/多边形"感且
 * 填充部分始终可见。官方机制（CircularWavyProgressModifiers.kt / WavyProgressIndicator.kt）：
 *  1. 形状是 圆 ↔ RoundedPolygon.star 的 Morph（CircularShapes L1338-1359）：
 *     numVertices = max(5, round(2πr/λ))（r = 尺寸/2 − 描边/2 = 22，λ=15 → 9 齿）；
 *     star(numVerticesPerRadius=9, innerRadius=0.75, rounding=CornerRounding(0.35, 0.4),
 *     innerRounding=CornerRounding(0.5))——外半径 = 轨道半径 22、谷径 = 0.75·22 = 16.5；
 *     Morph.toPath(progress = amplitude)（L1385-1394）→ 振幅 0 = 正规圆、振幅 1 = 全花形。
 *  2. 振幅由 progress 驱动（官方 indicatorAmplitude，WavyProgressIndicator.kt L490-497）：
 *     progress ≤ 0.10 或 ≥ 0.95 → 振幅 0（正规圆）；其余 → 1；以 500ms tween 过渡
 *     （Increasing=EasingStandard (0.2,0,0,1) / Decreasing=EasingEmphasizedAccelerate
 *     (0.3,0,0.8,0.15)，MotionTokens.DurationLong2=500）。静止/空载时就是正规圆。
 *  3. 波形相位持续滚动：offset 时长 = (λ/waveSpeed)·1000·vertexCount（L341-380，默认
 *     waveSpeed=λ → 每 9s 滚动一整圈 = 每秒 1 个波长）；取段 [0+shift, end+shift] 后按
 *     −offset·360° 旋转补偿（updateDrawPaths L1214-1239）→ 端点固定、波形滑动。
 *  4. 轨道始终为圆（trackPathProvider → trackPolygon 圆多边形，L311-317），不随波形形变；
 *     轨道两端留 trackSpacing = 2·min(pStop,capWidth) + min(pStop,gap)（L1207-1209）。
 *
 * 【不定态 retreat】（ProgressIndicator.kt L929-977 / L1069-1076 官方常量）
 *  - 周期 6000ms；恒定旋转 1080°（LinearEasing）；附加旋转 4×90° 突转（各 300ms
 *    EasingEmphasizedDecelerate (0.05,0.7,0.1,1)，于 0/1500/3000/4500ms 起，随后保持）；
 *  - 弧长 sweep 0.1 ↔ 0.87（CircularIndeterminateMin/MaxProgress），两程均
 *    EasingStandardCubicBezier (0.2,0,0,1)（circularIndeterminateProgressAnimationSpec）；
 *  - 振幅恒 1（WavyProgressIndicator.kt L360 默认值）；整体旋转 = global + additional。
 *
 * 【诚实缺口】
 *  1. graphics-shapes 库（RoundedPolygon/Morph 的角部圆角+smoothing 算法）不在本地源码树，
 *     花形以极径余弦近似：r(θ) = 22 − amp·(22−16.5)·(1−cos9θ)/2 —— 边界（外 22 / 谷 16.5）、
 *     齿数 9、振幅 0↔1 Morph 语义与官方一致；官方 Morph 为贝塞尔控制点线性插值，中间态
 *     形状有亚像素级差异。
 *  2. 起点角：官方 determinate 节点无整体旋转、indeterminate 旋转 = global+additional+90°；
 *     本实现花形自 12 点方向起（与 MDC「arc starts at top」及展示站一致），故不定态少加 90°
 *     基准（纯相位差，视觉等价）。
 *  3. prefers-reduced-motion：不定态定格 playtime=0、确定态振幅瞬时到位、相位冻结。
 *
 * 【与 MDC-Android 1.14.0 的差异（诚实声明）】MDC 版波形仅向内压 1.6dp（createWavyPath
 *  moveAcross(amplitude·2)）、相位默认静止；官方展示规格为 圆↔星形 Morph（谷径 0.75R）+
 *  相位持续滚动 + 振幅随进度收敛。本版按用户指令对齐官方展示规格。
 *
 * 【进度/模式控件】progress 滑块与模式开关均为带手柄/带滑轨样式的 Aosp 组件，
 *  绝不使用原生 <input type="range"> 默认圆点（用户硬性指令，2026-11-21）。
 */
import React, { useEffect, useRef, useState } from 'react';
import { hexToRgbaWave, type M3ThemeTokens } from '@/aosp/dynamicColor';
import type { LabConfigState } from './InteractiveLab';
import { AospExpressiveSlider } from './AospExpressiveSlider';
import { AospExpressiveSwitch } from './AospExpressiveSwitch';

/* ---------- 官方令牌（CircularProgressIndicatorTokens.kt / ProgressIndicator.kt） ---------- */
const SIZE = 48; // WaveSize 48dp（wavy 容器）
const STROKE = 4; // ActiveThickness = TrackThickness 4dp
const RADIUS = (SIZE - STROKE) / 2; // 官方 r = size/2 − strokeWidth/2 = 22
const GAP = 4; // TrackActiveSpace 4dp
const LAMBDA = 15; // ActiveWaveWavelength 15dp
const CAP_W = STROKE / 2; // currentStrokeCapWidth
const PETALS = Math.max(5, Math.round((2 * Math.PI * RADIUS) / LAMBDA)); // = 9（CircularShapes L1342）
const INNER_RATIO = 0.75; // RoundedPolygon.star innerRadius（L1351）
const CIRC = 2 * Math.PI * RADIUS; // 轨道周长（轨道恒为圆）
const WAVE_CYCLE_MS = (LAMBDA / LAMBDA) * 1000 * PETALS; // offset 时长 = 9000ms（每秒 1 波长）
const AMPLITUDE_MS = 500; // MotionTokens.DurationLong2

/* ---------- 缓动（MotionTokens.kt 原值） ---------- */
function makeCubicBezierSolver(x1: number, y1: number, x2: number, y2: number) {
  const cx = 3 * x1;
  const bx = 3 * (x2 - x1) - cx;
  const ax = 1 - cx - bx;
  const cy = 3 * y1;
  const by = 3 * (y2 - y1) - cy;
  const ay = 1 - cy - by;
  const sampleX = (t: number) => ((ax * t + bx) * t + cx) * t;
  const sampleY = (t: number) => ((ay * t + by) * t + cy) * t;
  const sampleDX = (t: number) => (3 * ax * t + 2 * bx) * t + cx;
  return (x: number): number => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const err = sampleX(t) - x;
      if (Math.abs(err) < 1e-6) return sampleY(t);
      const d = sampleDX(t);
      if (Math.abs(d) < 1e-6) break;
      t -= err / d;
    }
    let lo = 0;
    let hi = 1;
    t = x;
    for (let i = 0; i < 24; i++) {
      const v = sampleX(t);
      if (Math.abs(v - x) < 1e-6) break;
      if (v < x) lo = t;
      else hi = t;
      t = (lo + hi) / 2;
    }
    return sampleY(t);
  };
}

const EASE_STANDARD = makeCubicBezierSolver(0.2, 0, 0, 1); // EasingStandardCubicBezier
const EASE_EMPH_ACCEL = makeCubicBezierSolver(0.3, 0, 0.8, 0.15); // EasingEmphasizedAccelerateCubicBezier
const EASE_EMPH_DECEL = makeCubicBezierSolver(0.05, 0.7, 0.1, 1); // EasingEmphasizedDecelerateCubicBezier

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

/** 官方 indicatorAmplitude（WavyProgressIndicator.kt L490-497）：≤10% / ≥95% → 0 */
function amplitudeTarget(p: number): number {
  return p <= 0.1 || p >= 0.95 ? 0 : 1;
}

/* ---------- 花形查找表（圆 ↔ RoundedPolygon.star(9, 0.75) Morph 的极径近似） ---------- */
interface FlowerLut {
  xs: number[];
  ys: number[];
  cum: number[];
  total: number;
  amp: number;
}

const FLOWER_SAMPLES = 720; // 0.5°/点，闭合环（末点=首点）

function buildFlowerLut(amp: number): FlowerLut {
  const dip = RADIUS * (1 - INNER_RATIO); // 5.5
  const xs: number[] = [];
  const ys: number[] = [];
  const cum: number[] = [0];
  for (let i = 0; i <= FLOWER_SAMPLES; i++) {
    const theta = (i / FLOWER_SAMPLES) * Math.PI * 2;
    // Morph 语义：amp=0 → 正规圆（r=RADIUS）；amp=1 → 全花形（外 22 / 谷 16.5）
    const wave = amp * dip * ((1 - Math.cos(PETALS * theta)) / 2);
    const r = RADIUS - wave;
    // θ=0 从 12 点方向起、顺时针（与 MDC「arc starts at top」及展示站一致）
    const fx = r * Math.sin(theta);
    const fy = -r * Math.cos(theta);
    if (i > 0) {
      const dx = fx - xs[xs.length - 1];
      const dy = fy - ys[ys.length - 1];
      cum.push(cum[cum.length - 1] + Math.hypot(dx, dy));
    }
    xs.push(fx);
    ys.push(fy);
  }
  return { xs, ys, cum, total: cum[cum.length - 1], amp };
}

/** 弧长 → 点（二分 + 线性插值；dist 取模支持闭合回绕） */
function flowerPointAt(lut: FlowerLut, dist: number): [number, number] {
  const total = lut.total;
  const d = ((dist % total) + total) % total;
  let lo = 0;
  let hi = lut.cum.length - 1;
  while (lo < hi - 1) {
    const mid = (lo + hi) >> 1;
    if (lut.cum[mid] <= d) lo = mid;
    else hi = mid;
  }
  const span = lut.cum[hi] - lut.cum[lo];
  const k = span > 0 ? (d - lut.cum[lo]) / span : 0;
  return [lut.xs[lo] + (lut.xs[hi] - lut.xs[lo]) * k, lut.ys[lo] + (lut.ys[hi] - lut.ys[lo]) * k];
}

/** 弧段折线（updateDrawPaths L1214-1247：getSegment(start+shift, stop+shift)，坐标为花形局部系） */
function flowerSegmentD(lut: FlowerLut, startArc: number, stopArc: number): string | null {
  if (stopArc - startArc <= 0) return null;
  const count = Math.max(2, Math.min(512, Math.ceil(stopArc - startArc)));
  const cmds: string[] = [];
  for (let i = 0; i <= count; i++) {
    const [x, y] = flowerPointAt(lut, startArc + ((stopArc - startArc) * i) / count);
    cmds.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`);
  }
  return cmds.join(' ');
}

/* ===================== 圆形波形指示器 ===================== */

interface WavyCircularProps {
  theme: M3ThemeTokens;
  /** 确定态进度；indeterminate=true 时忽略 */
  progress: number;
  indeterminate: boolean;
  /** 渲染尺寸倍率（viewBox 恒为 48dp 令牌值；3× 放大视图用，不影响几何） */
  scale?: number;
}

/**
 * 圆形波形指示器。确定态由 rAF 命令式驱动（振幅 tween + 相位滚动 + 花形取段）；
 * 不定态 retreat 同样逐帧写 DOM。轨道恒为圆；活动弧 = 花形 Morph 段。
 */
function WavyCircular({ theme, progress, indeterminate, scale = 1 }: WavyCircularProps) {
  const p = clamp(progress, 0, 1);
  const pRef = useRef(p);
  pRef.current = p;
  const ampRef = useRef(0);
  const tweenRef = useRef<{ from: number; to: number; start: number; easing: (t: number) => number } | null>(null);
  const offsetRef = useRef(0);
  const lastTsRef = useRef(0);
  const reducedMotionRef = useRef(false);

  // 花形 LUT 缓存（振幅变化时重建；amp 变化仅在 500ms tween 期间逐帧发生）
  const lutRef = useRef<FlowerLut>(buildFlowerLut(0));
  const firstRunRef = useRef(true);

  const progressGRef = useRef<SVGGElement>(null); // −offset·360° 旋转补偿
  const progressPathRef = useRef<SVGPathElement>(null);
  const spinGRef = useRef<SVGGElement>(null); // indeterminate：global+additional 旋转
  const trackRef = useRef<SVGCircleElement>(null);

  // 振幅目标（官方 indicatorAmplitude lambda；不定态恒 1）。
  // 首帧直接落在目标值（官方 Animatable(initialValue = targetAmplitude) 无入场动画），
  // 之后的变更才以 500ms tween 过渡。
  const target = indeterminate ? 1 : amplitudeTarget(p);
  useEffect(() => {
    if (indeterminate) {
      ampRef.current = 1;
      lutRef.current = buildFlowerLut(1);
      tweenRef.current = null;
      return;
    }
    if (firstRunRef.current) {
      firstRunRef.current = false;
      ampRef.current = target;
      lutRef.current = buildFlowerLut(target);
      tweenRef.current = null;
      return;
    }
    tweenRef.current = {
      from: ampRef.current,
      to: target,
      start: performance.now(),
      easing: target > ampRef.current ? EASE_STANDARD : EASE_EMPH_ACCEL,
    };
  }, [target, indeterminate]);

  /* ---- 确定态：逐帧（振幅 tween / 相位 / 花形取段 / 轨道 dasharray） ---- */
  useEffect(() => {
    if (indeterminate) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reducedMotionRef.current = mq.matches;
    const onChange = (e: MediaQueryListEvent) => {
      reducedMotionRef.current = e.matches;
    };
    mq.addEventListener('change', onChange);
    let raf = 0;

    const render = (dtMs: number) => {
      const pNow = clamp(pRef.current, 0, 1);
      const tween = tweenRef.current;
      if (tween) {
        const k = reducedMotionRef.current
          ? 1
          : clamp((performance.now() - tween.start) / AMPLITUDE_MS, 0, 1);
        ampRef.current = tween.from + (tween.to - tween.from) * tween.easing(k);
        if (k >= 1) tweenRef.current = null;
      }
      const amp = ampRef.current;
      // 花形 LUT（振幅变化时重建）
      const lut = lutRef.current;
      if (Math.abs(lut.amp - amp) > 0.0005) {
        const next = buildFlowerLut(amp);
        lutRef.current = next;
      }
      const cur = lutRef.current;
      // 相位：每 9000ms 滚动一整圈（= 每秒 1 波长，startOffsetAnimation L341-380）
      if (!reducedMotionRef.current) {
        offsetRef.current = (offsetRef.current + dtMs / WAVE_CYCLE_MS) % 1;
      }
      const offset = offsetRef.current;
      const shift = offset * cur.total; // startStopShift（L1216）
      const pStopArc = pNow * cur.total;

      // 活动弧：[shift → pStop + shift] + 旋转补偿 −offset·360°（L1218-1239）
      const d = flowerSegmentD(cur, shift, pStopArc + shift);
      const path = progressPathRef.current;
      if (path) {
        if (d === null) {
          path.setAttribute('display', 'none');
        } else {
          path.removeAttribute('display');
          path.setAttribute('d', d);
          path.setAttribute('stroke', theme.primary);
        }
      }
      const g = progressGRef.current;
      if (g) {
        const offsetAngle = (offset * 360) % 360;
        g.setAttribute('transform', offsetAngle !== 0 ? `rotate(${(-offsetAngle).toFixed(3)})` : '');
      }

      // 轨道：圆，两端 trackSpacing（L1207-1209 / L1248-1256）
      const spacing = 2 * Math.min(pStopArc, CAP_W) + Math.min(pStopArc, GAP);
      const tStart = pNow * CIRC + spacing;
      const tStop = CIRC - spacing;
      const track = trackRef.current;
      if (track) {
        const span = tStop - tStart;
        if (span > 0) {
          track.removeAttribute('display');
          track.setAttribute('stroke', theme.secondaryContainer);
          track.setAttribute('stroke-dasharray', `${span.toFixed(2)} ${(CIRC - span).toFixed(2)}`);
          track.setAttribute('stroke-dashoffset', (-tStart).toFixed(2));
        } else {
          track.setAttribute('display', 'none');
        }
      }
    };

    const loop = (now: number) => {
      const dt = lastTsRef.current ? Math.min(100, now - lastTsRef.current) : 16;
      lastTsRef.current = now;
      render(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const onVisibility = () => {
      lastTsRef.current = 0;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(loop);
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVisibility);
      mq.removeEventListener('change', onChange);
    };
  }, [indeterminate, theme.primary, theme.secondaryContainer]);

  /* ---- 不定态 retreat：6000ms（global 1080° 线性 + 4×90° 突转 + sweep 0.1↔0.87） ---- */
  useEffect(() => {
    if (!indeterminate) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reducedMotionRef.current = mq.matches;
    const onChange = (e: MediaQueryListEvent) => {
      reducedMotionRef.current = e.matches;
    };
    mq.addEventListener('change', onChange);
    let raf = 0;

    const RETREAT_MS = 6000; // CircularAnimationProgressDuration
    const SWEEP_MIN = 0.1;
    const SWEEP_MAX = 0.87;
    const SPIN_DELAYS = [0, 1500, 3000, 4500]; // CircularAnimationAdditionalRotationDelay ×k
    const SPIN_MS = 300; // CircularAnimationAdditionalRotationDuration

    ampRef.current = 1; // 不定态振幅恒 1（官方默认参数）
    lutRef.current = buildFlowerLut(1);

    const render = (playtime: number, dtMs: number) => {
      const cur = lutRef.current;
      if (!reducedMotionRef.current) {
        offsetRef.current = (offsetRef.current + dtMs / WAVE_CYCLE_MS) % 1;
      }
      const offset = offsetRef.current;
      const shift = offset * cur.total;

      // sweep：两程均 EasingStandard（circularIndeterminateProgressAnimationSpec keyframes）
      const t = playtime;
      const sweep =
        t < RETREAT_MS / 2
          ? SWEEP_MIN + (SWEEP_MAX - SWEEP_MIN) * EASE_STANDARD(t / (RETREAT_MS / 2))
          : SWEEP_MAX - (SWEEP_MAX - SWEEP_MIN) * EASE_STANDARD((t - RETREAT_MS / 2) / (RETREAT_MS / 2));

      // 恒定旋转 1080°（LinearEasing）+ 附加 4×90° 突转（EmphasizedDecelerate）
      const globalRot = (1080 * t) / RETREAT_MS;
      let addRot = 0;
      for (const delay of SPIN_DELAYS) {
        addRot += 90 * EASE_EMPH_DECEL(clamp((t - delay) / SPIN_MS, 0, 1));
      }
      const deg = (globalRot + addRot) % 360;
      spinGRef.current?.setAttribute('transform', `rotate(${deg.toFixed(3)})`);

      // 活动弧：start=0、end=sweep（IndeterminateCircularWavyProgressNode L837-850）
      const pStopArc = sweep * cur.total;
      const d = flowerSegmentD(cur, shift, pStopArc + shift);
      const path = progressPathRef.current;
      if (path) {
        if (d === null) {
          path.setAttribute('display', 'none');
        } else {
          path.removeAttribute('display');
          path.setAttribute('d', d);
          path.setAttribute('stroke', theme.primary);
        }
      }
      const g = progressGRef.current;
      if (g) {
        const offsetAngle = (offset * 360) % 360;
        g.setAttribute('transform', offsetAngle !== 0 ? `rotate(${(-offsetAngle).toFixed(3)})` : '');
      }

      // 轨道（两端 trackSpacing）
      const spacing = 2 * Math.min(pStopArc, CAP_W) + Math.min(pStopArc, GAP);
      const tStart = sweep * CIRC + spacing;
      const tStop = CIRC - spacing;
      const track = trackRef.current;
      if (track) {
        const span = tStop - tStart;
        if (span > 0) {
          track.removeAttribute('display');
          track.setAttribute('stroke', theme.secondaryContainer);
          track.setAttribute('stroke-dasharray', `${span.toFixed(2)} ${(CIRC - span).toFixed(2)}`);
          track.setAttribute('stroke-dashoffset', (-tStart).toFixed(2));
        } else {
          track.setAttribute('display', 'none');
        }
      }
    };

    const loop = (now: number) => {
      const dt = lastTsRef.current ? Math.min(100, now - lastTsRef.current) : 16;
      lastTsRef.current = now;
      render(reducedMotionRef.current ? 0 : now % RETREAT_MS, dt);
      if (!reducedMotionRef.current) raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const onVisibility = () => {
      lastTsRef.current = 0;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(loop);
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVisibility);
      mq.removeEventListener('change', onChange);
    };
  }, [indeterminate, theme.primary, theme.secondaryContainer]);

  return (
    <svg
      width={SIZE * scale}
      height={SIZE * scale}
      viewBox={`0 0 ${SIZE} ${SIZE}`}
      role={scale === 1 ? 'progressbar' : undefined}
      aria-label={
        scale === 1
          ? indeterminate
            ? '圆形波形进度指示器（不定态 retreat）'
            : '圆形波形进度指示器（确定态）'
          : undefined
      }
    >
      <g transform="translate(24 24)">
        {indeterminate ? (
          <g ref={spinGRef}>
            <circle
              ref={trackRef}
              r={RADIUS}
              transform="rotate(-90)"
              fill="none"
              strokeWidth={STROKE}
              strokeLinecap="round"
              strokeDasharray="0 9999"
            />
            <g ref={progressGRef}>
              <path ref={progressPathRef} fill="none" strokeWidth={STROKE} strokeLinecap="round" />
            </g>
          </g>
        ) : (
          <>
            <circle
              ref={trackRef}
              r={RADIUS}
              transform="rotate(-90)"
              fill="none"
              strokeWidth={STROKE}
              strokeLinecap="round"
              strokeDasharray="0 9999"
            />
            <g ref={progressGRef}>
              <path ref={progressPathRef} fill="none" strokeWidth={STROKE} strokeLinecap="round" />
            </g>
          </>
        )}
      </g>
    </svg>
  );
}

/* ===================== 演示容器 ===================== */

interface WavyCircularDemoProps {
  theme: M3ThemeTokens;
  config: LabConfigState;
}

export function WavyCircularDemo({ theme, config }: WavyCircularDemoProps) {
  const [indeterminate, setIndeterminate] = useState(false);
  const [progress, setProgress] = useState(0.55);
  const waveColor = hexToRgbaWave(theme.primary, 1);
  const ampTarget = amplitudeTarget(clamp(progress, 0, 1));

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Wavy CircularProgressIndicator（圆形波形进度条）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          m3.material.io 展示规格 · Compose M3 Expressive {'{'}
          WavyProgressIndicator.kt · CircularWavyProgressModifiers.kt{'}'} · MDC-Android 1.14.0
          tokens 对照
        </span>
      </div>

      <div className="space-y-4 rounded-lg p-5" style={{ backgroundColor: theme.surfaceContainerLow }}>
        <div className="flex flex-wrap items-center gap-8">
          <div className="flex flex-col items-center gap-2">
            <WavyCircular theme={theme} progress={progress} indeterminate={indeterminate} />
            <span className="text-[10px] text-slate-400 dark:text-slate-500">1×（48dp 真实尺寸）</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <WavyCircular theme={theme} progress={progress} indeterminate={indeterminate} scale={3} />
            <span className="text-[10px] text-slate-400 dark:text-slate-500">3× 放大视图（几何仍为 48dp 令牌值）</span>
          </div>
        </div>
        {!indeterminate && (
          <AospExpressiveSlider
            label="调节确定态进度 (progress)"
            value={progress}
            min={0}
            max={1}
            step={0.01}
            size="xs"
            compact
            unit=""
            formatValue={(v) => `progress = ${v.toFixed(2)}`}
            accentHex={theme.primary}
            theme={theme}
            onChange={setProgress}
          />
        )}
        <div className="flex items-center justify-between gap-4 pt-1">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {indeterminate
              ? 'indeterminate：retreat（6000ms · 1080° 线性 + 4×90° EmphasizedDecelerate 突转 · sweep 0.1↔0.87）'
              : `determinate：振幅 ${ampTarget === 1 ? '满幅（圆↔9 齿星形 Morph）' : '收敛为 0（正规圆，≤0.10 / ≥0.95）'} · 相位每 9s 一圈（1 波长/秒）`}
          </div>
          <AospExpressiveSwitch
            checked={indeterminate}
            onChange={setIndeterminate}
            ariaLabel="切换圆形波形确定态 / 不定态"
            mode={config.mode}
            waveColor={waveColor}
            sparkleColor={{ r: 1, g: 1, b: 1, a: config.sparkleAlpha }}
            sparkleStrength={config.sparkleStrength}
            distortionStrength={config.distortionStrength}
            systemUiShape={config.systemUiShape}
            speedMultiplier={config.speedMultiplier}
            densityScale={config.densityScale}
            accentHex={theme.primary}
          />
        </div>
      </div>

      <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          按官方展示规格实现：活动弧 = 圆 ↔ RoundedPolygon.star 的 Morph（官方 9 齿、innerRadius
          0.75 → 外径 22 / 谷径 16.5、重圆角 0.35/0.5；本实现以极径余弦近似，边界与齿数一致）；
          progress ≤ 0.10 或 ≥ 0.95 时振幅收敛为 0（500ms tween）——静止与空载时为正规圆；
          波形相位每 9000ms 滚动一整圈（waveSpeed=λ → 每秒 1 波长），取段后按 −offset·360°
          旋转补偿使端点固定、波形滑动；轨道恒为圆，两端留 trackSpacing =
          2·min(pStop,capWidth)+min(pStop,gap)。不定态 retreat：6000ms 周期、1080° 线性恒旋 +
          4×90°（300ms EasingEmphasizedDecelerate）突转、弧长 sweep 0.1↔0.87（两程
          EasingStandard）。
        </p>
        <p>
          <span className="font-medium text-slate-600 dark:text-slate-300">诚实缺口：</span>
          graphics-shapes 的角部圆角/smoothing 算法不在本地源码树，花形中间态与官方 Morph
          存在亚像素级差异；起点角按 MDC/展示站「arc starts at top」约定；MDC-Android 1.14.0
          的差异实现（1.6dp 单向内凹波、静止相位、恒满幅）已按用户指令让位于官方展示规格；
          prefers-reduced-motion 定格并瞬时收敛。
        </p>
      </div>
    </div>
  );
}
