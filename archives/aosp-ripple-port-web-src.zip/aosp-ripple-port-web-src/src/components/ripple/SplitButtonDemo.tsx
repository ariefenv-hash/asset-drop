"use client";
/**
 * Material 3 Expressive SplitButton —— Web 忠实转译（MDC-Android 1.14.0）
 *
 * 全部取值均可回溯到本地真实源码（sources/mdc-android/lib/java/com/google/android/material/button/）：
 *  - 容器：spacing 2dp / paddingTop·Bottom 10dp / innerCornerSize 状态列表 / shapeAppearance Corner.Full
 *      （res/values/styles.xml  Widget.Material3.MaterialSplitButton）
 *  - 内角三态：默认 4dp；checkable+pressed 12dp；checked 50%（相对角尺寸，此处取高度之半 = 24px）
 *      （res/xml/m3_split_button_inner_corner_size_state_list.xml）
 *  - 令牌：small leading leading/trailing space 16dp/12dp；icon 20dp；minWidth mtrl_min_touch_target_size=48dp
 *      （res/values/split_button_tokens.xml、resources/res/values/dimens.xml）
 *  - 按钮：paddingTop/Bottom 6dp（LeadingButton.Filled）；IconButton padding 14dp·6dp；
 *      minHeight m3expressive_btn_min_height=48dp
 *      （res/values/styles.xml、res/values/dimens.xml）
 *  - 颜色：Filled = colorPrimary / onPrimary（m3_comp_button_filled_* 宏）；
 *      Tonal = colorSecondaryContainer / onSecondaryContainer（M3 标准 tonal 按钮）；
 *      图标按钮覆盖层 m3_comp_icon_button_filled_* → 同为 colorPrimary / colorOnPrimary
 *      （button/res/values/icon_btn_tokens.xml 105-106）
 *  - 展开 chevron：rotation 0→180°，200ms，OvershootInterpolator tension=1.0
 *      （res/animator/m3_split_button_chevron_rotation.xml + m3_split_button_chevron_overshoot_interpolator.xml）
 *      Overshoot 公式取自 AOSP framework android.view.animation.OvershootInterpolator（逐式实现）。
 *
 * 【诚实缺口】Android 侧内角切换由状态列表即时生效（无显式动画），此处同样即时切换，不加过渡。
 * 涟漪系统（RippleDrawable）未接入本组件 —— Android 上该组件的按压反馈由 MaterialButtonGroup
 * 与 RippleDrawable 协作产生，Web 转译暂以状态层呈现（M3 state layer 规范），详见页面标注。
 */
import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import type { M3ThemeTokens } from '@/aosp/dynamicColor';

/** AOSP android.view.animation.OvershootInterpolator.getInterpolation 精确公式 */
function overshoot(t: number, tension = 1.0): number {
  t -= 1.0;
  return t * t * ((tension + 1) * t + tension) + 1.0;
}

/** 200ms 0→180° 过冲旋转（m3_split_button_chevron_rotation.xml 逐值转译） */
function useChevronRotation(checked: boolean): number {
  const [rotation, setRotation] = useState(0);
  const rafRef = useRef<number | null>(null);
  useEffect(() => {
    const from = rotation;
    const to = checked ? 180 : 0;
    const start = performance.now();
    const DURATION = 200; // android:duration="200"
    if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / DURATION);
      setRotation(from + (to - from) * overshoot(t, 1.0));
      if (t < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [checked]);
  return rotation;
}

interface SplitButtonProps {
  theme: M3ThemeTokens;
  variant: 'filled' | 'tonal';
  label: string;
  icon: React.ReactNode;
}

/** 单个分体按钮实例（Filled / Tonal 两种官方样式） */
function SplitButton({ theme, variant, label, icon }: SplitButtonProps) {
  const [checked, setChecked] = useState(false);
  const [pressedSide, setPressedSide] = useState<'leading' | 'trailing' | null>(null);
  const rotation = useChevronRotation(checked);

  const containerColor =
    variant === 'filled' ? theme.primary : theme.secondaryContainer;
  const contentColor =
    variant === 'filled' ? theme.onPrimary : theme.onSecondaryContainer;

  // m3_split_button_inner_corner_size_state_list.xml 三态
  // checked 50% = 相对角尺寸（高度之半）
  const innerCorner =
    checked ? 24 : pressedSide !== null ? 12 : 4;

  const leadingRadius = `999px ${innerCorner}px ${innerCorner}px 999px`;
  const trailingRadius = `${innerCorner}px 999px 999px ${innerCorner}px`;

  return (
    <div
      className="inline-flex items-center"
      style={{ gap: '2px' }} // android:spacing 2dp
    >
      {/* LeadingButton —— padding 6dp/16dp/6dp/12dp（small 令牌）、icon 20dp、min 48dp */}
      <button
        type="button"
        aria-pressed={checked}
        onPointerDown={() => setPressedSide('leading')}
        onPointerUp={() => setPressedSide(null)}
        onPointerLeave={() => setPressedSide(null)}
        style={{
          backgroundColor: containerColor,
          color: contentColor,
          borderRadius: leadingRadius,
          minHeight: '48px', // m3expressive_btn_min_height 48dp
          minWidth: '48px', // mtrl_min_touch_target_size 48dp
          paddingTop: '6px',
          paddingBottom: '6px',
          paddingLeft: '16px', // m3_comp_split_button_small_leading_button_leading_space
          paddingRight: '12px', // ..._trailing_space
          display: 'inline-flex',
          alignItems: 'center',
          gap: '8px',
          fontSize: '14px',
          lineHeight: '20px',
          fontWeight: 500,
          transition: 'none',
        }}
      >
        <span style={{ width: '20px', height: '20px', display: 'inline-flex' }}>
          {icon}
        </span>
        <span>{label}</span>
      </button>

      {/* IconButton.Filled —— padding 6dp/14dp、min 48dp、chevron 180° 过冲 */}
      <button
        type="button"
        aria-label={checked ? '收起' : '展开'}
        aria-expanded={checked}
        onClick={() => setChecked((c) => !c)}
        onPointerDown={() => setPressedSide('trailing')}
        onPointerUp={() => setPressedSide(null)}
        onPointerLeave={() => setPressedSide(null)}
        style={{
          backgroundColor: containerColor,
          color: contentColor,
          borderRadius: trailingRadius,
          minHeight: '48px',
          width: '48px',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'none',
        }}
      >
        <span
          style={{
            width: '24px',
            height: '24px',
            display: 'inline-flex',
            transform: `rotate(${rotation}deg)`,
          }}
        >
          <ChevronDown size={24} strokeWidth={2} aria-hidden="true" />
        </span>
      </button>
    </div>
  );
}

interface SplitButtonDemoProps {
  theme: M3ThemeTokens;
}

export function SplitButtonDemo({ theme }: SplitButtonDemoProps) {
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          SplitButton 分体按钮（M3 Expressive）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          MDC-Android 1.14.0 · button/res/{'styles.xml · split_button_tokens.xml · xml/…inner_corner…'}
        </span>
      </div>

      {/* Android 容器：paddingTop/Bottom 10dp（MaterialSplitButton 样式） */}
      <div
        className="flex flex-wrap items-center justify-center gap-8 rounded-lg py-[10px]"
        style={{ backgroundColor: theme.surfaceContainerLow }}
      >
        <SplitButton
          theme={theme}
          variant="filled"
          label="Filled"
          icon={
            <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
              <path d="M12 3a9 9 0 1 0 9 9 9 9 0 0 0-9-9Zm1 13h-2v-2h2Zm0-4h-2V7h2Z" />
            </svg>
          }
        />
        <SplitButton
          theme={theme}
          variant="tonal"
          label="Tonal"
          icon={
            <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
              <path d="M12 3a9 9 0 1 0 9 9 9 9 0 0 0-9-9Zm1 13h-2v-2h2Zm0-4h-2V7h2Z" />
            </svg>
          }
        />
      </div>

      <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          点击右侧箭头切换 checked 态：chevron 0→180°（200ms，Overshoot tension=1.0），内角 4dp→50%；
          按压任一侧内角 4dp→12dp。全部取值见文件头注释所引源码路径。
        </p>
        <p>
          <span className="font-medium text-slate-600 dark:text-slate-300">诚实缺口：</span>
          内角切换在 Android 上为状态列表即时生效，本转译同样不加过渡；按压反馈为 M3 状态层近似，
          未接入 WebGL 涟漪引擎（Android 侧由 RippleDrawable 提供）。
        </p>
      </div>
    </div>
  );
}
