"use client";
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, X } from 'lucide-react';
import {
  AOSP_MAX_RIPPLES,
  AospRippleEngineMode,
  getSharedRippleRenderer,
  RippleColorRGBA,
  RippleSession,
  SystemUiRippleShape,
} from '../../aosp/RippleEngine';

export interface AospExpressiveSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  ariaLabel: string;
  showIcons?: boolean;
  disabled?: boolean;
  mode: AospRippleEngineMode;
  waveColor: RippleColorRGBA;
  sparkleColor: RippleColorRGBA;
  sparkleStrength: number;
  distortionStrength: number;
  systemUiShape: SystemUiRippleShape;
  speedMultiplier: number;
  densityScale: number;
  accentHex: string;
  onPrimaryHex?: string;
  inactiveTrackHex?: string;
  outlineHex?: string;
  thumbUncheckedHex?: string;
  thumbUncheckedIconHex?: string;
}

/**
 * ===== 第 22 轮重写（用户复核意见：涟漪滥用 + 源码核对）=====
 *
 * 官方 @material/web 2.5.0 md-switch 按压行为（本地 pkg/ 原文逐行核对）：
 *  · switch/internal/switch.js L116 — md-ripple 实例挂在 .handle-container 内，
 *    随小球一起移动；
 *  · switch/internal/_handle.scss L134-140（编译版 switch-styles.css 同）— 该
 *    md-ripple 被钉死为 40×40（--md-switch-state-layer-size，默认 40px）、
 *    border-radius: full 的圆形状态层，inset: unset 脱离全铺满默认值；
 *  · pressed-state-layer-opacity = 0.12（hover 0.08）；按压涟漪从触点生长，
 *    被宿主 overflow:hidden + border-radius:inherit 裁进 40×40 圆内，
 *    —— 不会扩散过整条轨道（用户观察的"小方块区域涟漪"实证）；
 *  · 小球按压 :active → 24→28px（pressed-handle-*，100ms linear），
 *    松开 250ms cubic-bezier(0.2,0,0,1) 回弹（_handle.scss L85-91）；
 *  · 小球位移过渡 = 300ms cubic-bezier(0.175,0.885,0.32,1.275)（官方自定义
 *    过冲缓动，_handle.scss L25）。
 *
 * 据此修正：
 *  1. 撤掉旧实现的"按整条开关生成无界 WebGL 涟漪光晕"（涟漪滥用）——官方与
 *     AOSP 的开关语义均无此行为；改为与官方同几何的约束状态层：40×40 圆形
 *     mask + 星斑着色器（framework / systemui 两种模式均支持 u_maskRadii）。
 *  2. 按压手感照官方：24→28px（100ms linear / 回弹 250ms standard），
 *     并叠加 1.05 的轻微放大（transform scale，过冲缓动）——用户要求。
 *  3. 新增 Web 增强交互（官方 md-switch 无拖拽，特此注明）：按住小球可左右
 *     拖拽（rAF 命令式写 DOM + setPointerCapture，与滑块第 20 条同款方案），
 *     松手自动吸附判定——越出行程中点（或甩动速度 > 0.35px/ms）即切换，
 *     否则以官方过冲缓动回弹原位。
 *
 * ===== 第 24 轮加固（全面自审）=====
 *  4. 修复派生 click 吞掉标志残留：pointercancel / lostpointercapture 结束拖拽
 *     时无 click 跟随，旧布尔标志会吞掉下一次正常点击（开关"点不动一次"）；
 *     改为 CLICK_SUPPRESS_WINDOW_MS=600 时间窗 + pointerdown 重置。
 *  5. 键盘：key repeat 不再重复生成涟漪 session（状态切换仍走原生 click）；
 *     涟漪生长点从轨道中心改为小球实际中心（状态层盒中心）；
 *     释放定时器收进卸载清理。
 *  6. prefers-reduced-motion：撤位移/过冲动画与按压微放大，仅保留 67ms 颜色
 *     过渡（M3 无障碍基线）。
 *  7. WebGL2 不可用时以官方 0.12 pressed-state-layer 的 CSS 状态层兜底，
 *     不再出现"按下零反馈"死区；几何与 WebGL 路径一致。
 *  8. 移动端长按体验：屏蔽 contextmenu / 文本选择 / iOS 长按呼出气泡。
 */
const TRACK_W = 52;
const TRACK_H = 32;
const STATE_LAYER_SIZE = 40; // 官方 --md-switch-state-layer-size 默认 40px
const STATE_LAYER_RADIUS = STATE_LAYER_SIZE / 2;
const TRAVEL_MIN = TRACK_H / 2; // 16 — 小球中心左极点
const TRAVEL_MAX = TRACK_W - TRACK_H / 2; // 36 — 小球中心右极点
const TRAVEL_MID = (TRAVEL_MIN + TRAVEL_MAX) / 2; // 26 — 自动吸附判定线
const DRAG_DEAD_ZONE = 4; // px，低于此视为点击而非拖拽
const FLING_SPEED = 0.35; // px/ms，甩动判定阈值

/** 官方缓动（_handle.scss 原值） */
const EASE_OVERSHOOT = 'cubic-bezier(0.175, 0.885, 0.32, 1.275)'; // 位移/回弹（官方自定义过冲）
const EASE_STANDARD = 'cubic-bezier(0.2, 0, 0, 1)'; // M3 standard
const CLICK_SUPPRESS_WINDOW_MS = 600; // 拖拽松手后浏览器可能派生 click，仅在此时间窗内吞掉

type PressEase = {
  thumb: string;
  canvas: string;
};

/**
 * 第 24 轮：prefers-reduced-motion 支持。
 * 减少动态效果时撤掉位移动画与过冲缓动（官方 M3 无障碍基线：非必要位移动画
 * 应弱化），仅保留 67ms 颜色过渡；按压微放大同步关闭（scale=1）。
 */
function easedTransitions(pressed: boolean, reducedMotion: boolean): PressEase {
  if (reducedMotion) {
    return {
      thumb: 'background-color 67ms linear',
      canvas: 'none',
    };
  }
  // 按压期尺寸走官方 100ms linear，松开回弹 250ms standard（_handle.scss L85-91）
  const size = pressed ? 'width 100ms linear, height 100ms linear' : `width 250ms ${EASE_STANDARD}, height 250ms ${EASE_STANDARD}`;
  return {
    thumb: `left 300ms ${EASE_OVERSHOOT}, ${size}, transform 250ms ${EASE_OVERSHOOT}, background-color 67ms linear`,
    canvas: `left 300ms ${EASE_OVERSHOOT}`,
  };
}

export const AospExpressiveSwitch: React.FC<AospExpressiveSwitchProps> = ({
  checked,
  onChange,
  ariaLabel,
  showIcons = true,
  disabled = false,
  mode,
  waveColor,
  sparkleColor,
  sparkleStrength,
  distortionStrength,
  systemUiShape,
  speedMultiplier,
  densityScale,
  accentHex,
  onPrimaryHex = '#ffffff',
  inactiveTrackHex,
  outlineHex,
  thumbUncheckedHex,
  thumbUncheckedIconHex,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const thumbRef = useRef<HTMLSpanElement>(null);
  const sessionsRef = useRef<RippleSession[]>([]);
  const activeSessionRef = useRef<RippleSession | null>(null);
  const rafRef = useRef<number | null>(null);
  const moveRafRef = useRef<number | null>(null);
  const nextIdRef = useRef(1);
  const keyRippleTimerRef = useRef<number | null>(null);

  const [isPressed, setIsPressed] = useState(false);
  const pressedRef = useRef(false);
  const checkedRef = useRef(checked);
  // 第 24 轮：布尔标志 → 时间戳窗口。pointercancel / lostpointercapture 结束拖拽时
  // 浏览器不会派生 click，布尔标志残留会吞掉下一次正常点击（开关“点不动一次”）；
  // 改为仅在 CLICK_SUPPRESS_WINDOW_MS 内吞派生 click，并在每次 pointerdown 重置。
  const suppressClickUntilRef = useRef(0);
  // 第 24 轮：WebGL2 不可用时的 CSS 状态层兜底（null = 未探测）
  const [webglSupported, setWebglSupported] = useState<boolean | null>(null);
  // 第 24 轮：prefers-reduced-motion（非必要位移动画弱化）
  const [reducedMotion, setReducedMotion] = useState(false);
  const reducedMotionRef = useRef(false); // 供命令式 restoreTransitions 读取，避免闭包过期
  const dragRef = useRef({
    pointerId: -1,
    startClientX: 0,
    restCenter: TRAVEL_MIN, // 按下时小球视觉中心
    curCenter: TRAVEL_MIN,
    maxAbsDx: 0,
    lastT: 0,
    lastX: 0,
    vx: 0, // px/ms
    dragging: false,
  });

  checkedRef.current = checked;

  const propsRef = useRef({
    mode,
    waveColor,
    sparkleColor,
    sparkleStrength,
    distortionStrength,
    systemUiShape,
    speedMultiplier,
    densityScale,
  });

  useEffect(() => {
    propsRef.current = {
      mode,
      waveColor,
      sparkleColor,
      sparkleStrength,
      distortionStrength,
      systemUiShape,
      speedMultiplier,
      densityScale,
    };
  });

  const startLoop = useCallback(() => {
    if (rafRef.current !== null) return;

    const tick = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        rafRef.current = null;
        return;
      }

      const now = performance.now();
      const sessions = sessionsRef.current;
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const pw = Math.round(STATE_LAYER_SIZE * dpr);
      const ph = Math.round(STATE_LAYER_SIZE * dpr);

      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
      }

      const renderer = getSharedRippleRenderer();
      renderer.renderSessions(sessions, STATE_LAYER_SIZE, STATE_LAYER_SIZE, dpr, now);

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, pw, ph);
        if (sessions.length > 0 && renderer.isSupported()) {
          ctx.drawImage(renderer.canvas, 0, 0, pw, ph, 0, 0, pw, ph);
        }
      }

      sessionsRef.current = sessions.filter((s) => !s.finished);
      if (sessionsRef.current.length > 0) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        if (ctx) ctx.clearRect(0, 0, pw, ph);
        rafRef.current = null;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  }, []);

  useEffect(() => {
    // 第 24 轮：探测 WebGL2 可用性与用户减少动态偏好（挂载后一次性 + 监听变更）
    try {
      setWebglSupported(getSharedRippleRenderer().isSupported());
    } catch {
      setWebglSupported(false);
    }
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = () => {
      setReducedMotion(mq.matches);
      reducedMotionRef.current = mq.matches;
    };
    sync();
    mq.addEventListener?.('change', sync);
    return () => {
      mq.removeEventListener?.('change', sync);
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      if (moveRafRef.current !== null) cancelAnimationFrame(moveRafRef.current);
      // 第 24 轮：键盘涟漪释放定时器随组件卸载一并回收
      if (keyRippleTimerRef.current !== null) {
        window.clearTimeout(keyRippleTimerRef.current);
        keyRippleTimerRef.current = null;
      }
    };
  }, []);

  /**
   * 官方同几何约束状态层：40×40 圆形 mask，涟漪从触点（钳制进盒内）生长，
   * maxRadius 保证盖满 40×40 后由 mask 裁形——绝不越过状态层边界。
   */
  const spawnStateLayerRipple = useCallback(
    (pressX: number, pressY: number) => {
      const p = propsRef.current;
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const inset = checkedRef.current ? 0 : 2;
      const thumbCenter = (checkedRef.current ? TRAVEL_MAX : TRAVEL_MIN) - inset;
      // 触点钳制进 40×40 状态层盒（官方 md-ripple 从触点生长的等价语义）
      const sx = Math.min(Math.max(pressX - (thumbCenter - STATE_LAYER_RADIUS), 0), STATE_LAYER_SIZE);
      const sy = Math.min(Math.max(pressY - (TRACK_H / 2 - STATE_LAYER_RADIUS), 0), STATE_LAYER_SIZE);

      if (sessionsRef.current.length >= AOSP_MAX_RIPPLES) {
        sessionsRef.current.shift();
      }

      const session = new RippleSession(
        nextIdRef.current++,
        {
          mode: p.mode,
          touchX: sx,
          touchY: sy,
          originX: sx,
          originY: sy,
          width: STATE_LAYER_SIZE,
          height: STATE_LAYER_SIZE,
          dpr,
          // framework 模式 auto = hypot(20,20)×2.3 ≈ 65 盖满全盒后由 mask 裁圆；
          // systemui 模式 override×2 = 直径 40，恰好铺满状态层。
          maxRadiusOverride: p.mode === 'framework' ? null : STATE_LAYER_RADIUS,
          color: { ...p.waveColor, a: p.waveColor.a * 0.75 },
          sparkleColor: p.sparkleColor,
          sparkleStrength: p.sparkleStrength,
          distortionStrength: p.distortionStrength,
          systemUiShape: p.systemUiShape === 'rounded_box' ? 'circle' : p.systemUiShape,
          hasMask: true,
          maskRadius: STATE_LAYER_RADIUS,
          maskRadii: [STATE_LAYER_RADIUS, STATE_LAYER_RADIUS, STATE_LAYER_RADIUS, STATE_LAYER_RADIUS],
          densityScale: p.densityScale,
          speedMultiplier: p.speedMultiplier,
        },
        performance.now()
      );

      sessionsRef.current.push(session);
      activeSessionRef.current = session;
      startLoop();
      return session;
    },
    [startLoop]
  );

  const releaseThumbRipple = useCallback(() => {
    if (activeSessionRef.current) {
      activeSessionRef.current.release(performance.now());
      activeSessionRef.current = null;
    }
  }, []);

  /** 拖拽期：命令式关闭过渡（rAF 逐帧合并写 DOM，与滑块方案一致） */
  const disableTransitions = useCallback(() => {
    if (thumbRef.current) thumbRef.current.style.transition = 'none';
    if (canvasRef.current) canvasRef.current.style.transition = 'none';
  }, []);

  const restoreTransitions = useCallback(() => {
    const t = easedTransitions(false, reducedMotionRef.current);
    if (thumbRef.current) thumbRef.current.style.transition = t.thumb;
    if (canvasRef.current) canvasRef.current.style.transition = t.canvas;
  }, []);

  const writeThumbPosition = useCallback((center: number, forChecked: boolean) => {
    const inset = forChecked ? 0 : 2;
    if (thumbRef.current) thumbRef.current.style.left = `${center - inset}px`;
    if (canvasRef.current) canvasRef.current.style.left = `${center - STATE_LAYER_RADIUS}px`;
  }, []);

  const applyDragPosition = useCallback(() => {
    moveRafRef.current = null;
    writeThumbPosition(dragRef.current.curCenter, checkedRef.current);
  }, [writeThumbPosition]);

  const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (disabled) return;
    if (pressedRef.current) return;
    e.stopPropagation();
    // 第 24 轮：新按压开始即清空上一轮的派生 click 吞掉窗口
    suppressClickUntilRef.current = 0;
    const rect = e.currentTarget.getBoundingClientRect();
    const center = checkedRef.current ? TRAVEL_MAX : TRAVEL_MIN;
    const inset = checkedRef.current ? 0 : 2;
    dragRef.current = {
      pointerId: e.pointerId,
      startClientX: e.clientX,
      restCenter: center - inset,
      curCenter: center - inset,
      maxAbsDx: 0,
      lastT: performance.now(),
      lastX: e.clientX,
      vx: 0,
      dragging: false,
    };
    pressedRef.current = true;
    setIsPressed(true);
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* setPointerCapture 不可用时退化：仍可点击，拖拽在元素外可能丢 */
    }
    spawnStateLayerRipple(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    const d = dragRef.current;
    if (!pressedRef.current || e.pointerId !== d.pointerId) return;
    const now = performance.now();
    const dt = now - d.lastT;
    if (dt > 0) {
      d.vx = (e.clientX - d.lastX) / dt;
      d.lastT = now;
      d.lastX = e.clientX;
    }
    const dx = e.clientX - d.startClientX;
    d.maxAbsDx = Math.max(d.maxAbsDx, Math.abs(dx));
    if (!d.dragging && d.maxAbsDx < DRAG_DEAD_ZONE) return;
    if (!d.dragging) {
      d.dragging = true;
      disableTransitions();
    }
    // 行程边界 + 越界阻尼（30% 橡皮筋），硬限 ±6px 过冲
    const raw = d.restCenter + dx;
    let target = raw;
    if (raw < TRAVEL_MIN) target = TRAVEL_MIN + (raw - TRAVEL_MIN) * 0.3;
    if (raw > TRAVEL_MAX) target = TRAVEL_MAX + (raw - TRAVEL_MAX) * 0.3;
    d.curCenter = Math.min(Math.max(target, TRAVEL_MIN - 6), TRAVEL_MAX + 6);
    if (moveRafRef.current === null) {
      moveRafRef.current = requestAnimationFrame(applyDragPosition);
    }
  };

  const handlePointerUp = (e?: React.PointerEvent<HTMLButtonElement>) => {
    const d = dragRef.current;
    if (!pressedRef.current) return;
    if (e && 'pointerId' in e && e.pointerId !== d.pointerId) return;
    pressedRef.current = false;

    releaseThumbRipple();
    restoreTransitions();

    if (d.dragging) {
      // ===== 自动吸附判定 =====
      // 甩动（|v| > 0.35px/ms 且已有位移）按甩动方向定夺；
      // 否则按"投影 80ms 动量后的位置是否越过行程中点"判定。
      let newChecked = checkedRef.current;
      if (Math.abs(d.vx) > FLING_SPEED && Math.abs(d.curCenter - d.restCenter) > 3) {
        newChecked = d.vx > 0;
      } else {
        const projected = d.curCenter + (Math.abs(d.vx) > FLING_SPEED ? d.vx * 80 : 0);
        newChecked = projected > TRAVEL_MID;
      }
      const finalCenter = newChecked ? TRAVEL_MAX : TRAVEL_MIN;
      writeThumbPosition(finalCenter, newChecked); // React 对 style 无 diff 时保证落位
      suppressClickUntilRef.current = performance.now() + CLICK_SUPPRESS_WINDOW_MS;
      setIsPressed(false);
      d.pointerId = -1;
      d.dragging = false;
      if (newChecked !== checkedRef.current) {
        checkedRef.current = newChecked;
        onChange(newChecked);
      }
    } else {
      suppressClickUntilRef.current = 0;
      setIsPressed(false);
      d.pointerId = -1;
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (disabled) return;
    // 拖拽松手后浏览器仍会派发 click：已在 pointerup 里判定过，仅在时间窗内吞掉
    // 防二次切换；pointercancel（无 click 跟随）不再残留标志污染后续点击
    if (performance.now() < suppressClickUntilRef.current) {
      suppressClickUntilRef.current = 0;
      return;
    }
    onChange(!checked);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (disabled) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.stopPropagation();
      // 第 24 轮：长按连发（key repeat）不再重复生成涟漪 session；
      // 状态切换仍交给浏览器原生 click（与官方 md-switch 行为一致）
      if (e.repeat) return;
      // 涟漪生长点从轨道中心改为小球实际中心（状态层盒中心，与官方
      // “涟漪生长于贴着小球的状态层”语义一致）
      const center = (checkedRef.current ? TRAVEL_MAX : TRAVEL_MIN) - (checkedRef.current ? 0 : 2);
      const s = spawnStateLayerRipple(center, TRACK_H / 2);
      if (keyRippleTimerRef.current !== null) window.clearTimeout(keyRippleTimerRef.current);
      keyRippleTimerRef.current = window.setTimeout(() => {
        s.release(performance.now());
        keyRippleTimerRef.current = null;
      }, 120);
    }
  };

  // ===== 渲染参数（官方 token 对照见顶部注释）=====
  const thumbSize = isPressed ? 28 : checked || showIcons ? 24 : 16; // pressed-handle-*=28
  const restCenter = (checked ? TRAVEL_MAX : TRAVEL_MIN) - (checked ? 0 : 2);
  const ease = easedTransitions(isPressed, reducedMotion);
  // 用户要求的按压微放大（叠加官方 28px 形变）；reduced-motion 下关闭
  const scale = isPressed && !reducedMotion ? 1.05 : 1;
  // 第 24 轮：WebGL2 不可用时的 CSS 状态层兜底（官方 pressed-state-layer-opacity 0.12）
  const showCssStateLayer = isPressed && webglSupported === false;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onLostPointerCapture={() => handlePointerUp()}
      onKeyDown={handleKeyDown}
      onClick={handleClick}
      // 第 24 轮：移动端长按/拖拽期屏蔽长按弹莱单、文本选择与 iOS 呼出气泡
      onContextMenu={(e) => e.preventDefault()}
      style={{
        width: `${TRACK_W}px`,
        height: `${TRACK_H}px`,
        backgroundColor: checked ? accentHex : inactiveTrackHex,
        borderColor: !checked && outlineHex ? outlineHex : undefined,
        touchAction: 'none',
        WebkitTouchCallout: 'none',
        userSelect: 'none',
        cursor: disabled ? 'not-allowed' : isPressed ? 'grabbing' : 'grab',
      }}
      className={`relative inline-flex shrink-0 items-center rounded-full transition-colors duration-200 ease-[cubic-bezier(0.2,0,0,1)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--md-sys-color-primary)] ${
        disabled ? 'opacity-40 cursor-not-allowed' : ''
      } ${
        checked
          ? 'border-0'
          : `border-2 ${inactiveTrackHex ? '' : 'bg-slate-200 dark:bg-slate-800'} ${outlineHex ? '' : 'border-slate-500 dark:border-slate-400'}`
      }`}
    >
      {/* 官方同几何约束状态层：40×40 圆形（state-layer-size 40 · shape full），
          随小球移动（官方 md-ripple 挂在 handle-container 内），WebGL2 星斑着色器 +
          圆形 mask 裁形。拖拽期过渡由命令式接管。 */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        style={{
          left: `${restCenter - STATE_LAYER_RADIUS}px`,
          top: `${TRACK_H / 2 - STATE_LAYER_RADIUS}px`,
          width: `${STATE_LAYER_SIZE}px`,
          height: `${STATE_LAYER_SIZE}px`,
          transition: ease.canvas,
        }}
        className="pointer-events-none absolute z-20"
      />

      {/* 第 24 轮：WebGL2 不可用时的 CSS 状态层兜底 —— 几何与 WebGL 路径一致
          （40×40 圆、贴小球），按压淡入官方 pressed-state-layer-opacity 0.12，
          不再出现“按下无任何视觉反馈”的降级死区。 */}
      {showCssStateLayer && (
        <span
          aria-hidden="true"
          style={{
            left: `${restCenter - STATE_LAYER_RADIUS}px`,
            top: `${TRACK_H / 2 - STATE_LAYER_RADIUS}px`,
            width: `${STATE_LAYER_SIZE}px`,
            height: `${STATE_LAYER_SIZE}px`,
            backgroundColor: checked ? onPrimaryHex : (outlineHex ?? thumbUncheckedHex ?? '#1D1B20'),
            opacity: 0.12,
          }}
          className="pointer-events-none absolute z-20 rounded-full"
        />
      )}

      {/* Expressive Morphing Handle / Thumb（官方 24→28 按压形变 + 1.05 微放大） */}
      <span
        ref={thumbRef}
        aria-hidden="true"
        style={{
          width: `${thumbSize}px`,
          height: `${thumbSize}px`,
          left: `${restCenter}px`,
          backgroundColor: checked ? onPrimaryHex : thumbUncheckedHex,
          color: checked ? accentHex : thumbUncheckedIconHex,
          transform: `translate(-50%, -50%) scale(${scale})`,
          transition: ease.thumb,
        }}
        className={`pointer-events-none absolute top-1/2 z-30 flex items-center justify-center rounded-full shadow-xs ${
          checked
            ? ''
            : `${thumbUncheckedHex ? '' : 'bg-slate-600 dark:bg-slate-300'} ${thumbUncheckedIconHex ? '' : 'text-slate-100 dark:text-slate-900'}`
        }`}
      >
        {showIcons &&
          (checked ? (
            <Check className="h-4 w-4 stroke-[2.75]" aria-hidden="true" />
          ) : (
            <X className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
          ))}
      </span>
    </button>
  );
};
