"use client";
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, X } from 'lucide-react';
import {
  AOSP_MAX_RIPPLES,
  AospRippleEngineMode,
  getSharedRippleRenderer,
  RippleColorRGBA,
  RippleSession,
  SystemUiRippleShape,
} from '../../aosp/RippleEngine';

export interface AospExpressiveSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  ariaLabel: string;
  showIcons?: boolean;
  disabled?: boolean;
  mode: AospRippleEngineMode;
  waveColor: RippleColorRGBA;
  sparkleColor: RippleColorRGBA;
  sparkleStrength: number;
  distortionStrength: number;
  systemUiShape: SystemUiRippleShape;
  speedMultiplier: number;
  densityScale: number;
  accentHex: string;
  onPrimaryHex?: string;
  inactiveTrackHex?: string;
  outlineHex?: string;
  thumbUncheckedHex?: string;
  thumbUncheckedIconHex?: string;
}

/**
 * Exact M3 Expressive / AOSP MaterialSwitch tokens (tokens.xml & dimens.xml):
 * - Track: 52dp x 32dp, full pill radius
 * - Thumb unchecked (no icon): 16dp; (with icon): 24dp
 * - Thumb checked: 24dp
 * - Thumb pressed: 28dp (morphs dynamically on pointerdown)
 * - Icon inside thumb: 16dp
 * - Ripple state-layer halo: unbounded circular WebGL2 AOSP RippleShader centered on thumb
 */
const TRACK_W = 52;
const TRACK_H = 32;
const HALO_SIZE = 56;

export const AospExpressiveSwitch: React.FC<AospExpressiveSwitchProps> = ({
  checked,
  onChange,
  ariaLabel,
  showIcons = true,
  disabled = false,
  mode,
  waveColor,
  sparkleColor,
  sparkleStrength,
  distortionStrength,
  systemUiShape,
  speedMultiplier,
  densityScale,
  accentHex,
  onPrimaryHex = '#ffffff',
  inactiveTrackHex,
  outlineHex,
  thumbUncheckedHex,
  thumbUncheckedIconHex,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionsRef = useRef<RippleSession[]>([]);
  const activeSessionRef = useRef<RippleSession | null>(null);
  const rafRef = useRef<number | null>(null);
  const nextIdRef = useRef(1);

  const [isPressed, setIsPressed] = useState(false);

  const propsRef = useRef({
    mode,
    waveColor,
    sparkleColor,
    sparkleStrength,
    distortionStrength,
    systemUiShape,
    speedMultiplier,
    densityScale,
  });

  useEffect(() => {
    propsRef.current = {
      mode,
      waveColor,
      sparkleColor,
      sparkleStrength,
      distortionStrength,
      systemUiShape,
      speedMultiplier,
      densityScale,
    };
  });

  const startLoop = useCallback(() => {
    if (rafRef.current !== null) return;

    const tick = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        rafRef.current = null;
        return;
      }

      const now = performance.now();
      const sessions = sessionsRef.current;
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const pw = Math.round(HALO_SIZE * dpr);
      const ph = Math.round(HALO_SIZE * dpr);

      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
      }

      const renderer = getSharedRippleRenderer();
      renderer.renderSessions(sessions, HALO_SIZE, HALO_SIZE, dpr, now);

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, pw, ph);
        if (sessions.length > 0 && renderer.isSupported()) {
          ctx.drawImage(renderer.canvas, 0, 0, pw, ph, 0, 0, pw, ph);
        }
      }

      sessionsRef.current = sessions.filter((s) => !s.finished);
      if (sessionsRef.current.length > 0) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        if (ctx) ctx.clearRect(0, 0, pw, ph);
        rafRef.current = null;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  }, []);

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const spawnThumbRipple = useCallback(() => {
    const p = propsRef.current;
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    const center = HALO_SIZE * 0.5;

    if (sessionsRef.current.length >= AOSP_MAX_RIPPLES) {
      sessionsRef.current.shift();
    }

    const session = new RippleSession(
      nextIdRef.current++,
      {
        mode: p.mode,
        touchX: center,
        touchY: center,
        originX: center,
        originY: center,
        width: HALO_SIZE,
        height: HALO_SIZE,
        dpr,
        maxRadiusOverride: HALO_SIZE * 0.44,
        color: p.waveColor,
        sparkleColor: p.sparkleColor,
        sparkleStrength: p.sparkleStrength,
        distortionStrength: p.distortionStrength,
        systemUiShape: p.systemUiShape === 'rounded_box' ? 'circle' : p.systemUiShape,
        hasMask: false,
        maskRadius: 0,
        densityScale: p.densityScale,
        speedMultiplier: p.speedMultiplier,
      },
      performance.now()
    );

    sessionsRef.current.push(session);
    activeSessionRef.current = session;
    startLoop();
    return session;
  }, [startLoop]);

  const releaseThumbRipple = useCallback(() => {
    if (activeSessionRef.current) {
      activeSessionRef.current.release(performance.now());
      activeSessionRef.current = null;
    }
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (disabled) return;
    e.stopPropagation();
    setIsPressed(true);
    spawnThumbRipple();
  };

  const handlePointerUp = () => {
    if (isPressed) {
      setIsPressed(false);
      releaseThumbRipple();
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (disabled) return;
    onChange(!checked);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (disabled) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.stopPropagation();
      const s = spawnThumbRipple();
      window.setTimeout(() => s.release(performance.now()), 120);
    }
  };

  const thumbSize = isPressed ? 28 : checked || showIcons ? 24 : 16;
  const thumbCenterX = checked ? TRACK_W - TRACK_H * 0.5 : TRACK_H * 0.5;
  const borderInset = checked ? 0 : 2;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onPointerLeave={handlePointerUp}
      onKeyDown={handleKeyDown}
      onClick={handleClick}
      style={{
        width: `${TRACK_W}px`,
        height: `${TRACK_H}px`,
        backgroundColor: checked ? accentHex : inactiveTrackHex,
        borderColor: !checked && outlineHex ? outlineHex : undefined,
      }}
      className={`relative inline-flex shrink-0 items-center rounded-full transition-colors duration-200 ease-[cubic-bezier(0.2,0,0,1)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--md-sys-color-primary)] ${
        disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'
      } ${
        checked
          ? 'border-0'
          : `border-2 ${inactiveTrackHex ? '' : 'bg-slate-200 dark:bg-slate-800'} ${outlineHex ? '' : 'border-slate-500 dark:border-slate-400'}`
      }`}
    >
      {/* Unbounded WebGL2 AOSP Ripple Halo tracking the Thumb */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        style={{
          left: `${thumbCenterX - borderInset - HALO_SIZE * 0.5}px`,
          top: `${TRACK_H * 0.5 - HALO_SIZE * 0.5}px`,
          width: `${HALO_SIZE}px`,
          height: `${HALO_SIZE}px`,
        }}
        className="pointer-events-none absolute z-20 transition-[left] duration-200 ease-[cubic-bezier(0.2,0,0,1)]"
      />

      {/* Expressive Morphing Handle / Thumb */}
      <span
        aria-hidden="true"
        style={{
          width: `${thumbSize}px`,
          height: `${thumbSize}px`,
          left: `${thumbCenterX - borderInset}px`,
          backgroundColor: checked ? onPrimaryHex : thumbUncheckedHex,
          color: checked ? accentHex : thumbUncheckedIconHex,
        }}
        className={`pointer-events-none absolute top-1/2 -translate-x-1/2 -translate-y-1/2 z-30 flex items-center justify-center rounded-full shadow-xs transition-[left,width,height,background-color] duration-200 ease-[cubic-bezier(0.2,0,0,1)] ${
          checked
            ? ''
            : `${thumbUncheckedHex ? '' : 'bg-slate-600 dark:bg-slate-300'} ${thumbUncheckedIconHex ? '' : 'text-slate-100 dark:text-slate-900'}`
        }`}
      >
        {showIcons &&
          (checked ? (
            <Check className="h-4 w-4 stroke-[2.75]" aria-hidden="true" />
          ) : (
            <X className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
          ))}
      </span>
    </button>
  );
};
