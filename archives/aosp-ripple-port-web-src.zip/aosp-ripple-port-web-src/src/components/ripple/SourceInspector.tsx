"use client";
import React, { useState } from 'react';
import { Check, Copy } from '@/components/icons';
import {
  AOSP_FRAMEWORK_AGSL_SOURCE,
  AOSP_SESSION_JAVA_SOURCE,
  AOSP_SYSTEMUI_AGSL_SOURCE,
  FRAMEWORK_FRAGMENT_SHADER_GLSL,
} from '../../aosp/shaders';

type SourceTab =
  | 'agsl_framework'
  | 'session_java'
  | 'agsl_systemui'
  | 'qs_bounceable'
  | 'md3e_loading_wavy'
  | 'md3e_split_toolbar_fab'
  | 'mcu_hct_shapes'
  | 'webgl_port';

const AOSP_BOUNCEABLE_SOURCE = `// packages/SystemUI/compose/scene/src/com/android/compose/animation/Bounceable.kt
// + packages/SystemUI/src/com/android/systemui/qs/panels/ui/viewmodel/BounceableTileViewModel.kt
// + material-components-android MaterialButtonGroup.java & m3_button_group_child_size_change.xml

// 1. QS Tile Bounce (BounceSize = 8.dp):
//    animatableBounce.animateTo(8.dp); animatableBounce.animateTo(0.dp)
//    Only looks for neighbors on the same row (BounceableInfo.kt):
var sizePrevious = 0f
var sizeNext = 0f
if (previousBounceable != null) {
    sizePrevious += bounceable.bounce.toPx() - previousBounceable.bounce.toPx()
}
if (nextBounceable != null) {
    sizeNext += bounceable.bounce.toPx() - nextBounceable.bounce.toPx()
} else if (bounceEnd) {
    sizeNext += bounceable.bounce.toPx()
}
val animatedWidth = (idleWidth + sizePrevious + sizeNext).roundToInt()
placeable.placeRelative(-sizePrevious.roundToInt(), 0)

// 2. MDC MaterialButtonGroup (m3_button_group_child_size_change.xml: widthChange = 15%):
//    SpringForce: Motion_Material3_Spring_Standard_Fast_Spatial (k=1400, ζ=0.9)
//    Expressive Fast Spatial: (k=800, ζ=0.6)
if (prevVisibleButton == null) {
    nextVisibleButton.setDisplayedWidthDecrease(increaseSize);
} else if (nextVisibleButton == null) {
    prevVisibleButton.setDisplayedWidthDecrease(increaseSize);
} else {
    prevVisibleButton.setDisplayedWidthDecrease(increaseSize / 2);
    nextVisibleButton.setDisplayedWidthDecrease((increaseSize + 1) / 2);
}`;

const MD3E_LOADING_WAVY_SOURCE = `// 1. MDC-Android LoadingIndicator (material-components-android)
// - loadingindicator/LoadingIndicatorAnimatorDelegate.java
// - loadingindicator/LoadingIndicatorDrawingDelegate.java
// - shape/MaterialShapes.java + androidx.graphics.shapes.RoundedPolygon / Cubic / Morph
static final int DURATION_PER_SHAPE_IN_MS = 650;
static final int CONSTANT_ROTATION_PER_SHAPE_DEGREES = 50;
static final int EXTRA_ROTATION_PER_SHAPE_DEGREES = 90;
// SpringForce: stiffness = 200f, dampingRatio = 0.6f
// m3_loading_indicator_container_size = 48dp, m3_loading_indicator_shape_size = 38dp
static final RoundedPolygon[] INDETERMINATE_SHAPES = {
  MaterialShapes.SOFT_BURST, MaterialShapes.COOKIE_9, MaterialShapes.PENTAGON,
  MaterialShapes.PILL, MaterialShapes.SUNNY, MaterialShapes.COOKIE_4, MaterialShapes.OVAL
};

// 2. MDC-Android Wavy ProgressIndicator (material-components-android)
// - progressindicator/DrawingDelegate.java: WAVE_SMOOTHNESS = 0.48f
// - progressindicator/LinearDrawingDelegate.java: cubicTo(2*i + 0.48f, 0, 2*i + 1 - 0.48f, 1, 2*i + 1, 1)
// - progressindicator/CircularDrawingDelegate.java:
//   cycleCount = 2 * max(3, int(basePathLength / wavelength / 2))
//   tangent control length = halfWaveLength * WAVE_SMOOTHNESS (0.48f)
//   odd half-cycles radial offset = amplitude * 2, rendered with exact closed cubicTo arcs
// - progressindicator/res/values/tokens.xml & styles.xml:
//   Linear.Wavy: trackThickness = 4dp, stopIndicatorSize = 4dp, gap = 4dp,
//     waveAmplitude = 3dp (ramped over 0.1..0.9), wavelengthDet = 40dp, wavelengthIndet = 20dp
//   Circular.Wavy: size = 48dp, waveAmplitude = 1.6dp, wavelength = 15dp`;

const MD3E_SPLIT_TOOLBAR_FAB_SOURCE = `// 1. MDC-Android MaterialSplitButton & ButtonGroup Tokens
// - button/MaterialSplitButton.java & split_button_tokens.xml & button_group_tokens.xml
// - res/xml/m3_split_button_inner_corner_size_state_list.xml:
//   spacing = 2dp, outerCorner = 50%, innerCorner: default 4dp / pressed 12dp / checked 50%
// - res/drawable/m3_split_button_chevron_avd.xml (ic_expand_more_22px <-> ic_expand_less_22px)
// - Widget.Material3.MaterialButtonGroup.Connected: spacing = 2dp, inner = 8dp / pressed = 4dp / checked = 50%

// 2. MDC-Android FloatingToolbarLayout (floatingtoolbar/res/values/tokens.xml & styles.xml)
// - m3_comp_floating_toolbar_horizontal_container_height = 64dp
// - leading_space / trailing_space = 8dp, Corner.Full, Standard (surfaceContainer) / Vibrant (primaryContainer)

// 3. AOSP Compose FloatingActionButtonMenu (androidx/compose/material3)
// - FloatingActionButtonMenu.kt & tokens/FabMenuBaselineTokens.kt
// - ToggleButtonContainerHeight/Width = 56.dp, corner 16.dp -> 28.dp
// - ListItemContainerHeight = 56.dp, ListItemBetweenSpace = 4.dp, Leading/TrailingSpace = 24.dp, IconSize = 24.dp`;

const MCU_HCT_SHAPES_SOURCE = `// 1. androidx.graphics.shapes RoundedCorner & Cubic.circularArc (Shapes.kt / PolygonMeasure.kt / Morph.kt)
// Exact circular arc Bézier tangent formula:
//   k = (4/3) * (1 - cos(theta/2)) / sin(theta/2) = (4/3) * tan(theta/4)
//   flanking cuts resolve overlapping corner radii via corner.calculateCutAdjusts()
//   Morph.match(): LengthMeasurer(3) -> featureMapper (convex/concave match) -> DoubleMapper -> cutAndShift

// 2. Material Color Utilities (material-color-utilities)
// - HctSolver.java: 256 RGB critical planes -> exact bisection + Newton J* solver in Linear RGB
// - TonalPalette.java + KeyColor: binary search for peak chroma around tone 50
// - SchemeTonalSpot.java & SchemeExpressive.java (240deg primary hue shift + rotated secondary/tertiary)
// - Contrast.java: WCAG AA (>= 4.5:1) foregroundTone() verification for every background/text token pair
// - QuantizerWsmeans.java (CIELAB K-means) + Score.java (excitement filter & hue separation)`;

const TABS: { id: SourceTab; label: string; path: string; code: string }[] = [
  {
    id: 'agsl_framework',
    label: 'AOSP RippleShader.java',
    path: 'frameworks/base/graphics/java/android/graphics/drawable/RippleShader.java',
    code: AOSP_FRAMEWORK_AGSL_SOURCE,
  },
  {
    id: 'session_java',
    label: 'RippleAnimationSession.java',
    path: 'frameworks/base/graphics/java/android/graphics/drawable/RippleAnimationSession.java',
    code: AOSP_SESSION_JAVA_SOURCE,
  },
  {
    id: 'agsl_systemui',
    label: 'SystemUI RippleShader.kt',
    path: 'packages/SystemUI/animation/.../surfaceeffects/ripple/RippleShader.kt',
    code: AOSP_SYSTEMUI_AGSL_SOURCE,
  },
  {
    id: 'qs_bounceable',
    label: 'QS Bounceable & ButtonGroup',
    path: 'packages/SystemUI/.../Bounceable.kt & MaterialButtonGroup.java',
    code: AOSP_BOUNCEABLE_SOURCE,
  },
  {
    id: 'md3e_loading_wavy',
    label: 'MD3E Loading & Wavy',
    path: 'material-components-android: loadingindicator/*, shape/MaterialShapes.java, progressindicator/*',
    code: MD3E_LOADING_WAVY_SOURCE,
  },
  {
    id: 'mcu_hct_shapes',
    label: 'HCT 动态色与圆角形变',
    path: 'src/aosp/materialShapes.ts & src/aosp/dynamicColor.ts',
    code: MCU_HCT_SHAPES_SOURCE,
  },
  {
    id: 'md3e_split_toolbar_fab',
    label: 'MD3E Split / Toolbar / FABMenu',
    path: 'material-components-android & androidx/compose/material3/FloatingActionButtonMenu.kt',
    code: MD3E_SPLIT_TOOLBAR_FAB_SOURCE,
  },
  {
    id: 'webgl_port',
    label: 'WebGL2 GLSL ES 3.00 移植源码',
    path: 'src/aosp/shaders.ts (Framework Fragment Shader w/ vec4 u_maskRadii)',
    code: FRAMEWORK_FRAGMENT_SHADER_GLSL,
  },
];

export const SourceInspector: React.FC = React.memo(() => {
  const [activeTab, setActiveTab] = useState<SourceTab>('agsl_framework');
  const [copied, setCopied] = useState(false);

  const current = TABS.find((t) => t.id === activeTab) ?? TABS[0];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(current.code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      // Clipboard API unavailable
    }
  };

  return (
    <section id="source" className="scroll-mt-24 space-y-5">
      <div>
        <h2 className="font-display text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          AOSP 原始源码与 AGSL → WebGL2 移植对照
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          以下着色器常量、Uniform 公式、HCT 动态色与贝塞尔形变算法直接对照 AOSP / AndroidX / MDC-Android 仓库。
        </p>
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 px-4 py-3">
          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                已复制
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                复制源码
              </>
            )}
          </button>
        </div>

        <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 px-4 py-2 text-xs font-mono text-slate-500 dark:text-slate-400 truncate">
          {current.path}
        </div>

        <pre className="max-h-[420px] overflow-auto bg-slate-950 p-5 text-xs leading-relaxed text-slate-100 font-mono">
          <code>{current.code}</code>
        </pre>
      </div>
    </section>
  );
});
