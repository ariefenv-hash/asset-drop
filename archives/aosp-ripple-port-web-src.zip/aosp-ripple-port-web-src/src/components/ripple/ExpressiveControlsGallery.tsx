"use client";
import React, { useEffect, useRef, useState } from 'react';
import {
  AlignLeft,
  Bold,
  Camera,
  ChevronDown,
  Copy,
  Download,
  Edit3,
  FileText,
  Image as ImageIcon,
  Italic,
  Mic,
  Plus,
  Share2,
  Underline,
} from 'lucide-react';
import { hexToRgbaWave, M3ThemeTokens } from '../../aosp/dynamicColor';
import {
  getLoadingIndicatorMorphCubics,
  LOADING_INDICATOR_SHAPES,
} from '../../aosp/materialShapes';
import { SpringState, stepSpring } from '../../aosp/spring';
import { AospExpressiveSlider } from './AospExpressiveSlider';
import { AospRippleSurface } from './AospRippleSurface';
import { LabConfigState } from './InteractiveLab';

interface ExpressiveControlsGalleryProps {
  isDark: boolean;
  config: LabConfigState;
  theme: M3ThemeTokens;
}

/**
 * M3 Expressive LoadingIndicator spring constants from
 * LoadingIndicatorAnimatorDelegate.java:
 * - DURATION_PER_SHAPE_IN_MS = 650
 * - CONSTANT_ROTATION_PER_SHAPE_DEGREES = 50
 * - EXTRA_ROTATION_PER_SHAPE_DEGREES = 90
 * - SPRING_STIFFNESS = 200f, SPRING_DAMPING_RATIO = 0.6f
 */
const LOADING_SHAPE_DURATION_MS = 650;
const LOADING_SPRING = { stiffness: 200, dampingRatio: 0.6 };

/**
 * MDC-Android DrawingDelegate.java WAVE_SMOOTHNESS = 0.48f
 * LinearDrawingDelegate.java & CircularDrawingDelegate.java cubic wave math
 */
const WAVE_SMOOTHNESS = 0.48;

function cubicSolveTForX(targetNormX: number, s: number): number {
  const x = Math.max(0, Math.min(1, targetNormX));
  let t = x;
  for (let iter = 0; iter < 5; iter++) {
    const omt = 1 - t;
    const bx = 3 * omt * omt * t * s + 3 * omt * t * t * (1 - s) + t * t * t;
    const dbx = 3 * omt * omt * s + 6 * omt * t * (1 - 2 * s) + 3 * t * t * s;
    if (Math.abs(dbx) < 1e-5) break;
    t = Math.max(0, Math.min(1, t - (bx - x) / dbx));
  }
  return t;
}

function splitCubicBezier(
  p0: [number, number],
  p1: [number, number],
  p2: [number, number],
  p3: [number, number],
  t0: number,
  t1: number
): [[number, number], [number, number], [number, number], [number, number]] {
  const lerpPt = (
    a: [number, number],
    b: [number, number],
    t: number
  ): [number, number] => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

  const subFromT = (
    q0: [number, number],
    q1: [number, number],
    q2: [number, number],
    q3: [number, number],
    t: number,
    takeRight: boolean
  ): [[number, number], [number, number], [number, number], [number, number]] => {
    const a = lerpPt(q0, q1, t);
    const b = lerpPt(q1, q2, t);
    const c = lerpPt(q2, q3, t);
    const d = lerpPt(a, b, t);
    const e = lerpPt(b, c, t);
    const f = lerpPt(d, e, t);
    return takeRight ? [f, e, c, q3] : [q0, a, d, f];
  };

  let seg: [[number, number], [number, number], [number, number], [number, number]] = [
    p0,
    p1,
    p2,
    p3,
  ];
  let remT1 = t1;
  if (t0 > 1e-4) {
    seg = subFromT(seg[0], seg[1], seg[2], seg[3], t0, true);
    remT1 = (t1 - t0) / (1 - t0);
  }
  if (remT1 < 1 - 1e-4) {
    seg = subFromT(seg[0], seg[1], seg[2], seg[3], remT1, false);
  }
  return seg;
}

function buildLinearWaveSvgPath(
  startX: number,
  endX: number,
  centerY: number,
  wavelength: number,
  amplitude: number,
  phaseShiftPx: number
): string {
  const len = endX - startX;
  if (len <= 1) return '';
  if (amplitude <= 0.08) {
    return `M ${startX.toFixed(2)} ${centerY.toFixed(2)} L ${endX.toFixed(2)} ${centerY.toFixed(2)}`;
  }

  const halfWave = Math.max(4, wavelength * 0.5);
  const uStart = phaseShiftPx / halfWave;
  const uEnd = (len + phaseShiftPx) / halfWave;
  const firstHalfIdx = Math.floor(uStart);
  const lastHalfIdx = Math.ceil(uEnd) - 1;

  const commands: string[] = [];

  for (let idx = firstHalfIdx; idx <= lastHalfIdx; idx++) {
    const goingDown = ((idx % 2) + 2) % 2 === 0;
    const y0 = goingDown ? centerY - amplitude : centerY + amplitude;
    const y1 = goingDown ? centerY + amplitude : centerY - amplitude;
    const segStartX = startX + (idx - uStart) * halfWave;
    const segEndX = segStartX + halfWave;

    const p0: [number, number] = [segStartX, y0];
    const p1: [number, number] = [segStartX + halfWave * WAVE_SMOOTHNESS, y0];
    const p2: [number, number] = [segEndX - halfWave * WAVE_SMOOTHNESS, y1];
    const p3: [number, number] = [segEndX, y1];

    const clipLeft = Math.max(0, (startX - segStartX) / halfWave);
    const clipRight = Math.min(1, (endX - segStartX) / halfWave);
    if (clipRight <= clipLeft + 1e-4) continue;

    const t0 = clipLeft > 1e-4 ? cubicSolveTForX(clipLeft, WAVE_SMOOTHNESS) : 0;
    const t1 = clipRight < 1 - 1e-4 ? cubicSolveTForX(clipRight, WAVE_SMOOTHNESS) : 1;

    const [s0, s1, s2, s3] = splitCubicBezier(p0, p1, p2, p3, t0, t1);
    if (commands.length === 0) {
      commands.push(`M ${s0[0].toFixed(2)} ${s0[1].toFixed(2)}`);
    }
    commands.push(
      `C ${s1[0].toFixed(2)} ${s1[1].toFixed(2)}, ${s2[0].toFixed(2)} ${s2[1].toFixed(2)}, ${s3[0].toFixed(2)} ${s3[1].toFixed(2)}`
    );
  }

  return commands.join(' ');
}

/**
 * Exact CircularDrawingDelegate.java cubic Bezier circular wave generator:
 * - cycleCount = max(4, floor((2 * PI * radius) / wavelength)) full waves around the circle
 * - Two cubic Beziers per full wave with tangent controlLength = halfWaveLength * WAVE_SMOOTHNESS (0.48)
 * - Mid-anchors shifted inward by amplitude * 2
 * - Clipped to [startDeg, startDeg + sweepDeg] via exact De Casteljau splitCubicBezier
 */
function buildCircularWaveSvgPath(
  cx: number,
  cy: number,
  radius: number,
  startDeg: number,
  sweepDeg: number,
  wavelength: number,
  amplitude: number,
  phaseCycles: number
): string {
  const clampedSweep = Math.min(360, Math.max(0, sweepDeg));
  if (clampedSweep <= 0.5) return '';

  const basePathLength = 2 * Math.PI * radius;
  const waveCount = Math.max(4, Math.floor(basePathLength / Math.max(4, wavelength)));
  const adjustedWavelength = basePathLength / waveCount;
  const halfCycleCount = waveCount * 2;
  const halfStepRad = Math.PI / waveCount;
  const controlLength = (adjustedWavelength * 0.5) * WAVE_SMOOTHNESS;
  const phaseRad = phaseCycles * ((2 * Math.PI) / waveCount);

  const startRad = ((startDeg - 90) * Math.PI) / 180;
  const endRad = ((startDeg + clampedSweep - 90) * Math.PI) / 180;

  const anchorAt = (
    halfIdx: number
  ): { pos: [number, number]; tan: [number, number] } => {
    const theta = -Math.PI * 0.5 + halfIdx * halfStepRad + phaseRad;
    const isMidTrough = (((halfIdx % 2) + 2) % 2) === 1;
    const r = isMidTrough ? Math.max(2, radius - amplitude * 2) : radius;
    return {
      pos: [cx + r * Math.cos(theta), cy + r * Math.sin(theta)],
      tan: [-Math.sin(theta), Math.cos(theta)],
    };
  };

  const theta0Base = -Math.PI * 0.5 + phaseRad;
  const firstHalfIdx = Math.floor((startRad - theta0Base) / halfStepRad);
  const lastHalfIdx = Math.ceil((endRad - theta0Base) / halfStepRad) - 1;

  const commands: string[] = [];

  for (let idx = firstHalfIdx; idx <= lastHalfIdx; idx++) {
    const segStartTheta = theta0Base + idx * halfStepRad;
    const segEndTheta = segStartTheta + halfStepRad;

    const a1 = anchorAt(idx);
    const a2 = anchorAt(idx + 1);

    const p0 = a1.pos;
    const p1: [number, number] = [
      a1.pos[0] + a1.tan[0] * controlLength,
      a1.pos[1] + a1.tan[1] * controlLength,
    ];
    const p2: [number, number] = [
      a2.pos[0] - a2.tan[0] * controlLength,
      a2.pos[1] - a2.tan[1] * controlLength,
    ];
    const p3 = a2.pos;

    const clipLeft = Math.max(0, (startRad - segStartTheta) / halfStepRad);
    const clipRight = Math.min(1, (endRad - segStartTheta) / halfStepRad);
    if (clipRight <= clipLeft + 1e-4) continue;

    const [s0, s1, s2, s3] = splitCubicBezier(p0, p1, p2, p3, clipLeft, clipRight);
    if (commands.length === 0) {
      commands.push(`M ${s0[0].toFixed(2)} ${s0[1].toFixed(2)}`);
    }
    commands.push(
      `C ${s1[0].toFixed(2)} ${s1[1].toFixed(2)}, ${s2[0].toFixed(2)} ${s2[1].toFixed(2)}, ${s3[0].toFixed(2)} ${s3[1].toFixed(2)}`
    );
  }

  return commands.join(' ');
}

export const ExpressiveControlsGallery: React.FC<ExpressiveControlsGalleryProps> = ({
  isDark,
  config,
  theme,
}) => {
  const waveColor = hexToRgbaWave(
    theme.primary,
    Math.max(isDark ? 0.24 : 0.22, config.waveAlpha)
  );
  const filledWave = { r: 1, g: 1, b: 1, a: 0.28 };
  const sparkleColor = { r: 1, g: 1, b: 1, a: config.sparkleAlpha };

  // 1. LoadingIndicator (MDC LoadingIndicatorAnimatorDelegate.java + RoundedPolygon Cubics)
  const loadingDefaultCanvasRef = useRef<HTMLCanvasElement>(null);
  const loadingContainedCanvasRef = useRef<HTMLCanvasElement>(null);
  const [loadingPaused, setLoadingPaused] = useState(false);
  const [activeShapeIdx, setActiveShapeIdx] = useState(0);
  const [cubicCount, setCubicCount] = useState(41);

  const springRef = useRef<SpringState>({ value: 0, velocity: 0, target: 1 });
  const morphTargetRef = useRef(1);
  const cycleElapsedRef = useRef(0);

  const loadingPausedRef = useRef(loadingPaused);
  const speedRef = useRef(config.speedMultiplier);
  const themeRef = useRef(theme);
  useEffect(() => {
    loadingPausedRef.current = loadingPaused;
    speedRef.current = config.speedMultiplier;
    themeRef.current = theme;
  });

  const jumpToShape = (shapeIndex: number) => {
    const count = LOADING_INDICATOR_SHAPES.length;
    const normalized = ((shapeIndex % count) + count) % count;
    morphTargetRef.current = normalized + 1;
    cycleElapsedRef.current = 0;
    springRef.current.value = normalized;
    springRef.current.velocity = 0;
    springRef.current.target = loadingPaused ? normalized : normalized + 1;
    setActiveShapeIdx(normalized);
  };

  useEffect(() => {
    let lastTime = performance.now();
    let rafId = 0;
    let lastReportedIdx = -1;
    let lastReportedCubics = -1;

    const drawToCanvas = (
      canvas: HTMLCanvasElement | null,
      morphVal: number,
      rotDeg: number,
      contained: boolean
    ): number => {
      if (!canvas) return 0;
      const t = themeRef.current;
      // 第 25 轮（用户复核）：撤销 2.5 的 DPR 封顶——旧值在浏览器缩放（DPR 1 屏 300% =>
      // dpr=3）或 2x 屏 200% 缩放（dpr=4）下把 48dp 硬边贝塞尔剪影按 ~1.2-1.6 倍上采样，
      // 放大后与周围 SVG/文本相比明显发虚。两块 48dp 小画布逐帧重设后备缓冲的代价可忽略，
      // 改按真实 devicePixelRatio × visualViewport 捏合缩放重建（封顶 8 仅防病态值）；
      // 大面积 WebGL 涟漪画布（InteractiveLab / RippleSurface / Switch 状态层）维持 2.5
      // 封顶——软边渐变下该差异不可见，且是既定性能口径。
      const vvScale = window.visualViewport?.scale ?? 1;
      const dpr = Math.min((window.devicePixelRatio || 1) * vvScale, 8);
      const sizeCss = 48; // m3_loading_indicator_container_size = 48dp
      const px = Math.round(sizeCss * dpr);
      if (canvas.width !== px || canvas.height !== px) {
        canvas.width = px;
        canvas.height = px;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) return 0;

      ctx.save();
      ctx.clearRect(0, 0, px, px);
      ctx.scale(dpr, dpr);

      if (contained) {
        ctx.fillStyle = t.primaryContainer;
        ctx.beginPath();
        ctx.arc(sizeCss * 0.5, sizeCss * 0.5, sizeCss * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // 38dp polygon centered inside 48dp container -> half = 19dp
      const { cubics } = getLoadingIndicatorMorphCubics(morphVal);
      const scale = 38 * 0.5;
      ctx.translate(sizeCss * 0.5, sizeCss * 0.5);
      ctx.rotate(((rotDeg - 90) * Math.PI) / 180);

      ctx.beginPath();
      if (cubics.length > 0) {
        ctx.moveTo(cubics[0].anchor0X * scale, cubics[0].anchor0Y * scale);
        for (let i = 0; i < cubics.length; i++) {
          const c = cubics[i];
          ctx.bezierCurveTo(
            c.control0X * scale,
            c.control0Y * scale,
            c.control1X * scale,
            c.control1Y * scale,
            c.anchor1X * scale,
            c.anchor1Y * scale
          );
        }
        ctx.closePath();
      }

      ctx.fillStyle = contained ? t.onPrimaryContainer : t.primary;
      ctx.fill();
      ctx.restore();
      return cubics.length;
    };

    const tick = (now: number) => {
      const rawDt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;
      const dt = rawDt * Math.max(0.15, speedRef.current);
      const spring = springRef.current;

      if (!loadingPausedRef.current) {
        cycleElapsedRef.current += dt * 1000;
        if (cycleElapsedRef.current >= LOADING_SHAPE_DURATION_MS) {
          cycleElapsedRef.current %= LOADING_SHAPE_DURATION_MS;
          morphTargetRef.current += 1;
          spring.target = morphTargetRef.current;
        }
        stepSpring(spring, dt, LOADING_SPRING);
      }

      const morphFactorBase = morphTargetRef.current - 1;
      const morphFactorPerShape = spring.value - morphFactorBase;
      const timeFactorPerShape = cycleElapsedRef.current / LOADING_SHAPE_DURATION_MS;
      const rotDeg = loadingPausedRef.current
        ? ((50 + 90) * morphFactorBase) % 360
        : ((50 + 90) * morphFactorBase +
            50 * timeFactorPerShape +
            90 * morphFactorPerShape) %
          360;

      const idx =
        ((morphFactorBase % LOADING_INDICATOR_SHAPES.length) +
          LOADING_INDICATOR_SHAPES.length) %
        LOADING_INDICATOR_SHAPES.length;
      if (idx !== lastReportedIdx) {
        lastReportedIdx = idx;
        setActiveShapeIdx(idx);
      }

      const cubicsUsed = drawToCanvas(
        loadingDefaultCanvasRef.current,
        spring.value,
        rotDeg,
        false
      );
      drawToCanvas(loadingContainedCanvasRef.current, spring.value, rotDeg, true);
      if (cubicsUsed > 0 && cubicsUsed !== lastReportedCubics) {
        lastReportedCubics = cubicsUsed;
        setCubicCount(cubicsUsed);
      }
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, []);

  // 2. Wavy Progress Indicators
  const [wavyProgress, setWavyProgress] = useState(62);
  const [wavyIndeterminate, setWavyIndeterminate] = useState(false);
  const [wavePhase, setWavePhase] = useState(0);

  useEffect(() => {
    let last = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000) * Math.max(0.15, speedRef.current);
      last = now;
      setWavePhase((p) => (p + dt) % 1000);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // 3. MaterialSplitButton & Connected ButtonGroup
  const [splitMenuOpen, setSplitMenuOpen] = useState(false);
  const [splitPressedPart, setSplitPressedPart] = useState<'lead' | 'trail' | null>(null);
  const [splitActionLabel, setSplitActionLabel] = useState('快速编辑');

  const [connectedChecked, setConnectedChecked] = useState<number[]>([0]);
  const [connectedPressedIdx, setConnectedPressedIdx] = useState<number | null>(null);

  // 4. FloatingToolbarLayout & FloatingActionButtonMenu
  const [toolbarTool, setToolbarTool] = useState('bold');
  const [fabMenuOpen, setFabMenuOpen] = useState(false);
  const [fabMenuAction, setFabMenuAction] = useState('点击 + 展开 FAB Menu');

  // Linear Wavy calculations matching LinearDrawingDelegate.java
  const linearSvgW = 300;
  const linearSvgH = 20;
  const linearCenterY = linearSvgH * 0.5;
  const linearFrac = wavyProgress / 100;
  const linearAmpFactor = wavyIndeterminate
    ? 1
    : linearFrac < 0.1
      ? linearFrac / 0.1
      : linearFrac > 0.9
        ? Math.max(0, (1 - linearFrac) / 0.1)
        : 1;
  const linearAmp = 3 * linearAmpFactor;
  const linearWavelength = wavyIndeterminate ? 20 : 40;
  const linearGap = 4;
  const linearStartX = wavyIndeterminate
    ? ((wavePhase * 0.55) % 1.3 - 0.3) * linearSvgW
    : 2;
  const linearEndX = wavyIndeterminate
    ? Math.min(linearSvgW - 2, linearStartX + linearSvgW * 0.42)
    : 2 + (linearSvgW - 4) * linearFrac;
  const clampedStartX = Math.max(2, linearStartX);
  const linearActivePath =
    linearEndX > clampedStartX + 2
      ? buildLinearWaveSvgPath(
          clampedStartX,
          linearEndX,
          linearCenterY,
          linearWavelength,
          linearAmp,
          wavePhase * 28
        )
      : '';
  const linearTrackStartX = wavyIndeterminate
    ? 2
    : Math.min(linearSvgW - 2, linearEndX + (linearFrac > 0.01 ? linearGap + 2 : 0));

  // Circular Wavy calculations matching CircularDrawingDelegate.java
  const circSize = 48;
  const circCx = circSize * 0.5;
  const circCy = circSize * 0.5;
  const circOuterPeakR = 20.5;
  const circAmpFactor = wavyIndeterminate
    ? 1
    : linearFrac < 0.1
      ? linearFrac / 0.1
      : linearFrac > 0.9
        ? Math.max(0, (1 - linearFrac) / 0.1)
        : 1;
  const circAmp = 1.6 * circAmpFactor;
  const circWavelength = 15;
  const circGapDeg = (4 / circOuterPeakR) * (180 / Math.PI) + 12;
  const circStartDeg = wavyIndeterminate ? (wavePhase * 210) % 360 : 0;
  const circSweepDeg = wavyIndeterminate
    ? 120 + 95 * Math.sin(wavePhase * 2.2)
    : linearFrac * 360;
  const circActivePath = buildCircularWaveSvgPath(
    circCx,
    circCy,
    circOuterPeakR,
    circStartDeg,
    Math.max(0, circSweepDeg - (!wavyIndeterminate && linearFrac > 0.02 && linearFrac < 0.98 ? 4 : 0)),
    circWavelength,
    circAmp,
    -wavePhase * 1.4
  );
  const circTrackStartDeg = circStartDeg + circSweepDeg + circGapDeg * 0.5;
  const circTrackSweepDeg = Math.max(
    0,
    360 - circSweepDeg - (linearFrac > 0.02 || wavyIndeterminate ? circGapDeg : 0)
  );
  const circTrackPath =
    circTrackSweepDeg > 4
      ? buildCircularWaveSvgPath(
          circCx,
          circCy,
          circOuterPeakR - circAmp,
          circTrackStartDeg,
          circTrackSweepDeg,
          circWavelength,
          0,
          0
        )
      : '';

  const splitLeadInner = splitMenuOpen ? 24 : splitPressedPart === 'lead' ? 12 : 4;
  const splitTrailInner = splitMenuOpen ? 24 : splitPressedPart === 'trail' ? 12 : 4;

  const connectedButtons = [
    { id: 0, label: '粗体', icon: Bold },
    { id: 1, label: '斜体', icon: Italic },
    { id: 2, label: '下划线', icon: Underline },
    { id: 3, label: '左对齐', icon: AlignLeft },
  ];

  const fabMenuItems = [
    { label: '拍摄照片', icon: Camera },
    { label: '上传图片', icon: ImageIcon },
    { label: '新建文档', icon: FileText },
    { label: '语音备忘', icon: Mic },
  ];

  const toggleConnected = (idx: number) => {
    setConnectedChecked((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const activeShape = LOADING_INDICATOR_SHAPES[activeShapeIdx] ?? LOADING_INDICATOR_SHAPES[0];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 1. LoadingIndicator & MaterialShapes */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs flex flex-col justify-between gap-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                M3 Expressive LoadingIndicator (RoundedPolygon Cubic Morph)
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                对照 <code className="font-mono">androidx.graphics.shapes</code> +{' '}
                <code className="font-mono">MaterialShapes.java</code>：用{' '}
                <code className="font-mono">Cubic.circularArc</code> 与{' '}
                <code className="font-mono">Morph</code> 渲染真实三次贝塞尔圆角，650ms 周期 + Spring(k=200, ζ=0.6) 连续形变 7 种图形。
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setLoadingPaused((p) => {
                  const next = !p;
                  if (!next) {
                    morphTargetRef.current += 1;
                    springRef.current.target = morphTargetRef.current;
                  }
                  return next;
                });
              }}
              className="shrink-0 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              {loadingPaused ? '继续' : '暂停'}
            </button>
          </div>

          <div className="flex items-center justify-around rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 py-5 px-4">
            <div className="flex flex-col items-center gap-2">
              <canvas
                ref={loadingDefaultCanvasRef}
                width={96}
                height={96}
                style={{ width: 48, height: 48 }}
                aria-label="M3 Expressive Default LoadingIndicator"
              />
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                Default (48dp)
              </span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <canvas
                ref={loadingContainedCanvasRef}
                width={96}
                height={96}
                style={{ width: 48, height: 48 }}
                aria-label="M3 Expressive Contained LoadingIndicator"
              />
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                Contained (48dp)
              </span>
            </div>

            <div className="text-right space-y-1">
              <div className="text-[11px] text-slate-500 dark:text-slate-400">当前几何原型</div>
              <div
                className="font-mono text-xs font-semibold"
                style={{ color: theme.primary }}
              >
                0{activeShapeIdx + 1}/07 · {activeShape.label}
              </div>
              <div className="font-mono text-[10px] text-slate-400 tabular-nums">
                {cubicCount} cubics · k=200 · ζ=0.6
              </div>
            </div>
          </div>

          {/* Interactive 7-shape segmented selector */}
          <div className="grid grid-cols-7 gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
            {LOADING_INDICATOR_SHAPES.map((s, idx) => {
              const active = idx === activeShapeIdx;
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => jumpToShape(idx)}
                  title={`跳转到第 ${idx + 1} 种图形: ${s.label}`}
                  style={
                    active
                      ? { backgroundColor: theme.primary, color: theme.onPrimary }
                      : undefined
                  }
                  className={`rounded-md py-1 text-[10px] font-mono transition-colors truncate px-1 whitespace-nowrap ${
                    active
                      ? 'font-semibold shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Wavy Progress Indicators (Linear + Circular cubic Beziers) */}
        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs flex flex-col justify-between gap-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                M3 Expressive Wavy ProgressIndicator (Cubic 波形进度条 &amp; 圆环)
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                对照 <code className="font-mono">LinearDrawingDelegate.java</code> 与{' '}
                <code className="font-mono">CircularDrawingDelegate.java</code>：
                正切句柄比例 WAVE_SMOOTHNESS=0.48，线形波幅 3dp · 4dp 断隙；环形 48dp · 波幅 1.6dp · 波长 15dp 纯三次贝塞尔构建。
              </p>
            </div>
            <button
              type="button"
              onClick={() => setWavyIndeterminate((v) => !v)}
              style={
                wavyIndeterminate
                  ? {
                      backgroundColor: theme.primary,
                      borderColor: theme.primary,
                      color: theme.onPrimary,
                    }
                  : undefined
              }
              className={`shrink-0 rounded-lg px-2.5 py-1 text-xs font-medium border transition-colors whitespace-nowrap ${
                wavyIndeterminate
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {wavyIndeterminate ? 'Indeterminate 模式' : 'Determinate 模式'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-center rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 p-4">
            <div className="sm:col-span-9 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400">
                <span>LinearProgressIndicator.Wavy (WAVE_SMOOTHNESS={WAVE_SMOOTHNESS})</span>
                <span className="tabular-nums">
                  {wavyIndeterminate ? 'λ=20dp' : `λ=40dp · ${wavyProgress}%`}
                </span>
              </div>
              <svg
                viewBox={`0 0 ${linearSvgW} ${linearSvgH}`}
                className="w-full h-7 overflow-visible"
                role="img"
                aria-label="Material 3 Expressive Linear Wavy Progress Indicator"
              >
                {linearTrackStartX < linearSvgW - 2 && (
                  <line
                    x1={linearTrackStartX}
                    y1={linearCenterY}
                    x2={linearSvgW - 2}
                    y2={linearCenterY}
                    stroke={theme.secondaryContainer}
                    strokeWidth={4}
                    strokeLinecap="round"
                  />
                )}
                {!wavyIndeterminate && linearFrac < 0.97 && (
                  <circle
                    cx={linearSvgW - 4}
                    cy={linearCenterY}
                    r={2}
                    fill={theme.primary}
                  />
                )}
                {linearActivePath && (
                  <path
                    d={linearActivePath}
                    fill="none"
                    stroke={theme.primary}
                    strokeWidth={4}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                )}
              </svg>
            </div>

            <div className="sm:col-span-3 flex flex-col items-center gap-1.5">
              <svg
                width={48}
                height={48}
                viewBox={`0 0 ${circSize} ${circSize}`}
                className="overflow-visible"
                role="img"
                aria-label="Material 3 Expressive Circular Wavy Progress Indicator"
              >
                {circTrackPath && (
                  <path
                    d={circTrackPath}
                    fill="none"
                    stroke={theme.secondaryContainer}
                    strokeWidth={4}
                    strokeLinecap="round"
                  />
                )}
                {circActivePath && (
                  <path
                    d={circActivePath}
                    fill="none"
                    stroke={theme.primary}
                    strokeWidth={4}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                )}
              </svg>
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                Circular 48dp
              </span>
            </div>
          </div>

          <AospExpressiveSlider
            label="波形进度控制 (waveAmplitude ramp 0.1–0.9)"
            value={wavyProgress}
            min={0}
            max={100}
            step={1}
            size="xs"
            compact
            unit="%"
            mode={config.mode}
            waveColor={waveColor}
            sparkleColor={sparkleColor}
            sparkleStrength={config.sparkleStrength}
            distortionStrength={config.distortionStrength}
            systemUiShape={config.systemUiShape}
            speedMultiplier={config.speedMultiplier}
            densityScale={config.densityScale}
            accentHex={theme.primary}
            theme={theme}
            onChange={(v) => {
              if (wavyIndeterminate) setWavyIndeterminate(false);
              setWavyProgress(v);
            }}
          />
        </div>
      </div>

      {/* 3. MaterialSplitButton, Connected ButtonGroup, FloatingToolbar & FAB Menu */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              MaterialSplitButton 与 Connected ButtonGroup（不对称圆角实时跟踪）
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              对照 <code className="font-mono">MaterialSplitButton.java</code> 与{' '}
              <code className="font-mono">m3_split_button_inner_corner_size_state_list.xml</code>：
              间距 2dp，内侧圆角 4dp → 按下 12dp → 展开 50%，WebGL2 SDF 实时读取四角落差并全覆盖裁切。
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 p-4">
            <div className="relative">
              <div className="inline-flex items-center gap-[2px]">
                <div
                  onPointerDown={() => setSplitPressedPart('lead')}
                  onPointerUp={() => setSplitPressedPart(null)}
                  onPointerCancel={() => setSplitPressedPart(null)}
                  onPointerLeave={() => setSplitPressedPart(null)}
                >
                  <AospRippleSurface
                    role="button"
                    tabIndex={0}
                    onClick={() => setSplitActionLabel('已执行主操作')}
                    mode={config.mode}
                    color={filledWave}
                    sparkleColor={sparkleColor}
                    sparkleStrength={config.sparkleStrength}
                    distortionStrength={config.distortionStrength}
                    systemUiShape={config.systemUiShape}
                    speedMultiplier={config.speedMultiplier}
                    densityScale={config.densityScale}
                    style={{
                      backgroundColor: theme.primary,
                      color: theme.onPrimary,
                      borderTopLeftRadius: '24px',
                      borderBottomLeftRadius: '24px',
                      borderTopRightRadius: `${splitLeadInner}px`,
                      borderBottomRightRadius: `${splitLeadInner}px`,
                    }}
                    className="flex h-12 items-center pl-4 pr-3 text-xs font-medium transition-[border-radius,background-color] duration-200 ease-[cubic-bezier(0.2,0,0,1)]"
                  >
                    <span className="inline-flex items-center gap-2 whitespace-nowrap">
                      <Edit3 className="h-4 w-4" />
                      {splitActionLabel}
                    </span>
                  </AospRippleSurface>
                </div>

                <div
                  onPointerDown={() => setSplitPressedPart('trail')}
                  onPointerUp={() => setSplitPressedPart(null)}
                  onPointerCancel={() => setSplitPressedPart(null)}
                  onPointerLeave={() => setSplitPressedPart(null)}
                >
                  <AospRippleSurface
                    role="button"
                    tabIndex={0}
                    ariaLabel="展开拆分菜单"
                    ariaPressed={splitMenuOpen}
                    onClick={() => setSplitMenuOpen((o) => !o)}
                    mode={config.mode}
                    color={filledWave}
                    sparkleColor={sparkleColor}
                    sparkleStrength={config.sparkleStrength}
                    distortionStrength={config.distortionStrength}
                    systemUiShape={config.systemUiShape}
                    speedMultiplier={config.speedMultiplier}
                    densityScale={config.densityScale}
                    style={{
                      backgroundColor: theme.primary,
                      color: theme.onPrimary,
                      borderTopLeftRadius: `${splitTrailInner}px`,
                      borderBottomLeftRadius: `${splitTrailInner}px`,
                      borderTopRightRadius: '24px',
                      borderBottomRightRadius: '24px',
                    }}
                    className="flex h-12 w-12 items-center justify-center transition-[border-radius,background-color] duration-200 ease-[cubic-bezier(0.2,0,0,1)]"
                  >
                    <ChevronDown
                      className={`h-5 w-5 transition-transform duration-200 ease-[cubic-bezier(0.2,0,0,1)] ${
                        splitMenuOpen ? 'rotate-180' : 'rotate-0'
                      }`}
                    />
                  </AospRippleSurface>
                </div>
              </div>

              {splitMenuOpen && (
                <div className="mt-2 w-44 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-1.5 shadow-lg z-30">
                  {[
                    { label: '导出模板', icon: Download },
                    { label: '复制链接', icon: Copy },
                    { label: '分享配置', icon: Share2 },
                  ].map((opt) => {
                    const OptIcon = opt.icon;
                    return (
                      <AospRippleSurface
                        key={opt.label}
                        role="button"
                        tabIndex={0}
                        onClick={() => {
                          setSplitActionLabel(opt.label);
                          setSplitMenuOpen(false);
                        }}
                        mode={config.mode}
                        color={waveColor}
                        sparkleColor={sparkleColor}
                        sparkleStrength={config.sparkleStrength}
                        distortionStrength={config.distortionStrength}
                        systemUiShape={config.systemUiShape}
                        speedMultiplier={config.speedMultiplier}
                        densityScale={config.densityScale}
                        style={{ borderRadius: '12px' }}
                        className="px-3 py-2 text-xs text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700/60"
                      >
                        <span className="flex items-center gap-2">
                          <OptIcon className="h-3.5 w-3.5" />
                          {opt.label}
                        </span>
                      </AospRippleSurface>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
              innerCorner: {splitMenuOpen ? '50% (24dp)' : splitPressedPart ? '12dp' : '4dp'}
            </div>
          </div>

          {/* Connected ButtonGroup */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
              <span>MaterialButtonGroup.Connected (spacing 2dp · inner 8dp → checked 50%)</span>
            </div>
            <div className="flex w-full items-center gap-[2px]">
              {connectedButtons.map((btn, i) => {
                const Icon = btn.icon;
                const checked = connectedChecked.includes(i);
                const pressed = connectedPressedIdx === i;
                const isFirst = i === 0;
                const isLast = i === connectedButtons.length - 1;
                const innerRadius = checked ? 24 : pressed ? 4 : 8;
                const tl = isFirst ? 24 : innerRadius;
                const bl = isFirst ? 24 : innerRadius;
                const tr = isLast ? 24 : innerRadius;
                const br = isLast ? 24 : innerRadius;

                return (
                  <div
                    key={btn.label}
                    className="flex-1 min-w-0"
                    onPointerDown={() => setConnectedPressedIdx(i)}
                    onPointerUp={() => setConnectedPressedIdx(null)}
                    onPointerCancel={() => setConnectedPressedIdx(null)}
                    onPointerLeave={() => setConnectedPressedIdx(null)}
                  >
                    <AospRippleSurface
                      role="button"
                      tabIndex={0}
                      ariaLabel={btn.label}
                      ariaPressed={checked}
                      onClick={() => toggleConnected(i)}
                      mode={config.mode}
                      color={checked ? filledWave : waveColor}
                      sparkleColor={sparkleColor}
                      sparkleStrength={config.sparkleStrength}
                      distortionStrength={config.distortionStrength}
                      systemUiShape={config.systemUiShape}
                      speedMultiplier={config.speedMultiplier}
                      densityScale={config.densityScale}
                      style={{
                        borderTopLeftRadius: `${tl}px`,
                        borderTopRightRadius: `${tr}px`,
                        borderBottomRightRadius: `${br}px`,
                        borderBottomLeftRadius: `${bl}px`,
                        backgroundColor: checked ? theme.primary : undefined,
                        color: checked ? theme.onPrimary : undefined,
                      }}
                      className={`flex h-11 w-full items-center justify-center px-2 text-xs font-medium transition-[border-radius,background-color] duration-200 ease-[cubic-bezier(0.2,0,0,1)] ${
                        checked
                          ? ''
                          : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <span className="flex h-11 items-center justify-center gap-1.5 whitespace-nowrap">
                        <Icon className="h-4 w-4 shrink-0" />
                        <span className="hidden sm:inline truncate">{btn.label}</span>
                      </span>
                    </AospRippleSurface>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 4. FloatingToolbarLayout + FloatingActionButtonMenu */}
        <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs flex flex-col justify-between gap-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              FloatingToolbarLayout 与 FloatingActionButtonMenu
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              对照 <code className="font-mono">floatingtoolbar/res/values/tokens.xml</code>（64dp 胶囊 · 8dp 内边距 · Standard/Vibrant）与{' '}
              <code className="font-mono">FabMenuBaselineTokens.kt</code>（56dp FAB 16dp→28dp 形变 + 4dp 间距菜单项）。
            </p>
          </div>

          <div className="space-y-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              {/* Standard FloatingToolbar */}
              <div className="inline-flex h-16 items-center gap-1 rounded-full bg-white dark:bg-slate-800 px-2 shadow-md border border-slate-200/80 dark:border-slate-700">
                {[
                  { id: 'bold', icon: Bold, label: '加粗' },
                  { id: 'italic', icon: Italic, label: '斜体' },
                  { id: 'share', icon: Share2, label: '分享' },
                ].map((item) => {
                  const Icon = item.icon;
                  const active = toolbarTool === item.id;
                  return (
                    <AospRippleSurface
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      ariaLabel={item.label}
                      ariaPressed={active}
                      onClick={() => setToolbarTool(item.id)}
                      mode={config.mode}
                      color={active ? filledWave : waveColor}
                      sparkleColor={sparkleColor}
                      sparkleStrength={config.sparkleStrength}
                      distortionStrength={config.distortionStrength}
                      systemUiShape={config.systemUiShape}
                      speedMultiplier={config.speedMultiplier}
                      densityScale={config.densityScale}
                      style={{
                        borderRadius: '999px',
                        backgroundColor: active ? theme.primary : undefined,
                        color: active ? theme.onPrimary : undefined,
                      }}
                      className={`flex h-12 w-12 items-center justify-center rounded-full transition-colors ${
                        active
                          ? ''
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                      }`}
                    >
                      <div className="flex h-12 w-12 items-center justify-center">
                        <Icon className="h-5 w-5" />
                      </div>
                    </AospRippleSurface>
                  );
                })}
              </div>

              {/* Vibrant FloatingToolbar (M3 PrimaryContainer) */}
              <div className="inline-flex items-center gap-2">
                <div
                  className="inline-flex h-16 items-center gap-1 rounded-full px-2 shadow-md"
                  style={{
                    backgroundColor: theme.primaryContainer,
                    color: theme.onPrimaryContainer,
                  }}
                >
                  {[
                    { id: 'edit', icon: Edit3, label: '编辑' },
                    { id: 'copy', icon: Copy, label: '复制' },
                  ].map((item) => {
                    const Icon = item.icon;
                    return (
                      <AospRippleSurface
                        key={item.id}
                        role="button"
                        tabIndex={0}
                        ariaLabel={item.label}
                        mode={config.mode}
                        color={waveColor}
                        sparkleColor={sparkleColor}
                        sparkleStrength={config.sparkleStrength}
                        distortionStrength={config.distortionStrength}
                        systemUiShape={config.systemUiShape}
                        speedMultiplier={config.speedMultiplier}
                        densityScale={config.densityScale}
                        style={{
                          borderRadius: '999px',
                          color: theme.onPrimaryContainer,
                        }}
                        className="flex h-12 w-12 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10"
                      >
                        <div className="flex h-12 w-12 items-center justify-center">
                          <Icon className="h-5 w-5" />
                        </div>
                      </AospRippleSurface>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400">
              <span>Standard &amp; Vibrant FloatingToolbar (height=64dp)</span>
              <span>Tool: {toolbarTool}</span>
            </div>
          </div>

          {/* FloatingActionButtonMenu */}
          <div className="flex flex-col sm:flex-row items-end justify-between gap-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 p-4 min-h-[150px]">
            <div className="text-xs text-slate-500 dark:text-slate-400 self-start">
              <div className="font-medium text-slate-800 dark:text-slate-200">
                FAB Menu 状态机
              </div>
              <div className="mt-1 font-mono text-[11px]">{fabMenuAction}</div>
            </div>

            <div className="flex flex-col items-end gap-2">
              {fabMenuOpen && (
                <div className="flex flex-col items-end gap-1">
                  {fabMenuItems.map((item, idx) => {
                    const Icon = item.icon;
                    return (
                      <AospRippleSurface
                        key={item.label}
                        role="button"
                        tabIndex={0}
                        onClick={() => {
                          setFabMenuAction(`已选择: ${item.label}`);
                          setFabMenuOpen(false);
                        }}
                        mode={config.mode}
                        color={waveColor}
                        sparkleColor={sparkleColor}
                        sparkleStrength={config.sparkleStrength}
                        distortionStrength={config.distortionStrength}
                        systemUiShape={config.systemUiShape}
                        speedMultiplier={config.speedMultiplier}
                        densityScale={config.densityScale}
                        style={{
                          borderRadius: '28px',
                          backgroundColor: theme.secondaryContainer,
                          color: theme.onSecondaryContainer,
                          transitionDelay: `${(fabMenuItems.length - 1 - idx) * 28}ms`,
                        }}
                        className="h-14 rounded-full px-6 shadow-sm transition-all duration-200 ease-[cubic-bezier(0.2,0,0,1)]"
                      >
                        <div className="flex h-14 items-center gap-2 text-xs font-medium whitespace-nowrap">
                          <Icon className="h-5 w-5 shrink-0" />
                          <span>{item.label}</span>
                        </div>
                      </AospRippleSurface>
                    );
                  })}
                </div>
              )}

              <AospRippleSurface
                role="button"
                tabIndex={0}
                ariaLabel={fabMenuOpen ? '关闭 FAB 菜单' : '打开 FAB 菜单'}
                ariaPressed={fabMenuOpen}
                onClick={() => setFabMenuOpen((o) => !o)}
                mode={config.mode}
                color={filledWave}
                sparkleColor={sparkleColor}
                sparkleStrength={config.sparkleStrength}
                distortionStrength={config.distortionStrength}
                systemUiShape={config.systemUiShape}
                speedMultiplier={config.speedMultiplier}
                densityScale={config.densityScale}
                style={{
                  borderRadius: fabMenuOpen ? '28px' : '16px',
                  backgroundColor: theme.primary,
                  color: theme.onPrimary,
                }}
                className="flex h-14 w-14 items-center justify-center shadow-md transition-[border-radius,background-color] duration-200 ease-[cubic-bezier(0.2,0,0,1)]"
              >
                <div className="flex h-14 w-14 items-center justify-center">
                  <Plus
                    className={`h-6 w-6 transition-transform duration-200 ease-[cubic-bezier(0.2,0,0,1)] ${
                      fabMenuOpen ? 'rotate-45' : 'rotate-0'
                    }`}
                  />
                </div>
              </AospRippleSurface>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
