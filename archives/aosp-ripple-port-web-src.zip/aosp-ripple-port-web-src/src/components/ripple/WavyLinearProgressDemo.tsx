"use client";
/**
 * Wavy LinearProgressIndicator（确定态 + 不定态 disjoint）—— 按官方 m3.material.io 展示规格对齐重写
 *
 * 本轮按用户指令「一一对照官方展示网站规格」实现。官方规格的参考实现为 Android 官方
 * Compose M3 Expressive 源码（本地 sources/androidx-m3-android，2025 Copyright AOSP），
 * 其令牌与 MDC-Android 1.14.0 一致（thickness 4dp / amplitude 3dp / λ 40·20dp / gap 4dp /
 * stop 4dp / 容器高 10dp），逐项核对无冲突。
 *
 * 【为什么改掉旧版】旧版照抄 MDC-Android LinearDrawingDelegate（恒定满幅 + 静止相位），
 * 导致「波浪到达停止指示点时原点不重合」。官方机制（WavyProgressIndicator.kt L490-497
 * indicatorAmplitude + LinearWavyProgressModifiers.kt）为：
 *  1. 振幅是 progress 的函数：progress ≤ 0.10 或 ≥ 0.95 → 振幅 0（正规直线），否则 1；
 *  2. 振幅 0↔1 以 500ms tween 过渡（Increasing=EasingStandard (0.2,0,0,1)；
 *     Decreasing=EasingEmphasizedAccelerate (0.3,0,0.8,0.15)，MotionTokens DurationLong2=500）；
 *  3. 波形按最大振幅绘制后整体 Y 缩放（向中心线塌缩），因此头部到达停止点前已收敛为
 *     中心线上的平线，与停止指示点精准重合；
 *  4. 停止指示点在头部逼近时逐步收缩至消失（drawStopIndicator L729-777）。
 *  ※ 官方源码中停止指示器为圆点（线性类型专属），无箭头造型；m3.material.io 解剖图
 *    仅称 "end stop indicator"。
 *
 * 【波形几何】（updateFullPaths L887-981 逐行转译）
 *  - 二次贝塞尔：锚点每隔 λ/2 落在中心线，控制点位于两锚点中点、纵距 ±(容器高 − 描边宽)
 *    = ±6（二次曲线中点峰值 = 控制点的一半 → 波峰恰为 ±3dp）；
 *  - 全路径延伸至 宽度 + 2λ（供相位滚动取段），再 translate(0, 容器高/2) 到中心线；
 *  - 取段：PathMeasure 弧长 = (tail + waveShift)·(总弧长/包围盒宽) —— 官方用线性比例
 *    progressPathScale 修正弧长/横坐标差异（L970-971），本实现同构复刻；
 *  - 绘制变换：translate(-waveShift) + scale(y=amplitude) + translate(y=(1-amplitude)·高/2)
 *    （L1088-1101）→ 波形塌向中心线而非原点；
 *  - 相位：waveOffset 以 LinearEasing 无限循环，时长 = λ/waveSpeed·1000（默认 waveSpeed=λ
 *    → 每秒滚动 1 个波长，L295-327）；振幅为 0 时官方以 0 相位绘制（L514）。
 *
 * 【描边/端帽】StrokeCap.Round（WavyProgressIndicatorDefaults L408-417）；线段两端由
 *  ROUND 帽补足，故尾部从 capWidth=2 起（updateDrawPaths L1067-1070 coerce）。
 *
 * 【间隙】trackSpacing = min(head−capWidth, gap 4dp) + 2·capWidth（L1054-1062 与
 *  L1108-1113 的 adaptiveTrackSpacing）——比 MDC 的裸 gap 多让出两个帽宽。
 *
 * 【停止点】min(描边宽, 4dp)，中心 x = W − stop − (stop < 描边宽 ? 描边宽/4 : 0)，
 *  progressX = progress·W + capWidth，重叠时 size = max(0, size − 重叠)（L737-752）。
 *
 * 【不定态 disjoint】（ProgressIndicator.kt L1049-1063 官方常量）
 *  - 周期 1750ms；head1 [0,1000] / tail1 [250,1250] / head2 [650,1500] / tail2 [900,1750]；
 *  - 四段共用 EasingEmphasizedAccelerateCubicBezier (0.3,0,0.8,0.15)
 *    （LinearIndeterminateProgressEasing L1063）；
 *  - 轨道三段式（右段 / 中段 / 左段），段间 adaptiveTrackSpacing；不定态无停止点；
 *  - 不定态振幅恒 1（WavyProgressIndicator.kt L177 默认值）。
 *
 * 【与 MDC-Android 1.14.0 的差异（诚实声明）】
 *  - MDC 版波形为三次贝塞尔 cos 近似（WAVE_SMOOTHNESS=0.48）且相位默认 0（waveSpeed 属性
 *    未设即静止）、振幅恒满幅；官方展示规格（Compose）为二次贝塞尔 + 相位持续滚动 +
 *    振幅随进度收敛。本版按用户指令对齐官方展示规格。
 *  - prefers-reduced-motion：不定态定格 playtime=0 帧、确定态振幅瞬时到位、相位冻结。
 *
 * 【进度/模式控件】调节 progress 的滑块统一使用 AospExpressiveSlider（带手柄），
 *  绝不使用原生 <input type="range"> 默认圆点（用户硬性指令，2026-11-21）。
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { hexToRgbaWave, type M3ThemeTokens } from '@/aosp/dynamicColor';
import type { LabConfigState } from './InteractiveLab';
import { AospExpressiveSlider } from './AospExpressiveSlider';
import { AospExpressiveSwitch } from './AospExpressiveSwitch';

/* ---------- 官方令牌（LinearProgressIndicatorTokens.kt / ProgressIndicator.kt / MotionTokens.kt） ---------- */
const WAVE_HEIGHT = 10; // WaveHeight 10dp（容器高）
const STROKE = 4; // ActiveThickness = TrackThickness 4dp
const CY = WAVE_HEIGHT / 2; // 中心线 y=5
const GAP = 4; // TrackActiveSpace 4dp
const STOP_SIZE = 4; // StopSize 4dp
const LAMBDA_DET = 40; // ActiveWaveWavelength 40dp
const LAMBDA_IND = 20; // IndeterminateActiveWaveWavelength 20dp
const AMPLITUDE_MS = 500; // MotionTokens.DurationLong2 = 500（振幅 tween）
const WAVE_SPEED_MS_PER_LAMBDA = 1000; // waveSpeed 默认 = λ → 每 1000ms 滚动 1 个波长

// 官方 indicatorAmplitude（WavyProgressIndicator.kt L490-497）：≤10% / ≥95% → 0
function amplitudeTarget(p: number): number {
  return p <= 0.1 || p >= 0.95 ? 0 : 1;
}

/* ---------- 缓动（MotionTokens.kt L40-62 原值） ---------- */
function makeCubicBezierSolver(x1: number, y1: number, x2: number, y2: number) {
  const cx = 3 * x1;
  const bx = 3 * (x2 - x1) - cx;
  const ax = 1 - cx - bx;
  const cy = 3 * y1;
  const by = 3 * (y2 - y1) - cy;
  const ay = 1 - cy - by;
  const sampleX = (t: number) => ((ax * t + bx) * t + cx) * t;
  const sampleY = (t: number) => ((ay * t + by) * t + cy) * t;
  const sampleDX = (t: number) => (3 * ax * t + 2 * bx) * t + cx;
  return (x: number): number => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const err = sampleX(t) - x;
      if (Math.abs(err) < 1e-6) return sampleY(t);
      const d = sampleDX(t);
      if (Math.abs(d) < 1e-6) break;
      t -= err / d;
    }
    let lo = 0;
    let hi = 1;
    t = x;
    for (let i = 0; i < 24; i++) {
      const v = sampleX(t);
      if (Math.abs(v - x) < 1e-6) break;
      if (v < x) lo = t;
      else hi = t;
      t = (lo + hi) / 2;
    }
    return sampleY(t);
  };
}

const EASE_STANDARD = makeCubicBezierSolver(0.2, 0, 0, 1); // EasingStandardCubicBezier
const EASE_EMPH_ACCEL = makeCubicBezierSolver(0.3, 0, 0.8, 0.15); // EasingEmphasizedAccelerateCubicBezier

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

/* ---------- 波形查找表（Compose LinearProgressDrawingCache.updateFullPaths 同构） ---------- */
interface WaveLut {
  xs: number[];
  ys: number[];
  cum: number[]; // 累计弧长
  total: number; // 总弧长
  scale: number; // progressPathScale = 总弧长 / 包围盒宽（官方 L970-971 线性修正）
}

/**
 * 全幅波形路径采样（控制点纵距 ±(容器高−描边宽)=±6，二次曲线峰值恰为 ±3dp）。
 * 路径延伸至 宽度 + 2λ（官方 L951 widthWithExtraPhase），锚点 y=CY（translate 后坐标）。
 */
function buildWaveLut(width: number, lambda: number): WaveLut {
  const half = lambda / 2;
  const controlY = WAVE_HEIGHT - STROKE; // 6
  const widthWithExtra = width + lambda * 2;
  const xs: number[] = [];
  const ys: number[] = [];
  const cum: number[] = [0];
  let px = 0;
  let py = CY;
  xs.push(px);
  ys.push(py);
  let anchorX = half;
  let controlX = half / 2;
  let sign = 1; // 官方首段控制点在 +y（画布向下）→ 波先下沉
  const STEPS = 16;
  while (anchorX <= widthWithExtra + 1e-6) {
    const cx = controlX;
    const cy = CY + sign * controlY;
    for (let s = 1; s <= STEPS; s++) {
      const t = s / STEPS;
      const mt = 1 - t;
      const x = mt * mt * px + 2 * mt * t * cx + t * t * anchorX;
      const y = mt * mt * py + 2 * mt * t * cy + t * t * CY;
      const dx = x - xs[xs.length - 1];
      const dy = y - ys[ys.length - 1];
      cum.push(cum[cum.length - 1] + Math.hypot(dx, dy));
      xs.push(x);
      ys.push(y);
    }
    px = anchorX;
    py = CY;
    anchorX += half;
    controlX += half;
    sign *= -1;
  }
  const total = cum[cum.length - 1];
  const boundsW = xs[xs.length - 1];
  return { xs, ys, cum, total, scale: total / boundsW };
}

/** 弧长 → 点（二分 + 线性插值，PathMeasure.getPosTan 同语义） */
function lutPointAt(lut: WaveLut, dist: number): [number, number] {
  const d = clamp(dist, 0, lut.total);
  let lo = 0;
  let hi = lut.cum.length - 1;
  while (lo < hi - 1) {
    const mid = (lo + hi) >> 1;
    if (lut.cum[mid] <= d) lo = mid;
    else hi = mid;
  }
  const span = lut.cum[hi] - lut.cum[lo];
  const k = span > 0 ? (d - lut.cum[lo]) / span : 0;
  return [lut.xs[lo] + (lut.xs[hi] - lut.xs[lo]) * k, lut.ys[lo] + (lut.ys[hi] - lut.ys[lo]) * k];
}

/**
 * 波形取段（updateDrawPaths L1073-1101 同构）：
 *  d = [tail, head] 在 (+waveShift 后) 波形上的弧长段；translate(-shift)；
 *  y' = y·amplitude + (1−amplitude)·CY（塌向中心线）。返回 SVG path d（L 段折线）。
 */
function waveSegmentD(
  lut: WaveLut,
  tailPx: number,
  headPx: number,
  shift: number,
  amplitude: number,
): string | null {
  if (headPx - tailPx <= 0) return null;
  const d1 = (tailPx + shift) * lut.scale;
  const d2 = (headPx + shift) * lut.scale;
  // 采样步长 ≈ 每像素 1 点（上限 512 点防退化）
  const count = Math.max(2, Math.min(512, Math.ceil(d2 - d1)));
  const cmds: string[] = [];
  for (let i = 0; i <= count; i++) {
    const [x, y] = lutPointAt(lut, d1 + ((d2 - d1) * i) / count);
    const tx = x - shift; // 官方 L1091：shift > 0 时回移
    const ty = y * amplitude + (1 - amplitude) * CY; // 官方 L1092/L1097-1099
    cmds.push(`${i === 0 ? 'M' : 'L'} ${tx.toFixed(2)} ${ty.toFixed(2)}`);
  }
  return cmds.join(' ');
}

/* ===================== 确定态 ===================== */

interface WavyLinearProgressProps {
  theme: M3ThemeTokens;
  /** 0..1 确定态进度 */
  progress: number;
  widthPx: number;
}

function WavyLinearProgress({ theme, progress, widthPx }: WavyLinearProgressProps) {
  const W = Math.max(LAMBDA_DET, widthPx);
  const capW = STROKE / 2; // currentStrokeCapWidth = max(stroke, trackStroke)/2 = 2
  const lut = useMemo(() => buildWaveLut(W, LAMBDA_DET), [W]);

  const pRef = useRef(progress);
  pRef.current = progress;
  const ampRef = useRef(0);
  const tweenRef = useRef<{ from: number; to: number; start: number; easing: (t: number) => number } | null>(null);
  const offsetRef = useRef(0);
  const lastTsRef = useRef(0);
  const reducedMotionRef = useRef(false);
  const firstRunRef = useRef(true);

  const waveRef = useRef<SVGPathElement>(null);
  const trackRef = useRef<SVGPathElement>(null);
  const stopRef = useRef<SVGCircleElement>(null);

  // 振幅目标（官方 indicatorAmplitude lambda）。
  // 首帧直接落在目标值（官方 Animatable(initialValue = targetAmplitude) 无入场动画），
  // 之后的变更才以 500ms tween 过渡（方向决定缓动）。
  const p = clamp(progress, 0, 1);
  const target = amplitudeTarget(p);
  useEffect(() => {
    if (firstRunRef.current) {
      firstRunRef.current = false;
      ampRef.current = target;
      return;
    }
    tweenRef.current = {
      from: ampRef.current,
      to: target,
      start: performance.now(),
      easing: target > ampRef.current ? EASE_STANDARD : EASE_EMPH_ACCEL,
    };
  }, [target]);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reducedMotionRef.current = mq.matches;
    const onChange = (e: MediaQueryListEvent) => {
      reducedMotionRef.current = e.matches;
    };
    mq.addEventListener('change', onChange);

    const waveColor = theme.primary;
    const trackColor = theme.secondaryContainer;
    let raf = 0;

    const render = (dtMs: number) => {
      const pNow = clamp(pRef.current, 0, 1);
      // 振幅 tween（500ms，方向缓动）
      const tween = tweenRef.current;
      if (tween) {
        const k = reducedMotionRef.current
          ? 1
          : clamp((performance.now() - tween.start) / AMPLITUDE_MS, 0, 1);
        ampRef.current = tween.from + (tween.to - tween.from) * tween.easing(k);
        if (k >= 1) tweenRef.current = null;
      }
      const amp = ampRef.current;
      // 相位：每秒滚动 1 个波长（LinearEasing 无限循环，updateOffsetAnimation L295-327）
      if (!reducedMotionRef.current) {
        offsetRef.current = (offsetRef.current + dtMs / WAVE_SPEED_MS_PER_LAMBDA) % 1;
      }
      const shift = amp > 0 ? offsetRef.current * LAMBDA_DET : 0;

      // 活动指示器：[tail, head] 波形段（updateDrawPaths L1044-1101）
      const barHeadRaw = pNow * W;
      const barTailRaw = 0; // 确定态 start 恒 0
      const adjHead = clamp(barHeadRaw, capW, W - capW);
      const adjTail = clamp(barTailRaw, capW, W - capW);
      const d = waveSegmentD(lut, adjTail, adjHead, shift, amp);
      const wave = waveRef.current;
      if (wave) {
        if (d === null) {
          wave.setAttribute('display', 'none');
        } else {
          wave.removeAttribute('display');
          wave.setAttribute('d', d);
          wave.setAttribute('stroke', waveColor);
        }
      }

      // 轨道：[head + adaptiveSpacing → W − capWidth]（L1035-1037 / L1108-1119）
      const activeVisible = barHeadRaw >= capW;
      const adjustedGap = barHeadRaw < capW ? 0 : Math.min(barHeadRaw - capW, GAP);
      const spacing = activeVisible ? adjustedGap + capW * 2 : adjustedGap;
      const trackStart = Math.max(capW, adjHead + spacing);
      const trackEnd = W - capW;
      const track = trackRef.current;
      if (track) {
        if (trackEnd > trackStart) {
          track.removeAttribute('display');
          track.setAttribute('d', `M ${trackEnd.toFixed(2)} ${CY} L ${trackStart.toFixed(2)} ${CY}`);
          track.setAttribute('stroke', trackColor);
        } else {
          track.setAttribute('display', 'none');
        }
      }

      // 停止指示点：头部逼近时收缩（drawStopIndicator L729-777）
      const stop = stopRef.current;
      if (stop) {
        let stopSize = Math.min(STROKE, STOP_SIZE);
        const xOffset = stopSize === STROKE ? 0 : STROKE / 4;
        let indicatorX = W - stopSize - xOffset;
        const progressX = barHeadRaw + capW;
        if (indicatorX <= progressX) {
          stopSize = Math.max(0, stopSize - (progressX - indicatorX));
          indicatorX = progressX;
        }
        if (stopSize > 0) {
          stop.removeAttribute('display');
          stop.setAttribute('cx', (indicatorX + stopSize / 2).toFixed(2));
          stop.setAttribute('cy', CY.toFixed(2));
          stop.setAttribute('r', (stopSize / 2).toFixed(2));
          stop.setAttribute('fill', waveColor);
        } else {
          stop.setAttribute('display', 'none');
        }
      }
    };

    const loop = (now: number) => {
      const dt = lastTsRef.current ? Math.min(100, now - lastTsRef.current) : 16;
      lastTsRef.current = now;
      render(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const onVisibility = () => {
      lastTsRef.current = 0;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(loop);
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVisibility);
      mq.removeEventListener('change', onChange);
    };
  }, [theme.primary, theme.secondaryContainer, W, lut, capW]);

  return (
    <svg
      width={W}
      height={WAVE_HEIGHT}
      viewBox={`0 0 ${W} ${WAVE_HEIGHT}`}
      role="progressbar"
      aria-valuenow={Math.round(p * 100)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label="Wavy 线性进度指示器（确定态）"
    >
      <path ref={trackRef} fill="none" strokeWidth={STROKE} strokeLinecap="round" d="" />
      <path ref={waveRef} fill="none" strokeWidth={STROKE} strokeLinecap="round" />
      <circle ref={stopRef} />
    </svg>
  );
}

/* ===================== 不定态（disjoint，官方 1750ms 四段 keyframes） ===================== */

const IND_PCM = 'wavy-linear-ind';
const CYCLE_MS = 1750; // LinearAnimationDuration（ProgressIndicator.kt L1049）
const HEAD1 = { delay: 0, dur: 1000 }; // FirstLineHead
const TAIL1 = { delay: 250, dur: 1000 }; // FirstLineTail
const HEAD2 = { delay: 650, dur: 850 }; // SecondLineHead
const TAIL2 = { delay: 900, dur: 850 }; // SecondLineTail

interface IndeterminateWavyProps {
  theme: M3ThemeTokens;
  widthPx: number;
}

/**
 * IndeterminateLinearWavyProgressNode 逐帧转译：
 *  - 四段 keyframes 共用 EasingEmphasizedAccelerateCubicBezier（LinearIndeterminateProgressEasing）；
 *  - 段 = [tail, head]（head 先行、tail 追赶）；轨道三段式 + adaptiveTrackSpacing；
 *  - adjustedGap/activeVisible 取自第一段（Compose 循环实现，L1047-1064，忠实复刻）；
 *  - 振幅恒 1；相位持续滚动（1λ/s）；无停止点。
 */
function IndeterminateWavy({ theme, widthPx }: IndeterminateWavyProps) {
  const W = Math.max(LAMBDA_IND, widthPx);
  const capW = STROKE / 2;
  const lut = useMemo(() => buildWaveLut(W, LAMBDA_IND), [W]);

  const trackRef = useRef<SVGPathElement>(null);
  const wave1Ref = useRef<SVGPathElement>(null);
  const wave2Ref = useRef<SVGPathElement>(null);
  const lastTsRef = useRef(0);
  const offsetRef = useRef(0);
  const reducedMotionRef = useRef(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reducedMotionRef.current = mq.matches;
    const onChange = (e: MediaQueryListEvent) => {
      reducedMotionRef.current = e.matches;
    };
    mq.addEventListener('change', onChange);

    const waveColor = theme.primary;
    const trackColor = theme.secondaryContainer;
    let raf = 0;

    const render = (playtime: number, dtMs: number) => {
      // 相位滚动（每秒 1λ）
      if (!reducedMotionRef.current) {
        offsetRef.current = (offsetRef.current + dtMs / WAVE_SPEED_MS_PER_LAMBDA) % 1;
      }
      const shift = offsetRef.current * LAMBDA_IND;
      const t = playtime;
      const head1 = EASE_EMPH_ACCEL(clamp((t - HEAD1.delay) / HEAD1.dur, 0, 1));
      const tail1 = EASE_EMPH_ACCEL(clamp((t - TAIL1.delay) / TAIL1.dur, 0, 1));
      const head2 = EASE_EMPH_ACCEL(clamp((t - HEAD2.delay) / HEAD2.dur, 0, 1));
      const tail2 = EASE_EMPH_ACCEL(clamp((t - TAIL2.delay) / TAIL2.dur, 0, 1));

      // 轨道（L1035-1133 右→左三段式；adjustedGap/activeVisible 取自第一段）
      const amp = 1;
      const segs: Array<[number, number]> = [
        [tail1 * W, head1 * W],
        [tail2 * W, head2 * W],
      ];
      const barHead0 = head1 * W;
      const adjustedGap = barHead0 < capW ? 0 : Math.min(barHead0 - capW, GAP);
      const activeVisible = barHead0 >= capW;
      const spacing = activeVisible ? adjustedGap + capW * 2 : adjustedGap;

      let nextEndTrackOffset = W - capW;
      const trackCmds: string[] = [`M ${nextEndTrackOffset.toFixed(2)} ${CY}`];
      const waveEls = [wave1Ref.current, wave2Ref.current];
      for (let i = 0; i < 2; i++) {
        const [barTail, barHead] = segs[i];
        const adjHead = clamp(barHead, capW, W - capW);
        const adjTail = clamp(barTail, capW, W - capW);
        const d = waveSegmentD(lut, adjTail, adjHead, shift, amp);
        const el = waveEls[i];
        if (el) {
          if (d === null) {
            el.setAttribute('display', 'none');
          } else {
            el.removeAttribute('display');
            el.setAttribute('d', d);
            el.setAttribute('stroke', waveColor);
          }
        }
        if (nextEndTrackOffset > adjHead + spacing) {
          trackCmds.push(`L ${Math.max(capW, adjHead + spacing).toFixed(2)} ${CY}`);
        }
        if (barHead > barTail) {
          nextEndTrackOffset = Math.max(capW, adjTail - spacing);
          trackCmds.push(`M ${nextEndTrackOffset.toFixed(2)} ${CY}`);
        }
      }
      if (nextEndTrackOffset > capW) {
        trackCmds.push(`L ${capW.toFixed(2)} ${CY}`);
      }
      const track = trackRef.current;
      if (track) {
        track.setAttribute('d', trackCmds.join(' '));
        track.setAttribute('stroke', trackColor);
      }
    };

    const loop = (now: number) => {
      const dt = lastTsRef.current ? Math.min(100, now - lastTsRef.current) : 16;
      lastTsRef.current = now;
      render(reducedMotionRef.current ? 0 : now % CYCLE_MS, dt);
      if (!reducedMotionRef.current) raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const onVisibility = () => {
      lastTsRef.current = 0;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(loop);
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVisibility);
      mq.removeEventListener('change', onChange);
    };
  }, [theme.primary, theme.secondaryContainer, W, lut, capW]);

  return (
    <svg
      width={W}
      height={WAVE_HEIGHT}
      viewBox={`0 0 ${W} ${WAVE_HEIGHT}`}
      role="progressbar"
      aria-label="Wavy 线性进度指示器（不定态 disjoint）"
    >
      <path ref={trackRef} fill="none" strokeWidth={STROKE} strokeLinecap="round" />
      <path ref={wave1Ref} fill="none" strokeWidth={STROKE} strokeLinecap="round" />
      <path ref={wave2Ref} fill="none" strokeWidth={STROKE} strokeLinecap="round" />
    </svg>
  );
}

/* ===================== 演示容器 ===================== */

interface WavyProgressDemoProps {
  theme: M3ThemeTokens;
  config: LabConfigState;
}

export function WavyProgressDemo({ theme, config }: WavyProgressDemoProps) {
  const [indeterminate, setIndeterminate] = useState(false);
  const [progress, setProgress] = useState(0.55);
  const containerRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(360);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => setWidth(Math.max(LAMBDA_DET, Math.floor(el.getBoundingClientRect().width)));
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const waveColor = hexToRgbaWave(theme.primary, 1);
  const ampTarget = amplitudeTarget(clamp(progress, 0, 1));

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Wavy LinearProgressIndicator（确定态 + 不定态波形进度条）
        </h3>
        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 break-all">
          m3.material.io 展示规格 · Compose M3 Expressive {'{'}
          WavyProgressIndicator.kt · LinearWavyProgressModifiers.kt · ProgressIndicator.kt{'}'}
          · MDC-Android 1.14.0 tokens 对照
        </span>
      </div>

      <div className="space-y-4 rounded-lg p-5" style={{ backgroundColor: theme.surfaceContainerLow }}>
        <div ref={containerRef} className="w-full">
          {indeterminate ? (
            <IndeterminateWavy theme={theme} widthPx={width} />
          ) : (
            <WavyLinearProgress theme={theme} progress={progress} widthPx={width} />
          )}
        </div>
        {/* 设置滑块：带手柄样式（BaseSlider 4dp→2dp），不用原生 range 圆点；不定态无 progress 语义 → 隐藏 */}
        {!indeterminate && (
          <AospExpressiveSlider
            label="调节确定态进度 (progress)"
            value={progress}
            min={0}
            max={1}
            step={0.01}
            size="xs"
            compact
            unit=""
            formatValue={(v) => `progress = ${v.toFixed(2)}`}
            accentHex={theme.primary}
            theme={theme}
            onChange={setProgress}
          />
        )}
        <div className="flex items-center justify-between gap-4 pt-1">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {indeterminate
              ? 'indeterminate：disjoint 双段（官方 1750ms 四段 keyframes · EasingEmphasizedAccelerate）'
              : `determinate：振幅 ${ampTarget === 1 ? '满幅（0.10 < progress < 0.95）' : '收敛为 0（≤0.10 / ≥0.95，500ms tween）'} · 相位 1 波长/秒滚动`}
          </div>
          <AospExpressiveSwitch
            checked={indeterminate}
            onChange={setIndeterminate}
            ariaLabel="切换确定态 / 不定态"
            mode={config.mode}
            waveColor={waveColor}
            sparkleColor={{ r: 1, g: 1, b: 1, a: config.sparkleAlpha }}
            sparkleStrength={config.sparkleStrength}
            distortionStrength={config.distortionStrength}
            systemUiShape={config.systemUiShape}
            speedMultiplier={config.speedMultiplier}
            densityScale={config.densityScale}
            accentHex={theme.primary}
          />
        </div>
      </div>

      <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        <p>
          按官方展示规格实现（WavyProgressIndicatorDefaults.indicatorAmplitude）：progress ≤ 0.10 或
          ≥ 0.95 时振幅收敛为 0（500ms tween：增大 EasingStandard (0.2,0,0,1) / 减小
          EasingEmphasizedAccelerate (0.3,0,0.8,0.15)），波形以二次贝塞尔（锚点每 λ/2、控制点 ±6，
          峰值 ±3dp，容器高 10dp）绘制后向中心线塌缩——因此头部抵达停止指示点时已与原点精准重合，
          停止点并随头部逼近逐步收缩至消失；波形相位默认以 1 波长/秒持续滚动（waveSpeed=λ）。
        </p>
        <p>
          <span className="font-medium text-slate-600 dark:text-slate-300">诚实缺口：</span>
          官方源码停止指示器为圆点（无箭头造型，m3.material.io 解剖仅称 end stop indicator）；
          弧长取段沿用官方线性比例修正（progressPathScale），非逐点精确解；MDC-Android 1.14.0
          的差异实现（三次贝塞尔 cos 波、静止相位、恒满幅）已按用户指令让位于官方展示规格；
          prefers-reduced-motion 定格并瞬时收敛。
        </p>
      </div>
    </div>
  );
}
