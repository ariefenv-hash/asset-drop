"use client";
/**
 * Material 3 Expressive LoadingIndicator —— Web 忠实转译（MDC-Android 1.14.0）
 *
 * 全部取值可回溯到本地真实源码（sources/mdc-android/lib/java/com/google/android/material/）：
 *  - 几何：indicatorSize 34dp / container 48×48dp（loadingindicator/res/values/styles.xml
 *    Widget.Material3.LoadingIndicator + res/values/tokens.xml m3_comp_loading_indicator_container_*）
 *  - 颜色：默认色 = colorPrimary（tokens.xml m3_comp_loading_indicator_active_indicator_color）；
 *    Contained 变体 = colorOnPrimaryContainer on colorPrimaryContainer（同文件 Contained 组宏）
 *  - 形变序列：SOFT_BURST → COOKIE_9 → PENTAGON → PILL → SUNNY → COOKIE_4 → OVAL，全部经
 *    normalize(shape, radial=true, RectF(-1,-1,1,1))（DrawingDelegate L134-143 + MaterialShapes.java）
 *    —— 形状构造与 normalize 语义逐行核对，转译实现见 aosp/materialShapes.ts
 *  - 旋转坐标系：adjustCanvas 先 rotate(-90)（0° 朝上），再叠加 indicatorState.rotationDegree
 *    （DrawingDelegate L84-85 / L117）
 *  - 动画（AnimatorDelegate L36-42）：
 *      DURATION_PER_SHAPE = 650ms，线性插值器，无限循环（L105-108）
 *      每次 repeat：morphFactorTarget++ 并以弹簧驱动（L112-115）
 *      弹簧：SpringForce stiffness=200 / dampingRatio=0.6（L41-42），minimumVisibleChange 0.01（L101）
 *      旋转 = (50+90)·(target-1) + 50·(playtime/650) + 90·(morph-(target-1))，mod 360（L123-141）
 *  - 颜色过渡：ArgbEvaluatorCompat —— sRGB→linear(2.2) 插值后换回（animation/ArgbEvaluatorCompat.java），
 *    起止索引 = (target-1)%len 与 (target)%len，fraction = clamp(morph-(target-1),0,1)（L144-154）
 *  - 弹簧求解：复用 aosp/spring.ts（androidx SpringForce F=-k(x-t)-c·v 逐式实现，c=2ζ√k）
 *
 * 【诚实缺口 / Web 适配】
 *  - Canvas → SVG：Android 用 Canvas.drawPath(Path) 硬件加速绘制，本实现将 Morph cubic 序列
 *    映射为 SVG <path d>（数学同源，均为 androidx.graphics.shapes 的三次贝塞尔插值）。
 *  - 系统动画时长缩放为 0 时 Android 绘制静态 ic_mtrl_arrow_circle（Drawable L106-111）；
 *    Web 侧对应 prefers-reduced-motion: reduce —— 绘制同一矢量（resources/res/drawable/
 *    ic_mtrl_arrow_circle.xml pathData 原样），并同样以 indicatorColors[0] 着色。
 *  - 脉冲/暂停按钮为页面演示控制（对应 show()/hide() 的可见性开关语义），非组件本体样式。
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  cubicsToSvgPath,
  getLoadingIndicatorMorphCubics,
} from '@/aosp/materialShapes';
import { stepSpring, type SpringState } from '@/aosp/spring';
import type { M3ThemeTokens } from '@/aosp/dynamicColor';

/** AnimatorDelegate L36：每个形状 650ms，线性 */
const DURATION_PER_SHAPE_MS = 650;
/** AnimatorDelegate L41-42：弹簧参数 */
const SPRING_STIFFNESS = 200;
const SPRING_DAMPING_RATIO = 0.6;
/** AnimatorDelegate L101：minimumVisibleChange 0.01 —— 弹簧判停阈值 */
const SPRING_MIN_VISIBLE_CHANGE = 0.01;
/** AnimatorDelegate L39-40：每形状恒定旋转 50°、弹簧附加旋转 90°（合计 140°/形） */
const CONSTANT_ROTATION_PER_SHAPE = 50;
const EXTRA_ROTATION_PER_SHAPE = 90;

/** styles.xml Widget.Material3.LoadingIndicator：indicatorSize 34dp / 容器 48×48dp */
export const LOADING_INDICATOR_DEFAULT_SIZE_DP = 34;
export const LOADING_INDICATOR_DEFAULT_CONTAINER_DP = 48;

/** 静态降级矢量：resources/res/drawable/ic_mtrl_arrow_circle.xml（24×24 viewport，pathData 原样） */
const STATIC_ARROW_CIRCLE_PATH =
  'M17.65,6.35C16.2,4.9 14.21,4.0 12.0,4.0c-4.42,0.0 -7.99,3.58 -7.99,8.0s3.57,8.0 7.99,' +
  '8.0c3.73,0.0 6.84,-2.55 7.73,-6.0l-2.08,0.0c-0.82,2.33 -3.04,4.0 -5.65,4.0 -3.31,0.0 ' +
  '-6.0,-2.69 -6.0,-6.0s2.69,-6.0 6.0,-6.0c1.66,0.0 3.1,0.69 4.22,1.78L13.0,11.0l7.0,0.0L20.0,4.0l-2.35,2.35z';

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
  const n = parseInt(full.slice(0, 6), 16);
  return [(n >> 16) & 0xff, (n >> 8) & 0xff, n & 0xff];
}

/** ArgbEvaluatorCompat.evaluate 精确公式：sRGB→linear(2.2) 逐通道插值后换回 */
function argbEvaluate(startHex: string, endHex: string, fraction: number): string {
  const [r0, g0, b0] = hexToRgb(startHex);
  const [r1, g1, b1] = hexToRgb(endHex);
  const lin = (v: number) => Math.pow(v / 255, 2.2);
  const r = Math.pow(lin(r0) + fraction * (lin(r1) - lin(r0)), 1 / 2.2) * 255;
  const g = Math.pow(lin(g0) + fraction * (lin(g1) - lin(g0)), 1 / 2.2) * 255;
  const b = Math.pow(lin(b0) + fraction * (lin(b1) - lin(b0)), 1 / 2.2) * 255;
  return `rgb(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)})`;
}

export interface M3LoadingIndicatorProps {
  theme: M3ThemeTokens;
  /** 对应 show()/hide()（LoadingIndicator.java L120/L147）；重启时 resetPropertiesForNewStart */
  running?: boolean;
  /** 指示器尺寸 px（默认 34dp 直传；对应 spec.indicatorSize） */
  indicatorSize?: number;
  /** 容器尺寸 px（默认 48dp 直传；对应 spec.containerWidth/Height） */
  containerSize?: number;
  /** indicatorColors（AnimatorDelegate 支持 int[]，逐形过渡）；默认 [colorPrimary] */
  indicatorColors?: string[];
  /** Contained 变体（styles.xml：容器 colorPrimaryContainer / 指示器 colorOnPrimaryContainer） */
  contained?: boolean;
}

export const M3LoadingIndicator: React.FC<M3LoadingIndicatorProps> = ({
  theme,
  running = true,
  indicatorSize = LOADING_INDICATOR_DEFAULT_SIZE_DP,
  containerSize = LOADING_INDICATOR_DEFAULT_CONTAINER_DP,
  indicatorColors,
  contained = false,
}) => {
  const [reducedMotion, setReducedMotion] = useState(false);

  // prefers-reduced-motion ↔ isSystemAnimatorDisabled()（系统动画缩放为 0）
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReducedMotion(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  const colors = useMemo(() => {
    if (indicatorColors && indicatorColors.length > 0) return indicatorColors;
    if (contained) return [theme.onPrimaryContainer]; // Contained 组宏
    return [theme.primary]; // m3_comp_loading_indicator_active_indicator_color
  }, [indicatorColors, contained, theme]);

  const containerColor = contained ? theme.primaryContainer : 'transparent';

  // 动画状态（对应 AnimatorDelegate 的 animationFraction / morphFactor / morphFactorTarget）
  const fractionRef = useRef(0);
  const springRef = useRef<SpringState>({ value: 0, velocity: 0, target: 1 });
  const frameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  // 每帧直接写 DOM（d / transform / fill），不经 setState —— 每帧重渲是反模式
  const pathRef = useRef<SVGPathElement>(null);
  const groupRef = useRef<SVGGElement>(null);
  const [currentColor, setCurrentColor] = useState(colors[0]);
  const colorRef = useRef(colors[0]);

  const colorsKey = colors.join(',');

  useEffect(() => {
    colorRef.current = colors[0];
    setCurrentColor(colors[0]);
  }, [colorsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (reducedMotion) return;

    // startAnimator → resetPropertiesForNewStart：target=1、morph=0、fraction=0
    const resetForNewStart = () => {
      fractionRef.current = 0;
      springRef.current.value = 0;
      springRef.current.velocity = 0;
      springRef.current.target = 1;
    };
    resetForNewStart();
    lastTimeRef.current = performance.now();

    const scale = indicatorSize / 2; // DrawingDelegate L128：setScale(specs.indicatorSize / 2f)
    const render = (now: number) => {
      const dtMs = Math.min(64, now - lastTimeRef.current);
      lastTimeRef.current = now;

      // 线性推进 animationFraction（0→1 / 650ms，ObjectAnimator setInterpolator(null)）
      let fraction = fractionRef.current + dtMs / DURATION_PER_SHAPE_MS;
      // onAnimationRepeat（L112-115）：每次循环 morphFactorTarget++ 并让弹簧追赶新目标
      while (fraction >= 1) {
        fraction -= 1;
        springRef.current.target += 1;
      }
      fractionRef.current = fraction;

      // 弹簧推进 morphFactor（SpringForce k=200 ζ=0.6，androidx 逐式实现见 spring.ts）
      const spring = springRef.current;
      stepSpring(spring, dtMs / 1000, { stiffness: SPRING_STIFFNESS, dampingRatio: SPRING_DAMPING_RATIO }, SPRING_MIN_VISIBLE_CHANGE);

      // updateIndicatorRotation（L123-141）逐式转译
      const base = spring.target - 1; // morphFactorBase
      const timeFactor = fraction >= 1 ? 0 : fraction; // playtime/650（==1 视为 0）
      const morphPerShape = spring.value - base; // morphFactorPerShape
      let rotation =
        (CONSTANT_ROTATION_PER_SHAPE + EXTRA_ROTATION_PER_SHAPE) * base +
        CONSTANT_ROTATION_PER_SHAPE * timeFactor +
        EXTRA_ROTATION_PER_SHAPE * morphPerShape;
      rotation %= 360;

      // 形状 Morph：floorMod(floor(morph), 7) + 段内进度（DrawingDelegate L120-125）
      const morphResult = getLoadingIndicatorMorphCubics(spring.value);
      const d = cubicsToSvgPath(morphResult.cubics, scale, 0, 0);

      if (pathRef.current && pathRef.current.getAttribute('d') !== d) {
        pathRef.current.setAttribute('d', d);
      }
      if (groupRef.current) {
        groupRef.current.setAttribute('transform', `rotate(${rotation - 90})`); // adjustCanvas rotate(-90) + rotationDegree
      }

      // updateIndicatorShapeAndColor（L144-154）：ArgbEvaluatorCompat 线性空间插值
      const len = colors.length;
      const startColorIndex = ((base % len) + len) % len;
      const endColorIndex = (startColorIndex + 1) % len;
      const t = Math.min(1, Math.max(0, morphPerShape));
      const mixed =
        len > 1 ? argbEvaluate(colors[startColorIndex], colors[endColorIndex], t) : colors[0];
      if (mixed !== colorRef.current) {
        colorRef.current = mixed;
        if (pathRef.current) pathRef.current.setAttribute('fill', mixed);
      }

      frameRef.current = requestAnimationFrame(render);
    };

    frameRef.current = requestAnimationFrame(render);
    return () => cancelAnimationFrame(frameRef.current);
    // running=false ↔ hide()：cancelAnimatorImmediately（L74-81）——直接停帧
  }, [running, reducedMotion, indicatorSize, colorsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const playing = running && !reducedMotion;

  return (
    <svg
      role="img"
      aria-label={running ? (reducedMotion ? '静态降级（系统动画已禁用）' : '加载中') : '已隐藏（对应 hide()）'}
      width={containerSize}
      height={containerSize}
      // adjustCanvas：clipRect(-preferredW/2 …) —— viewBox 即同一裁剪语义
      viewBox={`-${containerSize / 2} -${containerSize / 2} ${containerSize} ${containerSize}`}
    >
      {/* drawContainer：圆角矩形，radius = min(w,h)/2（DrawingDelegate L93） */}
      {containerColor !== 'transparent' && (
        <rect
          x={-containerSize / 2}
          y={-containerSize / 2}
          width={containerSize}
          height={containerSize}
          rx={containerSize / 2}
          fill={containerColor}
        />
      )}
      {playing ? (
        <g ref={groupRef} transform="rotate(-90)">
          <path ref={pathRef} fill={currentColor} />
        </g>
      ) : !running ? (
        // hide() 语义：internalHide → setVisibility(INVISIBLE)，指示器整体不可见（非静态图标）
        <g data-hidden-by-hide="true" />
      ) : (
        // 静态降级：isSystemAnimatorDisabled → ic_mtrl_arrow_circle，tint = indicatorColors[0]
        <g transform={`scale(${containerSize / 24})`}>
          <path d={STATIC_ARROW_CIRCLE_PATH} fill={colors[0]} />
        </g>
      )}
    </svg>
  );
};
