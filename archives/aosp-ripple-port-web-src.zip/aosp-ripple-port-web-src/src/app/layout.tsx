import type { Metadata } from "next";
import "./globals.css";

/* 第 27 轮（全站去 npm 化）：①摘除 @/components/ui/toaster（shadcn/Radix 死代码，
    演示自身从未派发过 toast（全站零引用），留在树里只会拖着 radix/react-toast
    等一串 npm 依赖）；
   ②摘除 next/font/google 的 Geist/Geist_Mono——脚手架残留字体，实际排版用的是
    globals.css @layer base :root 声明的 Google Sans Flex × 中文可变字体混排栈，
    Geist 变量只剩被覆写后的空壳（还多出一次构建期字体拉取）。@theme 映射已
    同步改指真实栈，见 globals.css。 */

export const metadata: Metadata = {
  title: "AOSP Ripple Port · M3 Expressive 涟漪与组件移植研究",
  description:
    "AOSP RippleShader / RippleAnimationSession 与 M3 Expressive 组件的 Web 移植复现演示，附官方 @material/web 2.5.0 同台对照。学习研究性质，与 Google 无隶属关系。",
  keywords: ["AOSP", "Ripple", "Material Design 3", "Expressive", "WebGL2", "移植"],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "AOSP Ripple Port",
    description: "AOSP 系统级涟漪与 M3 Expressive 组件的 Web 移植复现演示",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // 第 22 轮修复：@font-face 的字体 URL 必须按部署形态注入 basePath
  // （CSS 里的 url() 不吃 assetPrefix）。NEXT_PUBLIC_BASE_PATH 由 next.config.ts
  // env 配置在构建期内联：standalone = ''，Pages 导出 = '/asset-drop'。
  // 第 23 轮加固：①src 双 format 回退——个别浏览器不认 'truetype-variations'
  // 老关键字时落到 'truetype'（可变字体照样按可变处理），不再整条 src 报废；
  // ②3.9MB TTF 增加 preload——font-display:swap 期间英文先用回退字形，
  // 大文件慢载时用户会看到"英文没混搭"的假象，preload 显著缩短该窗口。
  const gsfSrc = `${process.env.NEXT_PUBLIC_BASE_PATH || ''}/fonts/GoogleSansFlex.ttf`;
  const fontFaceCss = `@font-face{font-family:'Google Sans Flex';src:url('${gsfSrc}') format('truetype-variations'),url('${gsfSrc}') format('truetype');font-weight:1 1000;font-stretch:25% 151%;font-style:normal;font-optical-sizing:auto;font-display:swap;}`;
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <head>
        {/* 字体 preload（React 19 自动置于 head；fonts 按规范以 CORS-anonymous 模式
            拉取，preload 必须 crossorigin 匹配否则等于白预载） */}
        <link rel="preload" href={gsfSrc} as="font" type="font/ttf" crossOrigin="anonymous" />
      </head>
      <body className="antialiased bg-background text-foreground">
        {/* 第 20 条（用户混搭方案）：中文可变字体 CDN（zeoseven fontsapi）。
            family 名与分片注册已实测核实：414 = WenYuan Rounded SC VF（471 分片，
            wght 100–900 可变）· 415 = WenYuan Serif SC VF（411 分片）·
            285 = Noto Serif CJK（672 分片）。英文 Google Sans Flex 不走此处 CDN——
            项目已内置本地 /fonts/GoogleSansFlex.ttf（google/fonts v26，OFL），
            @font-face 自第 22 轮起内联于本文件（basePath 感知）。React 19 会将 <link rel="stylesheet">
            自动提升到 <head>，浏览器端按 unicode-range 分片按需加载。 */}
        <link rel="preconnect" href="https://fontsapi.zeoseven.com" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/414/main/result.css" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/415/main/result.css" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/285/main/result.css" />
        {/* Google Sans Flex 本地 @font-face（第 22 轮自 globals.css 迁入，见上方注释） */}
        <style dangerouslySetInnerHTML={{ __html: fontFaceCss }} />
        {children}
      </body>
    </html>
  );
}
