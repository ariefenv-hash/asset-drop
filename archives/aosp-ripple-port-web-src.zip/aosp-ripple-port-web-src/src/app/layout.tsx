import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Z.ai Code Scaffold - AI-Powered Development",
  description: "Modern Next.js scaffold optimized for AI-powered development with Z.ai. Built with TypeScript, Tailwind CSS, and shadcn/ui.",
  keywords: ["Z.ai", "Next.js", "TypeScript", "Tailwind CSS", "shadcn/ui", "AI development", "React"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Z.ai Code Scaffold",
    description: "AI-powered development with modern React stack",
    url: "https://chat.z.ai",
    siteName: "Z.ai",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Z.ai Code Scaffold",
    description: "AI-powered development with modern React stack",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {/* 第 20 条（用户混搭方案）：中文可变字体 CDN（zeoseven fontsapi）。
            family 名与分片注册已实测核实：414 = WenYuan Rounded SC VF（471 分片，
            wght 100–900 可变）· 415 = WenYuan Serif SC VF（411 分片）·
            285 = Noto Serif CJK（672 分片）。英文 Google Sans Flex 不走此处 CDN——
            项目已内置本地 /fonts/GoogleSansFlex.ttf（google/fonts v26，OFL），
            @font-face 见 globals.css。React 19 会将 <link rel="stylesheet">
            自动提升到 <head>，浏览器端按 unicode-range 分片按需加载。 */}
        <link rel="preconnect" href="https://fontsapi.zeoseven.com" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/414/main/result.css" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/415/main/result.css" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/285/main/result.css" />
        {children}
        <Toaster />
      </body>
    </html>
  );
}
