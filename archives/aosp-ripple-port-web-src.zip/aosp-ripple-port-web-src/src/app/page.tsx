'use client'

import App from '@/components/ripple/App'

export default function Home() {
  return <App />
}
