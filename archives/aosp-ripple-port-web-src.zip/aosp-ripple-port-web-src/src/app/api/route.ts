import { NextResponse } from "next/server";

// force-static：GitHub Pages 静态导出（NEXT_EXPORT=1）模式下本路由
// 预渲染为静态 JSON，页面功能不依赖此路由（scaffold 健康检查用）。
export const dynamic = "force-static";

export async function GET() {
  return NextResponse.json({ message: "Hello, world!" });
}
