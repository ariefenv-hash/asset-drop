/**
 * 第 22 轮：公共资源 basePath 助手。
 *
 * 背景：本项目有两种分发形态——
 *  · standalone 预览（默认）：站点在根路径，公共资源前缀为 ''；
 *  · NEXT_EXPORT=1 + NEXT_BASE_PATH=/asset-drop 的静态导出：GitHub Pages
 *    把站点挂在 /asset-drop/ 子路径下。
 * 此前 iframe / zip 链接 / @font-face 均硬编码绝对路径（如
 * "/official-md-ripple/index.html"），Pages 上必然 404（Next 的 assetPrefix
 * 只作用于 _next 静态资源，不会改写 JSX / CSS 里的手工路径）。
 *
 * 取值链：next.config.ts env.NEXT_PUBLIC_BASE_PATH（= NEXT_BASE_PATH）在
 * 构建期内联进 bundle，两种形态自动切换，无需运行时探测。
 */
export const PUBLIC_BASE_PATH: string = process.env.NEXT_PUBLIC_BASE_PATH || '';

export function withBasePath(path: string): string {
  if (!PUBLIC_BASE_PATH) return path;
  if (!path.startsWith('/')) return `${PUBLIC_BASE_PATH}/${path}`;
  return `${PUBLIC_BASE_PATH}${path}`;
}
