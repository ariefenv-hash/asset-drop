/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { customElement } from 'lit/decorators.js';
import { OutlinedField } from './internal/outlined-field.js';
import { styles as outlinedStyles } from './internal/outlined-styles.cssresult.js';
import { styles as sharedStyles } from './internal/shared-styles.cssresult.js';
/**
 * TODO(b/228525797): add docs
 * @final
 * @suppress {visibility}
 */
let MdOutlinedField = class MdOutlinedField extends OutlinedField {
};
MdOutlinedField.styles = [sharedStyles, outlinedStyles];
MdOutlinedField = __decorate([
    customElement('md-outlined-field')
], MdOutlinedField);
export { MdOutlinedField };
//# sourceMappingURL=outlined-field.js.map