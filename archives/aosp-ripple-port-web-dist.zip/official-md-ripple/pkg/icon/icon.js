/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { customElement } from 'lit/decorators.js';
import { Icon } from './internal/icon.js';
import { styles } from './internal/icon-styles.cssresult.js';
/**
 * @final
 * @suppress {visibility}
 */
let MdIcon = class MdIcon extends Icon {
};
/** @nocollapse */
MdIcon.styles = [styles];
MdIcon = __decorate([
    customElement('md-icon')
], MdIcon);
export { MdIcon };
//# sourceMappingURL=icon.js.map