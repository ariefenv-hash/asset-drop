/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { customElement } from 'lit/decorators.js';
import { NavigationTab } from './internal/navigation-tab.js';
import { styles } from './internal/navigation-tab-styles.cssresult.js';
/**
 * @final
 * @suppress {visibility}
 */
let MdNavigationTab = class MdNavigationTab extends NavigationTab {
};
MdNavigationTab.styles = [styles];
MdNavigationTab = __decorate([
    customElement('md-navigation-tab')
], MdNavigationTab);
export { MdNavigationTab };
//# sourceMappingURL=navigation-tab.js.map