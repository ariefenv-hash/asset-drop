/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated stylesheet for ./labs/gb/styles/motion/md-motion-tokens-easing.css.
import { css } from 'lit';
export const styles = css `/*!
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */@layer md.sys.motion{:root{--md-sys-motion-easing-standard: cubic-bezier(0.2, 0, 0, 1);--md-sys-motion-easing-standard-accelerate: cubic-bezier(0.3, 0, 1, 1);--md-sys-motion-easing-standard-decelerate: cubic-bezier(0, 0, 0, 1);--md-sys-motion-easing-emphasized: cubic-bezier(0.2, 0, 0, 1);--md-sys-motion-easing-emphasized-accelerate: cubic-bezier(0.3, 0, 0.8, 0.15);--md-sys-motion-easing-emphasized-decelerate: cubic-bezier(0.05, 0.7, 0.1, 1);--md-sys-motion-duration-short1: 50ms;--md-sys-motion-duration-short2: 100ms;--md-sys-motion-duration-short3: 150ms;--md-sys-motion-duration-short4: 200ms;--md-sys-motion-duration-medium1: 250ms;--md-sys-motion-duration-medium2: 300ms;--md-sys-motion-duration-medium3: 350ms;--md-sys-motion-duration-medium4: 400ms;--md-sys-motion-duration-long1: 450ms;--md-sys-motion-duration-long2: 500ms;--md-sys-motion-duration-long3: 550ms;--md-sys-motion-duration-long4: 600ms;--md-sys-motion-duration-extra-long1: 700ms;--md-sys-motion-duration-extra-long2: 800ms;--md-sys-motion-duration-extra-long3: 900ms;--md-sys-motion-duration-extra-long4: 1000ms}}
`;
export default styles.styleSheet;
//# sourceMappingURL=md-motion-tokens-easing.cssresult.js.map