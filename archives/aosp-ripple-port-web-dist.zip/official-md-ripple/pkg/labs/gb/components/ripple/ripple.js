/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { createElementDirective } from '../shared/directives.js';
import { PSEUDO_CLASSES, isDisabled } from '../shared/pseudo-classes.js';
/** Ripple classes. */
export const RIPPLE_CLASSES = {
    ripple: 'ripple',
    rippleTarget: 'ripple-target',
    rippleHost: 'ripple-host',
    hover: PSEUDO_CLASSES.hover,
    active: PSEUDO_CLASSES.active,
    disabled: PSEUDO_CLASSES.disabled,
};
/**
 * Returns the ripple classes to apply to an element based on the given state.
 *
 * @param state The state of the ripple.
 * @return An object of class names and truthy values if they apply.
 */
export function rippleClasses({ hover = false, active = false, disabled = false, } = {}) {
    return {
        [RIPPLE_CLASSES.ripple]: true,
        [RIPPLE_CLASSES.hover]: hover,
        [RIPPLE_CLASSES.active]: active,
        [RIPPLE_CLASSES.disabled]: disabled,
    };
}
const MINIMUM_PRESS_MS = 225;
let ripplePropertiesRegistered = false;
/**
 * Sets up ripple functionality for the given element.
 *
 * @param ripple The element on which to set up ripple functionality.
 * @param opts Setup options, supports a cleanup `signal`.
 */
export function setupRipple(ripple, opts) {
    if (!ripplePropertiesRegistered) {
        const properties = [
            ['--ripple-scale', '0%'],
            ['--ripple-hover-opacity', '0%'],
            ['--ripple-press-opacity', '0%'],
            ['--ripple-x', '50%'],
            ['--ripple-y', '50%'],
        ];
        try {
            for (const [property, value] of properties) {
                CSS.registerProperty({
                    name: property,
                    syntax: '<percentage>',
                    inherits: false,
                    initialValue: value,
                });
            }
        }
        catch {
            // Ignore errors if the properties are already registered.
        }
        finally {
            ripplePropertiesRegistered = true;
        }
    }
    let minimumPressTimeoutId;
    const activateRipple = () => {
        // If the ripple is already active, restart the current press animation.
        if (ripple.classList.contains(RIPPLE_CLASSES.active)) {
            const pressAnimation = ripple
                .getAnimations()
                .find((animation) => animation.animationName ===
                'ripple-press');
            pressAnimation?.cancel();
            pressAnimation?.play();
        }
        // Emulate the `:active` class for a minimum press duration to show the
        // ripple effect on short clicks.
        ripple.classList.add(RIPPLE_CLASSES.active);
        clearTimeout(minimumPressTimeoutId);
        minimumPressTimeoutId = setTimeout(() => {
            ripple.classList.remove(RIPPLE_CLASSES.active);
        }, MINIMUM_PRESS_MS);
    };
    // Return true if the ripple is disabled, or if the ripple class has been
    // removed. This allows components to disable and re-enable ripple behavior.
    const isRippleDisabled = () => isDisabled(ripple) || !ripple.matches(`.${RIPPLE_CLASSES.ripple}`);
    ripple.addEventListener('pointerdown', (event) => {
        if (isRippleDisabled())
            return;
        // Set ripple position to the pointer position.
        const rect = ripple.getBoundingClientRect();
        const x = (event.clientX - rect.x) / rect.width;
        const y = (event.clientY - rect.y) / rect.height;
        ripple.style.setProperty('--ripple-x', `${x * 100}%`);
        ripple.style.setProperty('--ripple-y', `${y * 100}%`);
        activateRipple();
    }, opts);
    ripple.addEventListener('keydown', (event) => {
        // Reset ripple pointer position when a key is pressed.
        ripple.style.removeProperty('--ripple-x');
        ripple.style.removeProperty('--ripple-y');
    }, opts);
    ripple.addEventListener('click', (event) => {
        // A UIEvent.detail click count of 0 indicates the click was not triggered
        // by a pointer. Show the ripple press effect for these clicks as well.
        if (event.detail === 0 && !isRippleDisabled()) {
            activateRipple();
        }
    }, opts);
}
/**
 * A Lit directive that adds updates the position of a ripple to match pointer
 * interactions. Use with the `.ripple` class.
 *
 * @example
 * ```ts
 * class Component extends LitElement {
 *   static styles = [rippleStyles, css`...`];
 *
 *   render() {
 *     return html`<button class="ripple" ${ripple()}>Ripple effect</button>`;
 *   }
 * }
 * ```
 *
 * Use the `.ripple-target` class if the interactive element is a parent or
 * child of the ripple element.
 *
 * The `ripple()` directive should be applied to the parent element, which may
 * be the `.ripple-target` instead of the `.ripple`.
 *
 * @example
 * ```ts
 * html`
 *   <div class="card ripple" ${ripple()}>
 *     Child interactive element
 *     <button class="ripple-target card-btn"></button>
 *   </div>
 *
 *   <button class="ripple-target" ${ripple()}>
 *     Parent interactive element
 *     <span class="ripple"></span>
 *   </button>
 * `;
 * ```
 */
export const ripple = createElementDirective(setupRipple);
//# sourceMappingURL=ripple.js.map