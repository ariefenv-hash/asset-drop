/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { afterDispatch, setupDispatchHooks, } from '../../../../internal/events/dispatch-hooks.js';
import { focusRingClasses } from '../focus/focus-ring.js';
import { rippleClasses, setupRipple } from '../ripple/ripple.js';
import { createClassMapDirective } from '../shared/directives.js';
import { isDisabled, PSEUDO_CLASSES } from '../shared/pseudo-classes.js';
/** Button color configurations. */
export const BUTTON_COLORS = {
    filled: 'filled',
    elevated: 'elevated',
    tonal: 'tonal',
    outlined: 'outlined',
    text: 'text',
};
/** Button size configurations. */
export const BUTTON_SIZES = {
    xs: 'xs',
    sm: 'sm',
    md: 'md',
    lg: 'lg',
    xl: 'xl',
};
/** Button classes. */
export const BUTTON_CLASSES = {
    btn: 'btn',
    btnFilled: 'btn-filled',
    btnElevated: 'btn-elevated',
    btnTonal: 'btn-tonal',
    btnOutlined: 'btn-outlined',
    btnText: 'btn-text',
    btnXs: 'btn-xs',
    btnSm: 'btn-sm',
    btnMd: 'btn-md',
    btnLg: 'btn-lg',
    btnXl: 'btn-xl',
    btnSquare: 'btn-square',
    btnUnselected: 'btn-unselected',
    btnSelected: 'btn-selected',
    active: PSEUDO_CLASSES.active,
    disabled: PSEUDO_CLASSES.disabled,
};
/**
 * Returns the button classes to apply to an element based on the given state.
 *
 * @param state The state of the button.
 * @return An object of class names and truthy values if they apply.
 */
export function buttonClasses({ color, size, square = false, selected, active = false, disabled = false, } = {}) {
    return {
        ...rippleClasses(),
        ...focusRingClasses(),
        [BUTTON_CLASSES.btn]: true,
        [BUTTON_CLASSES.btnFilled]: color === BUTTON_COLORS.filled,
        [BUTTON_CLASSES.btnElevated]: color === BUTTON_COLORS.elevated,
        [BUTTON_CLASSES.btnTonal]: color === BUTTON_COLORS.tonal,
        [BUTTON_CLASSES.btnOutlined]: color === BUTTON_COLORS.outlined,
        [BUTTON_CLASSES.btnText]: color === BUTTON_COLORS.text || !color,
        [BUTTON_CLASSES.btnXs]: size === BUTTON_SIZES.xs,
        [BUTTON_CLASSES.btnSm]: size === BUTTON_SIZES.sm || !size,
        [BUTTON_CLASSES.btnMd]: size === BUTTON_SIZES.md,
        [BUTTON_CLASSES.btnLg]: size === BUTTON_SIZES.lg,
        [BUTTON_CLASSES.btnXl]: size === BUTTON_SIZES.xl,
        [BUTTON_CLASSES.btnSquare]: square,
        [BUTTON_CLASSES.btnUnselected]: selected === false,
        [BUTTON_CLASSES.btnSelected]: selected === true,
        [BUTTON_CLASSES.active]: active,
        [BUTTON_CLASSES.disabled]: disabled,
    };
}
/**
 * Sets up button functionality for the given element.
 *
 * @param button The element on which to set up button functionality.
 * @param opts Setup options, supports a cleanup `signal`.
 */
export function setupButton(button, opts) {
    setupDispatchHooks(button, 'click');
    setupRipple(button, opts);
    button.addEventListener('click', (event) => {
        // When disabled, explicitly prevent the click from propagating to other
        // event listeners as well as prevent the default action. This is because
        // the underlying element may not actually be `:disabled`, such as an
        // anchor tag or a soft-disabled button.
        if (isDisabled(button)) {
            event.stopImmediatePropagation();
            event.preventDefault();
            return;
        }
        afterDispatch(event, () => {
            const isToggle = button.hasAttribute('aria-pressed') ||
                button.matches(`.${BUTTON_CLASSES.btnSelected},.${BUTTON_CLASSES.btnUnselected}`);
            if (event.defaultPrevented || !isToggle) {
                return;
            }
            const isPressed = button.ariaPressed === 'true';
            button.ariaPressed = String(!isPressed);
            // Mimic native browser input and change event behavior.
            button.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true }));
            button.dispatchEvent(new Event('change', { bubbles: true }));
        });
    }, opts);
}
/**
 * A Lit directive that adds button styling and functionality to its element.
 *
 * @example
 * ```ts
 * html`<button class="${button({color: 'filled'})}">Filled</button>`;
 * ```
 */
export const button = createClassMapDirective({
    getClasses: buttonClasses,
    setupElement: setupButton,
});
//# sourceMappingURL=button.js.map