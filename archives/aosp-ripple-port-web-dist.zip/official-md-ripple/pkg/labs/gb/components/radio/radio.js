/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { focusRingClasses } from '../focus/focus-ring.js';
import { rippleClasses, setupRipple } from '../ripple/ripple.js';
import { createClassMapDirective } from '../shared/directives.js';
import { PSEUDO_CLASSES } from '../shared/pseudo-classes.js';
/** Radio classes. */
export const RADIO_CLASSES = {
    radio: 'radio',
    hover: PSEUDO_CLASSES.hover,
    focus: PSEUDO_CLASSES.focus,
    active: PSEUDO_CLASSES.active,
    checked: PSEUDO_CLASSES.checked,
    disabled: PSEUDO_CLASSES.disabled,
};
/**
 * Returns the radio classes to apply to an element based on the given state.
 *
 * @param state The state of the radio.
 * @return An object of class names and truthy values if they apply.
 */
export function radioClasses({ hover = false, focus = false, active = false, checked = false, disabled = false, } = {}) {
    return {
        ...rippleClasses(),
        ...focusRingClasses(),
        [RADIO_CLASSES.radio]: true,
        [RADIO_CLASSES.hover]: hover,
        [RADIO_CLASSES.focus]: focus,
        [RADIO_CLASSES.active]: active,
        [RADIO_CLASSES.checked]: checked,
        [RADIO_CLASSES.disabled]: disabled,
    };
}
/**
 * Sets up radio functionality for the given element.
 *
 * @param radio The element on which to set up radio functionality.
 * @param opts Setup options, supports a cleanup `signal`.
 */
export function setupRadio(radio, opts) {
    setupRipple(radio, opts);
}
/**
 * A Lit directive that adds radio styling and functionality to its element.
 *
 * @example
 * ```ts
 * html`
 *   <input type="radio" class="${radio()}" name="radio-group">
 *   <input type="radio" class="${radio()}" name="radio-group">
 *   <input type="radio" class="${radio()}" name="radio-group">
 * `;
 * ```
 */
export const radio = createClassMapDirective({
    getClasses: radioClasses,
    setupElement: setupRadio,
});
//# sourceMappingURL=radio.js.map