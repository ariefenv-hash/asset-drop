/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { __decorate } from "tslib";
import { css, html, isServer, LitElement } from 'lit';
import { property, query, state } from 'lit/decorators.js';
import { afterDispatch, setupDispatchHooks, } from '../../../../internal/events/dispatch-hooks.js';
import { SingleSelectionController } from '../../../../radio/internal/single-selection-controller.js';
import { createValidator, getValidityAnchor, mixinConstraintValidation, } from '../../../behaviors/constraint-validation.js';
import { internals, mixinElementInternals, } from '../../../behaviors/element-internals.js';
import { mixinFocusable } from '../../../behaviors/focusable.js';
import { getFormState, getFormValue, mixinFormAssociated, } from '../../../behaviors/form-associated.js';
import { RadioValidator } from '../../../behaviors/validators/radio-validator.js';
import focusRingStyles from '../focus/focus-ring.css' with { type: 'css' }; // github-only
// import focusRingStyles from '../focus/focus-ring.cssresult.js'; // google3-only
import rippleStyles from '../ripple/ripple.css' with { type: 'css' }; // github-only
// import rippleStyles from '../ripple/ripple.cssresult.js'; // google3-only
import radioStyles from './radio.css' with { type: 'css' }; // github-only
// import {styles as radioStyles} from './radio.cssresult.js'; // google3-only
import { radio } from './radio.js';
// Separate variable needed for closure.
const radioBaseClass = mixinConstraintValidation(mixinFormAssociated(mixinElementInternals(mixinFocusable(LitElement))));
/**
 * A Material Design radio component.
 *
 * @fires {InputEvent} input - Fired when the radio is checked (but not unchecked). --bubbles --composed
 * @fires {Event} change - Fired when the radio is checked (but not unchecked). --bubbles
 * @csspart radio - The radio's root element.
 * @cssprop --icon-color
 * @cssprop --icon-size
 * @cssprop --state-layer-color
 * @cssprop --state-layer-shape
 * @cssprop --state-layer-size
 */
export class RadioElement extends radioBaseClass {
    /**
     * Whether or not the radio is selected.
     */
    get checked() {
        return this[internals].ariaChecked === 'true';
    }
    set checked(checked) {
        const wasChecked = this.checked;
        if (wasChecked === checked) {
            return;
        }
        this[internals].ariaChecked = String(checked);
        this.requestUpdate('checked', wasChecked);
        this.selectionController.handleCheckedChange();
    }
    /**
     * The default checked state of the radio.
     */
    get defaultChecked() {
        return this.hasAttribute('checked');
    }
    set defaultChecked(value) {
        this.toggleAttribute('checked', value || false);
    }
    constructor() {
        super();
        /**
         * Whether or not the radio is required. If any radio is required in a group,
         * all radios are implicitly required.
         */
        this.required = false;
        /**
         * The element value to use in form submission when checked.
         */
        this.value = 'on';
        this.selectionController = new SingleSelectionController(this);
        /**
         * Mimics the behavior of <input> dirty checkedness, where the `checked`
         * attribute only updates the checked state if the radio has not been
         * interacted with.
         *
         * @see https://html.spec.whatwg.org/multipage/input.html#concept-input-checked-dirty-flag
         */
        this.dirtyCheckedness = false;
        this.isFocused = false;
        if (isServer)
            return;
        this[internals].role = 'radio';
        this.addController(this.selectionController);
        setupDispatchHooks(this, 'click', 'keydown');
        this.addEventListener('click', (event) => {
            // Return if disabled, or already checked since clicking on a checked
            // radio does not dispatch events.
            if (this.disabled || this.checked)
                return;
            afterDispatch(event, () => {
                if (event.defaultPrevented)
                    return;
                // Per spec, clicking on a radio input always selects it.
                this.checked = true;
                this.dirtyCheckedness = true;
                this.dispatchEvent(new Event('change', { bubbles: true }));
                this.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true }));
            });
        });
        this.addEventListener('keydown', (event) => {
            afterDispatch(event, () => {
                if (event.key !== ' ' || event.defaultPrevented) {
                    return;
                }
                this.click();
            });
        });
        this.addEventListener('focus', () => {
            this.isFocused = true;
        });
        this.addEventListener('blur', () => {
            this.isFocused = false;
        });
    }
    render() {
        return html `<div
      part="radio"
      class="ripple-host focus-ring-host ${radio({
            checked: this.checked,
            disabled: this.disabled,
            focus: this.isFocused,
        })}"></div>`;
    }
    attributeChangedCallback(name, oldValue, newValue) {
        if (name === 'checked' && this.dirtyCheckedness) {
            // The 'checked' attribute does not update radios that have been
            // interacted with.
            return;
        }
        super.attributeChangedCallback(name, oldValue, newValue);
    }
    [getFormValue]() {
        return this.checked ? this.value : null;
    }
    [getFormState]() {
        return String(this.checked);
    }
    formResetCallback() {
        this.dirtyCheckedness = false;
        this.checked = this.defaultChecked;
    }
    formStateRestoreCallback(state) {
        this.checked = state === 'true';
    }
    [createValidator]() {
        return new RadioValidator(() => {
            if (!this.selectionController) {
                // Validation runs on superclass construction, so selection controller
                // might not actually be ready until this class constructs.
                return [this];
            }
            return this.selectionController.controls;
        });
    }
    [getValidityAnchor]() {
        return this.radio;
    }
}
RadioElement.styles = [
    focusRingStyles,
    rippleStyles,
    radioStyles,
    css `
      :host {
        display: inline-flex;
        outline: none;
      }
      .radio {
        flex: 1;
      }
    `,
];
__decorate([
    property({ type: Boolean })
], RadioElement.prototype, "checked", null);
__decorate([
    property({ type: Boolean })
], RadioElement.prototype, "required", void 0);
__decorate([
    property()
], RadioElement.prototype, "value", void 0);
__decorate([
    query('.radio', true)
], RadioElement.prototype, "radio", void 0);
__decorate([
    state()
], RadioElement.prototype, "isFocused", void 0);
//# sourceMappingURL=radio-element.js.map