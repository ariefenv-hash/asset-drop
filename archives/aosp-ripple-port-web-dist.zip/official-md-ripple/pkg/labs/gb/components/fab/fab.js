/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { focusRingClasses } from '../focus/focus-ring.js';
import { rippleClasses, setupRipple } from '../ripple/ripple.js';
import { createClassMapDirective } from '../shared/directives.js';
import { PSEUDO_CLASSES } from '../shared/pseudo-classes.js';
/** Fab color configurations. */
export const FAB_COLORS = {
    primary: 'primary',
    primaryContainer: 'primary-container',
    secondary: 'secondary',
    secondaryContainer: 'secondary-container',
    tertiary: 'tertiary',
    tertiaryContainer: 'tertiary-container',
};
/** Fab size configurations. */
export const FAB_SIZES = {
    default: 'default',
    md: 'md',
    lg: 'lg',
};
/** Fab classes. */
export const FAB_CLASSES = {
    fab: 'fab',
    fabPrimary: 'fab-primary',
    fabPrimaryContainer: 'fab-primary-container',
    fabSecondary: 'fab-secondary',
    fabSecondaryContainer: 'fab-secondary-container',
    fabTertiary: 'fab-tertiary',
    fabTertiaryContainer: 'fab-tertiary-container',
    fabMd: 'fab-md',
    fabLg: 'fab-lg',
    hover: PSEUDO_CLASSES.hover,
    active: PSEUDO_CLASSES.active,
};
/**
 * Returns the fab classes to apply to an element based on the given state.
 *
 * @param state The state of the fab.
 * @return An object of class names and truthy values if they apply.
 */
export function fabClasses({ color, size, hover = false, active = false, } = {}) {
    return {
        ...rippleClasses(),
        ...focusRingClasses(),
        [FAB_CLASSES.fab]: true,
        [FAB_CLASSES.fabPrimary]: color === FAB_COLORS.primary,
        [FAB_CLASSES.fabPrimaryContainer]: color === FAB_COLORS.primaryContainer || !color,
        [FAB_CLASSES.fabSecondary]: color === FAB_COLORS.secondary,
        [FAB_CLASSES.fabSecondaryContainer]: color === FAB_COLORS.secondaryContainer,
        [FAB_CLASSES.fabTertiary]: color === FAB_COLORS.tertiary,
        [FAB_CLASSES.fabTertiaryContainer]: color === FAB_COLORS.tertiaryContainer,
        [FAB_CLASSES.fabMd]: size === FAB_SIZES.md,
        [FAB_CLASSES.fabLg]: size === FAB_SIZES.lg,
        [FAB_CLASSES.hover]: hover,
        [FAB_CLASSES.active]: active,
    };
}
/**
 * Sets up fab functionality for the given element.
 *
 * @param fab The element on which to set up fab functionality.
 * @param opts Setup options, supports a cleanup `signal`.
 */
export function setupFab(fab, opts) {
    setupRipple(fab, opts);
}
/**
 * A Lit directive that adds fab styling and functionality to its element.
 *
 * @example
 * ```ts
 * html`
 *   <button class="${fab()}">
 *     <md-icon>add</md-icon>
 *   </button>
 *
 *   <button class="${fab()}">
 *     <md-icon>add</md-icon>
 *     Extended
 *   </button>
 * `;
 * ```
 */
export const fab = createClassMapDirective({
    getClasses: fabClasses,
    setupElement: setupFab,
});
//# sourceMappingURL=fab.js.map