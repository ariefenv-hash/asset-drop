"use client";
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, X } from '@/components/icons';
import {
  AOSP_MAX_RIPPLES,
  AospRippleEngineMode,
  effectiveRasterDpr,
  getSharedRippleRenderer,
  RippleColorRGBA,
  RippleSession,
  SystemUiRippleShape,
} from '../../aosp/RippleEngine';

export interface AospExpressiveSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  ariaLabel: string;
  showIcons?: boolean;
  disabled?: boolean;
  mode: AospRippleEngineMode;
  waveColor: RippleColorRGBA;
  sparkleColor: RippleColorRGBA;
  sparkleStrength: number;
  distortionStrength: number;
  systemUiShape: SystemUiRippleShape;
  speedMultiplier: number;
  densityScale: number;
  accentHex: string;
  onPrimaryHex?: string;
  inactiveTrackHex?: string;
  outlineHex?: string;
  thumbUncheckedHex?: string;
  thumbUncheckedIconHex?: string;
}

/**
 * 【第 29 轮全盘核查修正（用户指令：还原基准=AOSP/Android 17 kt·java·xml，
 *  不复刻网页版）：本节原引据自网页版 _handle.scss 的参数已全部改按 Android 源
 *  逐项重核；网页版独有参数（自定义过冲缓动）已按铁律 1 移除——明细见本节尾】
 *
 * 开关按压/位移行为（MDC-Android 1.14.0 materialswitch 模块源码，本轮 contents
 * API 逐文件取回）：
 *  · 轨道 52×32dp ✓（tokens.xml m3_comp_switch_track_{width,height}，原实现已合）；
 *  · 小球按压 24↔28dp：materialswitch/res/drawable/mtrl_switch_thumb.xml
 *    animated-selector 的 pressed↔checked/unchecked 形变：
 *    path_checked（r12=24dp）↔ path_pressed（r14=28dp），双向往返均
 *    mtrl_switch_thumb_pressed_duration = m3_sys_motion_duration_short2 = 100ms，
 *    插值器 m3_sys_motion_easing_standard = cubic-bezier(0.2,0,0,1)
 *    （原注释误引网页版 100ms linear / 松开 250ms standard——第 29 轮已按 Android 源改）；
 *  · 小球位移：Android 位移 = 圆→stadium→圆 pathData 形变（mtrl_switch_thumb_
 *    unchecked_checked：pre-morph short2=100ms + post-morph short3=150ms，
 *    总 medium1=250ms；objectAnimator 未指定插值器 = Android 默认
 *    AccelerateDecelerate）。本移植保持用户 22-28 轮复核验收的「圆形平移」形态
 *    （Android 的 stadium 中间形为已知简化取舍，如实标注）；位移时长按 medium1
 *    取 250ms，缓动取 Android 默认插值器（AccelerateDecelerateInterpolator =
 *    余弦曲线，AOSP android.view.animation.AccelerateDecelerateInterpolator#getInterpolation）
 *    的标准 Web 映射 cubic-bezier(0.37,0,0.63,1)（easeInOutSine），
 *    【网页版自定义过冲缓动 cubic-bezier(0.175,0.885,0.32,1.275) 已移除】。
 *  · 状态层 40×40 圆：M3 规范状态层（m3.material.io/components/switch/specs：
 *    state layer 40dp，hover 8% / pressed 12%）——Android 端经 controlBackground
 *    实现且不暴露独立 token（materialswitch tokens.xml 无 state-layer-size 项），
 *    网页版 --md-switch-state-layer-size 同值互证；40×40 圆形约束涟漪 = 用户第
 *    22 轮复核验收的移植形态。0.08/0.12 两值 Android 端经
 *    m3_comp_switch_{selected,unselected}_{hover,pressed}_state_layer_opacity →
 *    @dimen/m3_sys_state_* 引用（定义文件本轮 API 通道未能定位，如实标注；
 *    数值与 Web 版 token 一致）。
 *  · 按压涟漪从触点生长、被状态层裁剪进 40×40 圆内（不会扩散过整条轨道——
 *    用户观察的"小方块区域涟漪"实证）。
 *
 * 据此修正：
 *  1. 撤掉旧实现的“按整条开关生成无界 WebGL 涟漪光晕”（涟漪滥用）——Android
 *     开关语义均无此行为；改为约束状态层：40×40 圆形 mask + 星斑着色器
 *     （framework / systemui 两种模式均支持 u_maskRadii）。
 *  2. 按压手感：24→28px（100ms standard，按 Android 源；第 29 轮前为网页版
 *     100ms linear），并叠加 1.05 的轻微放大（transform scale）——用户要求。
 *  3. 新增 Web 增强交互（MDC-Android MaterialSwitch 未暴露拖拽 API，特此注明）：
 *     按住小球可左右拖拽（rAF 命令式写 DOM + setPointerCapture，与滑块第 20 条
 *     同款方案），松手自动吸附判定——越出行程中点（或甩动速度 > 0.35px/ms）即切换，
 *     否则以位移缓动回弹原位。
 *  【第 29 轮核查结论】本文件不再引用任何网页版独有参数；网页版仅有、且被保留
 *   的行为=0（其余均为 Android 源值或用户验收的增强项，均已标注）。
 *
 * ===== 第 24 轮加固（全面自审）=====
 *  4. 修复派生 click 吞掉标志残留：pointercancel / lostpointercapture 结束拖拽
 *     时无 click 跟随，旧布尔标志会吞掉下一次正常点击（开关"点不动一次"）；
 *     改为 CLICK_SUPPRESS_WINDOW_MS=600 时间窗 + pointerdown 重置。
 *  5. 键盘：key repeat 不再重复生成涟漪 session（状态切换仍走原生 click）；
 *     涟漪生长点从轨道中心改为小球实际中心（状态层盒中心）；
 *     释放定时器收进卸载清理。
 *  6. prefers-reduced-motion：撤位移/过冲动画与按压微放大，仅保留 67ms 颜色
 *     过渡（M3 无障碍基线）。
 *  7. WebGL2 不可用时以官方 0.12 pressed-state-layer 的 CSS 状态层兜底，
 *     不再出现"按下零反馈"死区；几何与 WebGL 路径一致。
 *  8. 移动端长按体验：屏蔽 contextmenu / 文本选择 / iOS 长按呼出气泡。
 */
const TRACK_W = 52;
const TRACK_H = 32;
const STATE_LAYER_SIZE = 40; // M3 规范状态层 40dp（Android 经 controlBackground 实现，无独立 token；网页版 token 同值互证，见头注）
const STATE_LAYER_RADIUS = STATE_LAYER_SIZE / 2;
const TRAVEL_MIN = TRACK_H / 2; // 16 — 小球中心左极点
const TRAVEL_MAX = TRACK_W - TRACK_H / 2; // 36 — 小球中心右极点
const TRAVEL_MID = (TRAVEL_MIN + TRAVEL_MAX) / 2; // 26 — 自动吸附判定线
const DRAG_DEAD_ZONE = 4; // px，低于此视为点击而非拖拽
const FLING_SPEED = 0.35; // px/ms，甩动判定阈值

/** 第 29 轮：Android 源缓动（materialswitch drawable/integers 取证，见头注） */
const EASE_TRAVEL = 'cubic-bezier(0.37, 0, 0.63, 1)'; // 位移：Android 默认 AccelerateDecelerateInterpolator（余弦 easeInOutSine）的标准 Web 映射（250ms = medium1）
const EASE_STANDARD = 'cubic-bezier(0.2, 0, 0, 1)'; // M3 standard（Android m3_sys_motion_easing_standard）
const CLICK_SUPPRESS_WINDOW_MS = 600; // 拖拽松手后浏览器可能派生 click，仅在此时间窗内吞掉

type PressEase = {
  thumb: string;
  canvas: string;
};

/**
 * 第 24 轮：prefers-reduced-motion 支持。
 * 减少动态效果时撤掉位移动画与过冲缓动（官方 M3 无障碍基线：非必要位移动画
 * 应弱化），仅保留 67ms 颜色过渡；按压微放大同步关闭（scale=1）。
 */
function easedTransitions(pressed: boolean, reducedMotion: boolean): PressEase {
  if (reducedMotion) {
    return {
      thumb: 'background-color 67ms linear',
      canvas: 'none',
    };
  }
  // 第 29 轮按 Android 源：按压/松开均为 short2=100ms · standard（mtrl_switch_thumb_pressed_duration
  // 双向往返同参）；位移 medium1=250ms · Android 默认插值器近似（原网页版 300ms 过冲已移除）
  const size = `width 100ms ${EASE_STANDARD}, height 100ms ${EASE_STANDARD}`;
  return {
    thumb: `left 250ms ${EASE_TRAVEL}, ${size}, transform 100ms ${EASE_STANDARD}, background-color 67ms linear`,
    canvas: `left 250ms ${EASE_TRAVEL}`,
  };
}

export const AospExpressiveSwitch: React.FC<AospExpressiveSwitchProps> = ({
  checked,
  onChange,
  ariaLabel,
  showIcons = true,
  disabled = false,
  mode,
  waveColor,
  sparkleColor,
  sparkleStrength,
  distortionStrength,
  systemUiShape,
  speedMultiplier,
  densityScale,
  accentHex,
  onPrimaryHex = '#ffffff',
  inactiveTrackHex,
  outlineHex,
  thumbUncheckedHex,
  thumbUncheckedIconHex,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const thumbRef = useRef<HTMLSpanElement>(null);
  const sessionsRef = useRef<RippleSession[]>([]);
  const activeSessionRef = useRef<RippleSession | null>(null);
  const rafRef = useRef<number | null>(null);
  const moveRafRef = useRef<number | null>(null);
  const nextIdRef = useRef(1);
  const keyRippleTimerRef = useRef<number | null>(null);

  const [isPressed, setIsPressed] = useState(false);
  const pressedRef = useRef(false);
  const checkedRef = useRef(checked);
  // 第 24 轮：布尔标志 → 时间戳窗口。pointercancel / lostpointercapture 结束拖拽时
  // 浏览器不会派生 click，布尔标志残留会吞掉下一次正常点击（开关“点不动一次”）；
  // 改为仅在 CLICK_SUPPRESS_WINDOW_MS 内吞派生 click，并在每次 pointerdown 重置。
  const suppressClickUntilRef = useRef(0);
  // 第 24 轮：WebGL2 不可用时的 CSS 状态层兜底（null = 未探测）
  const [webglSupported, setWebglSupported] = useState<boolean | null>(null);
  // 第 24 轮：prefers-reduced-motion（非必要位移动画弱化）
  const [reducedMotion, setReducedMotion] = useState(false);
  const reducedMotionRef = useRef(false); // 供命令式 restoreTransitions 读取，避免闭包过期
  const dragRef = useRef({
    pointerId: -1,
    startClientX: 0,
    restCenter: TRAVEL_MIN, // 按下时小球视觉中心
    curCenter: TRAVEL_MIN,
    maxAbsDx: 0,
    lastT: 0,
    lastX: 0,
    vx: 0, // px/ms
    dragging: false,
  });

  checkedRef.current = checked;

  const propsRef = useRef({
    mode,
    waveColor,
    sparkleColor,
    sparkleStrength,
    distortionStrength,
    systemUiShape,
    speedMultiplier,
    densityScale,
  });

  useEffect(() => {
    propsRef.current = {
      mode,
      waveColor,
      sparkleColor,
      sparkleStrength,
      distortionStrength,
      systemUiShape,
      speedMultiplier,
      densityScale,
    };
  });

  const startLoop = useCallback(() => {
    if (rafRef.current !== null) return;

    const tick = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        rafRef.current = null;
        return;
      }

      const now = performance.now();
      const sessions = sessionsRef.current;
      // 第 26 轮（用户复核）：状态层圆形扩散同遭 2.5 上采样顶拉糊 —— 40dp 小画布
      // 改按真实 dpr×捏合缩放重建（cap 8），与第 25 轮形变指示器同口径
      const dpr = effectiveRasterDpr(8);
      const pw = Math.round(STATE_LAYER_SIZE * dpr);
      const ph = Math.round(STATE_LAYER_SIZE * dpr);

      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
      }

      const renderer = getSharedRippleRenderer();
      renderer.renderSessions(sessions, STATE_LAYER_SIZE, STATE_LAYER_SIZE, dpr, now);

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, pw, ph);
        if (sessions.length > 0 && renderer.isSupported()) {
          ctx.drawImage(renderer.canvas, 0, 0, pw, ph, 0, 0, pw, ph);
        }
      }

      sessionsRef.current = sessions.filter((s) => !s.finished);
      if (sessionsRef.current.length > 0) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        if (ctx) ctx.clearRect(0, 0, pw, ph);
        rafRef.current = null;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  }, []);

  useEffect(() => {
    // 第 24 轮：探测 WebGL2 可用性与用户减少动态偏好（挂载后一次性 + 监听变更）
    try {
      setWebglSupported(getSharedRippleRenderer().isSupported());
    } catch {
      setWebglSupported(false);
    }
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = () => {
      setReducedMotion(mq.matches);
      reducedMotionRef.current = mq.matches;
    };
    sync();
    mq.addEventListener?.('change', sync);
    return () => {
      mq.removeEventListener?.('change', sync);
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      if (moveRafRef.current !== null) cancelAnimationFrame(moveRafRef.current);
      // 第 24 轮：键盘涟漪释放定时器随组件卸载一并回收
      if (keyRippleTimerRef.current !== null) {
        window.clearTimeout(keyRippleTimerRef.current);
        keyRippleTimerRef.current = null;
      }
    };
  }, []);

  /**
   * 官方同几何约束状态层：40×40 圆形 mask，涟漪从触点（钳制进盒内）生长，
   * maxRadius 保证盖满 40×40 后由 mask 裁形——绝不越过状态层边界。
   */
  const spawnStateLayerRipple = useCallback(
    (pressX: number, pressY: number) => {
      const p = propsRef.current;
      // 与 tick 同口径：session dpr 必须等于渲染循环 dpr，否则逐帧重设缓冲会抖
      const dpr = effectiveRasterDpr(8);
      const inset = checkedRef.current ? 0 : 2;
      const thumbCenter = (checkedRef.current ? TRAVEL_MAX : TRAVEL_MIN) - inset;
      // 触点钳制进 40×40 状态层盒（官方 md-ripple 从触点生长的等价语义）
      const sx = Math.min(Math.max(pressX - (thumbCenter - STATE_LAYER_RADIUS), 0), STATE_LAYER_SIZE);
      const sy = Math.min(Math.max(pressY - (TRACK_H / 2 - STATE_LAYER_RADIUS), 0), STATE_LAYER_SIZE);

      if (sessionsRef.current.length >= AOSP_MAX_RIPPLES) {
        sessionsRef.current.shift();
      }

      const session = new RippleSession(
        nextIdRef.current++,
        {
          mode: p.mode,
          touchX: sx,
          touchY: sy,
          originX: sx,
          originY: sy,
          width: STATE_LAYER_SIZE,
          height: STATE_LAYER_SIZE,
          dpr,
          // framework 模式 auto = hypot(20,20)×2.3 ≈ 65 盖满全盒后由 mask 裁圆；
          // systemui 模式 override×2 = 直径 40，恰好铺满状态层。
          maxRadiusOverride: p.mode === 'framework' ? null : STATE_LAYER_RADIUS,
          color: { ...p.waveColor, a: p.waveColor.a * 0.75 },
          sparkleColor: p.sparkleColor,
          sparkleStrength: p.sparkleStrength,
          distortionStrength: p.distortionStrength,
          systemUiShape: p.systemUiShape === 'rounded_box' ? 'circle' : p.systemUiShape,
          hasMask: true,
          maskRadius: STATE_LAYER_RADIUS,
          maskRadii: [STATE_LAYER_RADIUS, STATE_LAYER_RADIUS, STATE_LAYER_RADIUS, STATE_LAYER_RADIUS],
          densityScale: p.densityScale,
          speedMultiplier: p.speedMultiplier,
        },
        performance.now()
      );

      sessionsRef.current.push(session);
      activeSessionRef.current = session;
      startLoop();
      return session;
    },
    [startLoop]
  );

  const releaseThumbRipple = useCallback(() => {
    if (activeSessionRef.current) {
      activeSessionRef.current.release(performance.now());
      activeSessionRef.current = null;
    }
  }, []);

  /** 拖拽期：命令式关闭过渡（rAF 逐帧合并写 DOM，与滑块方案一致） */
  const disableTransitions = useCallback(() => {
    if (thumbRef.current) thumbRef.current.style.transition = 'none';
    if (canvasRef.current) canvasRef.current.style.transition = 'none';
  }, []);

  const restoreTransitions = useCallback(() => {
    const t = easedTransitions(false, reducedMotionRef.current);
    if (thumbRef.current) thumbRef.current.style.transition = t.thumb;
    if (canvasRef.current) canvasRef.current.style.transition = t.canvas;
  }, []);

  const writeThumbPosition = useCallback((center: number, forChecked: boolean) => {
    const inset = forChecked ? 0 : 2;
    if (thumbRef.current) thumbRef.current.style.left = `${center - inset}px`;
    if (canvasRef.current) canvasRef.current.style.left = `${center - STATE_LAYER_RADIUS}px`;
  }, []);

  const applyDragPosition = useCallback(() => {
    moveRafRef.current = null;
    // 第 24 轮：释放/取消后残留的拖拽 rAF 不得再写 DOM —— 否则会在吸附落位后
    // 下一帧把小球拉回中途位置（快速拖拽+松手的“卡在中途”实错根因）
    if (!pressedRef.current) return;
    writeThumbPosition(dragRef.current.curCenter, checkedRef.current);
  }, [writeThumbPosition]);

  /** 第 24 轮：拖拽/按压结束时统一取消未决的拖拽 rAF，防止覆盖最终位置 */
  const cancelPendingDragRaf = useCallback(() => {
    if (moveRafRef.current !== null) {
      cancelAnimationFrame(moveRafRef.current);
      moveRafRef.current = null;
    }
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (disabled) return;
    if (pressedRef.current) return;
    e.stopPropagation();
    // 第 24 轮：新按压开始即清空上一轮的派生 click 吞掉窗口
    suppressClickUntilRef.current = 0;
    const rect = e.currentTarget.getBoundingClientRect();
    const center = checkedRef.current ? TRAVEL_MAX : TRAVEL_MIN;
    const inset = checkedRef.current ? 0 : 2;
    dragRef.current = {
      pointerId: e.pointerId,
      startClientX: e.clientX,
      restCenter: center - inset,
      curCenter: center - inset,
      maxAbsDx: 0,
      lastT: performance.now(),
      lastX: e.clientX,
      vx: 0,
      dragging: false,
    };
    pressedRef.current = true;
    setIsPressed(true);
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* setPointerCapture 不可用时退化：仍可点击，拖拽在元素外可能丢 */
    }
    spawnStateLayerRipple(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    const d = dragRef.current;
    if (!pressedRef.current || e.pointerId !== d.pointerId) return;
    const now = performance.now();
    const dt = now - d.lastT;
    if (dt > 0) {
      d.vx = (e.clientX - d.lastX) / dt;
      d.lastT = now;
      d.lastX = e.clientX;
    }
    const dx = e.clientX - d.startClientX;
    d.maxAbsDx = Math.max(d.maxAbsDx, Math.abs(dx));
    if (!d.dragging && d.maxAbsDx < DRAG_DEAD_ZONE) return;
    if (!d.dragging) {
      d.dragging = true;
      disableTransitions();
    }
    // 行程边界 + 越界阻尼（30% 橡皮筋），硬限 ±6px 过冲
    const raw = d.restCenter + dx;
    let target = raw;
    if (raw < TRAVEL_MIN) target = TRAVEL_MIN + (raw - TRAVEL_MIN) * 0.3;
    if (raw > TRAVEL_MAX) target = TRAVEL_MAX + (raw - TRAVEL_MAX) * 0.3;
    d.curCenter = Math.min(Math.max(target, TRAVEL_MIN - 6), TRAVEL_MAX + 6);
    if (moveRafRef.current === null) {
      moveRafRef.current = requestAnimationFrame(applyDragPosition);
    }
  };

  const handlePointerUp = (e?: React.PointerEvent<HTMLButtonElement>) => {
    const d = dragRef.current;
    if (!pressedRef.current) return;
    if (e && 'pointerId' in e && e.pointerId !== d.pointerId) return;
    pressedRef.current = false;
    cancelPendingDragRaf();

    releaseThumbRipple();
    restoreTransitions();

    if (d.dragging) {
      // ===== 自动吸附判定 =====
      // 甩动（|v| > 0.35px/ms 且已有位移）按甩动方向定夺；
      // 否则按"投影 80ms 动量后的位置是否越过行程中点"判定。
      let newChecked = checkedRef.current;
      if (Math.abs(d.vx) > FLING_SPEED && Math.abs(d.curCenter - d.restCenter) > 3) {
        newChecked = d.vx > 0;
      } else {
        const projected = d.curCenter + (Math.abs(d.vx) > FLING_SPEED ? d.vx * 80 : 0);
        newChecked = projected > TRAVEL_MID;
      }
      const finalCenter = newChecked ? TRAVEL_MAX : TRAVEL_MIN;
      writeThumbPosition(finalCenter, newChecked); // React 对 style 无 diff 时保证落位
      suppressClickUntilRef.current = performance.now() + CLICK_SUPPRESS_WINDOW_MS;
      setIsPressed(false);
      d.pointerId = -1;
      d.dragging = false;
      if (newChecked !== checkedRef.current) {
        checkedRef.current = newChecked;
        onChange(newChecked);
      }
    } else {
      suppressClickUntilRef.current = 0;
      setIsPressed(false);
      d.pointerId = -1;
    }
  };

  /**
   * 第 24 轮：pointercancel 语义 = 手势中止（浏览器抢去滚动/来电等）。
   * 原实现把 cancel 当 release 处理，会误触发吸附切换；现改为回弹原状态、
   * 不派发 onChange、不吞 click（cancel 无 click 跟随，无需抑制窗口）。
   */
  const handlePointerCancel = (e: React.PointerEvent<HTMLButtonElement>) => {
    const d = dragRef.current;
    if (!pressedRef.current) return;
    if (e.pointerId !== d.pointerId) return;
    pressedRef.current = false;
    cancelPendingDragRaf();
    releaseThumbRipple();
    restoreTransitions();
    if (d.dragging) {
      // 回弹到按压前状态（不做吸附判定）
      writeThumbPosition(d.restCenter, checkedRef.current);
    }
    suppressClickUntilRef.current = 0;
    setIsPressed(false);
    d.pointerId = -1;
    d.dragging = false;
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (disabled) return;
    // 拖拽松手后浏览器仍会派发 click：已在 pointerup 里判定过，仅在时间窗内吞掉
    // 防二次切换；pointercancel（无 click 跟随）不再残留标志污染后续点击
    if (performance.now() < suppressClickUntilRef.current) {
      suppressClickUntilRef.current = 0;
      return;
    }
    onChange(!checked);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (disabled) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.stopPropagation();
      // 第 24 轮：长按连发（key repeat）不再重复生成涟漪 session；
      // 状态切换仍交给浏览器原生 click（与官方 md-switch 行为一致）
      if (e.repeat) return;
      // 涟漪生长点从轨道中心改为小球实际中心（状态层盒中心，与官方
      // “涟漪生长于贴着小球的状态层”语义一致）
      const center = (checkedRef.current ? TRAVEL_MAX : TRAVEL_MIN) - (checkedRef.current ? 0 : 2);
      const s = spawnStateLayerRipple(center, TRACK_H / 2);
      if (keyRippleTimerRef.current !== null) window.clearTimeout(keyRippleTimerRef.current);
      keyRippleTimerRef.current = window.setTimeout(() => {
        s.release(performance.now());
        keyRippleTimerRef.current = null;
      }, 120);
    }
  };

  // ===== 渲染参数（官方 token 对照见顶部注释）=====
  const thumbSize = isPressed ? 28 : checked || showIcons ? 24 : 16; // pressed-handle-*=28
  const restCenter = (checked ? TRAVEL_MAX : TRAVEL_MIN) - (checked ? 0 : 2);
  const ease = easedTransitions(isPressed, reducedMotion);
  // 用户要求的按压微放大（叠加官方 28px 形变）；reduced-motion 下关闭
  const scale = isPressed && !reducedMotion ? 1.05 : 1;
  // 第 24 轮：WebGL2 不可用时的 CSS 状态层兜底（官方 pressed-state-layer-opacity 0.12）
  const showCssStateLayer = isPressed && webglSupported === false;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      onLostPointerCapture={() => handlePointerUp()}
      onKeyDown={handleKeyDown}
      onClick={handleClick}
      // 第 24 轮：移动端长按/拖拽期屏蔽长按弹莱单、文本选择与 iOS 呼出气泡
      onContextMenu={(e) => e.preventDefault()}
      style={{
        width: `${TRACK_W}px`,
        height: `${TRACK_H}px`,
        backgroundColor: checked ? accentHex : inactiveTrackHex,
        borderColor: !checked && outlineHex ? outlineHex : undefined,
        touchAction: 'none',
        WebkitTouchCallout: 'none',
        userSelect: 'none',
        cursor: disabled ? 'not-allowed' : isPressed ? 'grabbing' : 'grab',
      }}
      className={`relative inline-flex shrink-0 items-center rounded-full transition-colors duration-200 ease-[cubic-bezier(0.2,0,0,1)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--md-sys-color-primary)] ${
        disabled ? 'opacity-40 cursor-not-allowed' : ''
      } ${
        checked
          ? 'border-0'
          : `border-2 ${inactiveTrackHex ? '' : 'bg-slate-200 dark:bg-slate-800'} ${outlineHex ? '' : 'border-slate-500 dark:border-slate-400'}`
      }`}
    >
      {/* 官方同几何约束状态层：40×40 圆形（state-layer-size 40 · shape full），
          随小球移动（官方 md-ripple 挂在 handle-container 内），WebGL2 星斑着色器 +
          圆形 mask 裁形。拖拽期过渡由命令式接管。 */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        style={{
          left: `${restCenter - STATE_LAYER_RADIUS}px`,
          // 第 26 轮（用户复核）：top 改 calc(50% - 20px) —— 绝对定位包含块是 padding box，
          // unchecked 态的 border-2 会把固定 top 值整体压低 2px（实测圆心 18 vs 小球 16），
          // 且在 checked 翻转瞬间跳变 2px（"松手先往下跳一下再回去"实根因）；
          // 50% 同样以 padding box 计，减去半径后圆心恒与 border-box 中心重合，两种状态、
          // 翻转前后都严格居中
          top: `calc(50% - ${STATE_LAYER_RADIUS}px)`,
          width: `${STATE_LAYER_SIZE}px`,
          height: `${STATE_LAYER_SIZE}px`,
          transition: ease.canvas,
        }}
        className="pointer-events-none absolute z-20"
      />

      {/* 第 24 轮：WebGL2 不可用时的 CSS 状态层兜底 —— 几何与 WebGL 路径一致
          （40×40 圆、贴小球），按压淡入官方 pressed-state-layer-opacity 0.12，
          不再出现“按下无任何视觉反馈”的降级死区。 */}
      {showCssStateLayer && (
        <span
          aria-hidden="true"
          style={{
            left: `${restCenter - STATE_LAYER_RADIUS}px`,
            // 同 canvas：calc(50% - 半径) 免疫 border-2 包含块偏移
            top: `calc(50% - ${STATE_LAYER_RADIUS}px)`,
            width: `${STATE_LAYER_SIZE}px`,
            height: `${STATE_LAYER_SIZE}px`,
            backgroundColor: checked ? onPrimaryHex : (outlineHex ?? thumbUncheckedHex ?? '#1D1B20'),
            opacity: 0.12,
          }}
          className="pointer-events-none absolute z-20 rounded-full"
        />
      )}

      {/* Expressive Morphing Handle / Thumb（官方 24→28 按压形变 + 1.05 微放大） */}
      <span
        ref={thumbRef}
        aria-hidden="true"
        style={{
          width: `${thumbSize}px`,
          height: `${thumbSize}px`,
          left: `${restCenter}px`,
          backgroundColor: checked ? onPrimaryHex : thumbUncheckedHex,
          color: checked ? accentHex : thumbUncheckedIconHex,
          transform: `translate(-50%, -50%) scale(${scale})`,
          transition: ease.thumb,
        }}
        className={`pointer-events-none absolute top-1/2 z-30 flex items-center justify-center rounded-full shadow-xs ${
          checked
            ? ''
            : `${thumbUncheckedHex ? '' : 'bg-slate-600 dark:bg-slate-300'} ${thumbUncheckedIconHex ? '' : 'text-slate-100 dark:text-slate-900'}`
        }`}
      >
        {/* 第 28 轮（用户实机对照"小球勾叉大一圈"）：双重根因修复 ——
            ① 实根因在图标渲染器：size 经 inline style（默认 24px）写入，
            内联样式压过本处的 h-4 w-4，小球勾叉自第 27 轮起实际以 24px
            盒渲染（应为 16dp）；渲染器已改 width/height 属性化（lucide
            同款语义，类名可覆盖），本处 h-4 w-4 恢复真实 16dp 盒。
            ② 字形档位经真机逐像素取证：Android 16 Expressive 系统设置
            开关截图实测 X 宽/小球直径 = 0.355～0.387，与官方默认 close
            字形 @16dp 盒（8.77/24 = 0.365）吻合；check_small/close_small
            小号变体（6.13/24 = 0.256）明显小于实机——小球维持官方默认
            check/close 字形，官方 16dp 图标盒不变（m3.material.io switch
            specs：icon size 16dp 选中/未选中同值）。 */}
        {showIcons &&
          (checked ? (
            <Check className="h-4 w-4" aria-hidden="true" />
          ) : (
            <X className="h-4 w-4" aria-hidden="true" />
          ))}
      </span>
    </button>
  );
};
