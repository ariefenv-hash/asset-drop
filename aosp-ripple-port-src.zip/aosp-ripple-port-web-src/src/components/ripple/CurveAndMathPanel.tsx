"use client";
import React, { useMemo } from 'react';
import { M3ThemeTokens } from '../../aosp/dynamicColor';
import {
  AOSP_ENTER_ANIM_DURATION,
  AOSP_EXIT_ANIM_DURATION,
  AOSP_RIPPLE_VIEW_DURATION,
  AospRippleEngineMode,
  FrameworkUniformSnapshot,
} from '../../aosp/RippleEngine';
import {
  FAST_OUT_SLOW_IN,
  LINEAR_INTERPOLATOR,
  STANDARD_INTERPOLATOR,
} from '../../aosp/interpolators';

interface CurveAndMathPanelProps {
  mode: AospRippleEngineMode;
  telemetry: FrameworkUniformSnapshot | null;
  theme: M3ThemeTokens;
}

function subProgress(start: number, end: number, p: number): number {
  const sub = Math.min(Math.max(p, start), end);
  return (sub - start) / (end - start);
}

export const CurveAndMathPanel: React.FC<CurveAndMathPanelProps> = ({
  mode,
  telemetry,
  theme,
}) => {
  const activeMode = telemetry?.mode ?? mode;
  const totalMs =
    activeMode === 'systemui'
      ? AOSP_RIPPLE_VIEW_DURATION
      : AOSP_ENTER_ANIM_DURATION + AOSP_EXIT_ANIM_DURATION;

  const W = 640;
  const H = 220;
  const PAD_L = 44;
  const PAD_R = 18;
  const PAD_T = 20;
  const PAD_B = 34;
  const plotW = W - PAD_L - PAD_R;
  const plotH = H - PAD_T - PAD_B;

  const paths = useMemo(() => {
    const steps = 110;
    const progPts: string[] = [];
    const sparkleAlphaPts: string[] = [];
    const waveAlphaPts: string[] = [];

    for (let i = 0; i <= steps; i++) {
      const tMs = (i / steps) * totalMs;
      let p = 0;
      let sparkleEnv = 0;
      let waveEnv = 0;

      if (activeMode === 'systemui') {
        const rawP = tMs / AOSP_RIPPLE_VIEW_DURATION;
        p = STANDARD_INTERPOLATOR(rawP);
        sparkleEnv = Math.min(subProgress(0, 0.1, rawP), 1 - subProgress(0.4, 1.0, rawP));
        waveEnv = Math.min(subProgress(0, 0.1, rawP), 1 - subProgress(0.3, 1.0, rawP));
      } else {
        if (tMs <= AOSP_ENTER_ANIM_DURATION) {
          p = 0.5 * FAST_OUT_SLOW_IN(tMs / AOSP_ENTER_ANIM_DURATION);
        } else {
          p =
            0.5 +
            0.5 *
              LINEAR_INTERPOLATOR(
                (tMs - AOSP_ENTER_ANIM_DURATION) / AOSP_EXIT_ANIM_DURATION
              );
        }

        const fadeIn = subProgress(0, 0.13, p);
        const fadeOutNoise = subProgress(0.4, 0.5, p);
        const fadeOutRipple = subProgress(0.4, 1.0, p);

        sparkleEnv = Math.min(fadeIn, 1 - fadeOutNoise);
        waveEnv = Math.min(fadeIn, 1 - fadeOutRipple);
      }

      const x = PAD_L + (tMs / totalMs) * plotW;
      const yProg = PAD_T + (1 - p) * plotH;
      const ySparkle = PAD_T + (1 - sparkleEnv) * plotH;
      const yWave = PAD_T + (1 - waveEnv) * plotH;

      progPts.push(`${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${yProg.toFixed(1)}`);
      sparkleAlphaPts.push(
        `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${ySparkle.toFixed(1)}`
      );
      waveAlphaPts.push(`${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${yWave.toFixed(1)}`);
    }

    return {
      progPath: progPts.join(' '),
      sparklePath: sparkleAlphaPts.join(' '),
      wavePath: waveAlphaPts.join(' '),
    };
  }, [activeMode, plotH, plotW, totalMs]);

  const playheadX = useMemo(() => {
    if (!telemetry) return null;
    let tMs: number;
    if (activeMode === 'systemui') {
      tMs = Math.min(Math.max(telemetry.elapsedMs, 0), totalMs);
    } else if (telemetry.stage === 'ENTER') {
      tMs = Math.min(Math.max(telemetry.elapsedMs, 0), AOSP_ENTER_ANIM_DURATION);
    } else if (telemetry.stage === 'HOLD') {
      tMs = AOSP_ENTER_ANIM_DURATION;
    } else {
      const exitRatio = Math.max(0, (telemetry.progress - 0.5) / 0.5);
      tMs = AOSP_ENTER_ANIM_DURATION + exitRatio * AOSP_EXIT_ANIM_DURATION;
    }
    return PAD_L + (Math.min(Math.max(tMs, 0), totalMs) / totalMs) * plotW;
  }, [activeMode, telemetry, plotW, totalMs]);

  const enterEndX = PAD_L + (AOSP_ENTER_ANIM_DURATION / totalMs) * plotW;
  const xTicks =
    activeMode === 'systemui' ? [0, 150, 300, 500, 750] : [0, 200, 450, 650, 825];

  return (
    <section id="curves" className="scroll-mt-24 space-y-6">
      <div>
        <h2 className="font-display text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          时间曲线与着色器数学管线
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          对照 AOSP <code className="font-mono text-xs">RippleAnimationSession.java</code> 与{' '}
          <code className="font-mono text-xs">RippleShader.java / .kt</code> 的精确分段插值与包络函数。
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200">
              {activeMode === 'systemui'
                ? 'SystemUI STANDARD (0.2, 0, 0, 1) 包络曲线（时长按 RippleView 默认 1750ms）'
                : 'Framework 入场 (450ms) / 退场 (375ms) 包络曲线'}
            </span>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <span
                  className="h-0.5 w-3.5 inline-block"
                  style={{ backgroundColor: theme.primary }}
                />
                in_progress
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-0.5 w-3.5 bg-amber-500 inline-block" />
                {activeMode === 'systemui' ? 'in_fadeSparkle' : 'sparkle alpha'}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-0.5 w-3.5 bg-emerald-600 dark:bg-emerald-400 inline-block" />
                {activeMode === 'systemui' ? 'in_fadeRing' : 'wave fade'}
              </span>
            </div>
          </div>

          <svg
            viewBox={`0 0 ${W} ${H}`}
            className="w-full h-auto overflow-visible"
            role="img"
            aria-label="AOSP Ripple progress and alpha envelope curves"
          >
            {[0, 0.25, 0.5, 0.75, 1.0].map((v) => {
              const y = PAD_T + (1 - v) * plotH;
              return (
                <g key={v}>
                  <line
                    x1={PAD_L}
                    y1={y}
                    x2={W - PAD_R}
                    y2={y}
                    stroke="currentColor"
                    className="text-slate-200 dark:text-slate-800"
                    strokeWidth={1}
                  />
                  <text
                    x={PAD_L - 8}
                    y={y + 3.5}
                    textAnchor="end"
                    className="fill-slate-400 font-mono text-[10px]"
                  >
                    {v.toFixed(2)}
                  </text>
                </g>
              );
            })}

            {activeMode === 'framework' && (
              <>
                <line
                  x1={enterEndX}
                  y1={PAD_T}
                  x2={enterEndX}
                  y2={PAD_T + plotH}
                  stroke="currentColor"
                  className="text-slate-300 dark:text-slate-700"
                  strokeDasharray="4 4"
                  strokeWidth={1}
                />
                <text
                  x={enterEndX}
                  y={PAD_T - 6}
                  textAnchor="middle"
                  className="fill-slate-500 dark:fill-slate-400 font-mono text-[10px]"
                >
                  450ms (Release Gate)
                </text>
              </>
            )}

            {xTicks.map((ms) => {
              const x = PAD_L + (ms / totalMs) * plotW;
              return (
                <text
                  key={ms}
                  x={x}
                  y={H - 8}
                  textAnchor="middle"
                  className="fill-slate-400 font-mono text-[10px]"
                >
                  {ms}ms
                </text>
              );
            })}

            <path
              d={paths.wavePath}
              fill="none"
              stroke="#059669"
              strokeWidth={2}
              strokeLinecap="round"
            />
            <path
              d={paths.sparklePath}
              fill="none"
              stroke="#f59e0b"
              strokeWidth={2}
              strokeLinecap="round"
            />
            <path
              d={paths.progPath}
              fill="none"
              stroke={theme.primary}
              strokeWidth={2.5}
              strokeLinecap="round"
            />

            {playheadX !== null && (
              <g>
                <line
                  x1={playheadX}
                  y1={PAD_T}
                  x2={playheadX}
                  y2={PAD_T + plotH}
                  stroke="#e11d48"
                  strokeWidth={1.5}
                />
                <circle
                  cx={playheadX}
                  cy={PAD_T + (1 - (telemetry?.progress ?? 0)) * plotH}
                  r={4}
                  fill="#e11d48"
                />
              </g>
            )}
          </svg>
        </div>

        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              01. 三角分布白噪声 (triangleNoise)
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              将像素按 <code className="font-mono">in_noiseScale = 2.1 / resolution</code> 量化后采样{' '}
              <code className="font-mono">fract(xy * 95.4307) + fract(xy * 75.04961) - 1.0</code>
              ，并在 4 层相位阈值中叠加闪耀颗粒。
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              02. 三层旋转圆网格湍流 (turbulence)
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              以 <code className="font-mono">0.17 / 0.20 / 0.275</code> 晶胞尺寸叠加三层旋转{' '}
              <code className="font-mono">circle_grid</code>，在 7000ms 循环中形成自然呼吸感的光斑调制。
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              03. 中心迁移与环形边缘 (softRing)
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              圆心随 <code className="font-mono">mix(in_touch, in_origin, saturate(in_progress * 2.0))</code>{' '}
              在入场期由触点平滑收敛至组件几何中心，颗粒仅在环形边界内显现。
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              04. 预乘 Alpha 合成 (SkBlendMode::kSrcOver)
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              输出与 Skia 一致的预乘 RGBA（<code className="font-mono">gl.ONE, gl.ONE_MINUS_SRC_ALPHA</code>
              ），确保半透明白色星斑叠加彩色基底时不出现暗边。
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
