"use client";
/**
 * 可变字体多字体多轴实验室 · 第 30 轮重构（用户方案：网络搜索更多选择 + 中文多轴字体加入）
 * ============================================================
 * 【第 30 轮字体清单（全部真实文件/CDN 考据，fvar 逐轴 fontTools 实测）】
 *   英文（本地 /fonts/，google/fonts ofl 原文件）：
 *     - Google Sans Flex v5.000;[cedf1e9]：wght 1–1000(def 400) · opsz 1–144(def 18)
 *       · wdth 25–151(def 100) · ROND 0–100(def 0) · slnt -10–0(def 0) —— 5 轴
 *       ※ 考据修正：旧实验室硬编码 opsz 6–144/def 36，本地 fvar 实测为 1–144/def 18
 *     - Roboto Flex：13 轴（wght/opsz/wdth/slnt/GRAD/XOPQ/YOPQ/XTRA/YTUC/YTLC/YTAS/YTDE/YTFI）
 *     - Recursive：5 轴（MONO/CASL/wght/slnt/CRSV）
 *     - Fraunces：4 轴（opsz/wght/SOFT/WONK）
 *   中文：
 *     - 文渊圆体 SC VF / 文渊宋体 SC VF / 思源宋体 CJK（zeoseven fontsapi 414/415/285，
 *       wght 单轴，第 20 轮原方案保留）
 *     - MiSans VF（小米官方 VF，jsDelivr npm misans@5.0.0 分片 CSS；wght 150–700(def 330)
 *       为字体内部刻度，与 web 标准刻度不同——Thin=150…Heavy=700，混用时注意）
 *     - 资源圆体 CN VF（Resource Han Rounded CN VF v1.910，OFL，思源黑体衍生；
 *       wght 200–900(def 200) + ROND 0–100(def 100) 双轴，33 命名实例——
 *       本页第一枚多轴中文可变字体；65MB CFF2 原文件经 fontTools 子集化
 *       （GB2312 一级 3755 字 + ASCII + 常用标点 = 3913 字形）为 2.4MB woff2 本地内置）
 *   【考据排除记录】霞鹜文楷 v1.530：官方仅 3 静态字重（axes=[]，fontsource 元数据
 *     + GitHub release 核实），坊间"文楷 VF"说法不成立；OPPO Sans 2.0 的可变字体
 *     仅存在于 ColorOS 系统内，官网未提供 VF 下载；阿里巴巴普惠体 3.0 仅有静态字重。
 * 【混排机制】不变：font-family 栈英文在前汉字回落；font-weight 同时驱动中英 wght；
 *   font-variation-settings 仅写当前选中字体的专属轴（无该轴的字体自动忽略）。
 * 【全局应用】"应用到全站"写 :root 的 --vf-en / --vf-cn / --vf-rond（globals.css
 *   的 --font-display / --font-sans 栈引用之），localStorage('aosp-vf-global') 持久化。
 *   专属轴仍不全局化（覆盖 font-weight 会毁掉组件语义字重——取舍说明见 globals.css）。
 * 【滑块】全部 AospExpressiveSlider（带手柄；全站禁止默认圆点滑块）。
 * ============================================================
 */
import React, { useEffect, useMemo, useState } from 'react';
import { RotateCcw, Type } from '@/components/icons';
import { M3ThemeTokens } from '../../aosp/dynamicColor';
import { AospExpressiveSlider } from './AospExpressiveSlider';

/** 可变轴定义（全部取自真实字体文件 fvar 表，min/def/max 逐值一致） */
export interface AxisDef {
  key: string;
  label: string;
  min: number;
  max: number;
  def: number;
  step: number;
  note: string;
}

/** 英文可变字体（本地内置，fvar 实测） */
export interface EnFontDef {
  id: string;
  label: string;
  family: string;
  axes: AxisDef[]; // 不含 wght（wght 由 font-weight 中英联动驱动）
  source: string;
}

/** 中文可变字体（CDN 分片或本地子集） */
export interface CnFontDef {
  id: string;
  label: string;
  family: string | null;
  axes: AxisDef[]; // 中文专属轴（如资源圆体 ROND）
  source: string;
  badge?: string; // 「双轴」等标注
}

const EN_FONTS: EnFontDef[] = [
  {
    id: 'gsf',
    label: 'Google Sans Flex（5 轴）',
    family: 'Google Sans Flex',
    axes: [
      { key: 'opsz', label: '视觉尺寸 opsz', min: 1, max: 144, def: 18, step: 1, note: '1–144，Caption→Display（fvar 实测修正：旧值 6 起不实）' },
      { key: 'ROND', label: '圆角 ROND', min: 0, max: 100, def: 0, step: 1, note: '0–100，直角→全圆角字形' },
      { key: 'wdth', label: '字宽 wdth', min: 25, max: 151, def: 100, step: 1, note: '25–151，Condensed→Wide' },
      { key: 'slnt', label: '倾斜 slnt', min: -10, max: 0, def: 0, step: 0.5, note: '-10–0，罗马体→斜体' },
    ],
    source: '本地 /fonts/GoogleSansFlex.ttf · google/fonts v26 · Version 5.000;[cedf1e9]',
  },
  {
    id: 'robotoflex',
    label: 'Roboto Flex（13 轴）',
    family: 'Roboto Flex',
    axes: [
      { key: 'opsz', label: '视觉尺寸 opsz', min: 8, max: 144, def: 14, step: 1, note: '8–144' },
      { key: 'wdth', label: '字宽 wdth', min: 25, max: 151, def: 100, step: 1, note: '25–151' },
      { key: 'slnt', label: '倾斜 slnt', min: -10, max: 0, def: 0, step: 0.5, note: '-10–0' },
      { key: 'GRAD', label: '笔画梯度 GRAD', min: -200, max: 150, def: 0, step: 1, note: '-200–150，粗细微调不改字宽' },
      { key: 'XOPQ', label: '大写横向 XOPQ', min: 27, max: 175, def: 96, step: 1, note: '27–175' },
      { key: 'YOPQ', label: '小写竖向 YOPQ', min: 25, max: 135, def: 79, step: 1, note: '25–135' },
      { key: 'XTRA', label: '横向比例 XTRA', min: 323, max: 603, def: 468, step: 1, note: '323–603' },
      { key: 'YTUC', label: '大写高度 YTUC', min: 528, max: 760, def: 712, step: 1, note: '528–760' },
      { key: 'YTLC', label: '小写高度 YTLC', min: 416, max: 570, def: 514, step: 1, note: '416–570' },
      { key: 'YTAS', label: '上伸部 YTAS', min: 649, max: 854, def: 750, step: 1, note: '649–854' },
      { key: 'YTDE', label: '下伸部 YTDE', min: -305, max: -98, def: -203, step: 1, note: '-305–-98' },
      { key: 'YTFI', label: '字怀系数 YTFI', min: 560, max: 788, def: 738, step: 1, note: '560–788' },
    ],
    source: '本地 /fonts/roboto-flex.ttf · google/fonts ofl/robotoflex（fvar 13 轴实测）',
  },
  {
    id: 'recursive',
    label: 'Recursive（5 轴）',
    family: 'Recursive',
    axes: [
      { key: 'MONO', label: '等宽 MONO', min: 0, max: 1, def: 0, step: 0.01, note: '0–1，比例体↔等宽' },
      { key: 'CASL', label: '手写 CASL', min: 0, max: 1, def: 0, step: 0.01, note: '0–1，Linear↔Casual' },
      { key: 'CRSV', label: '连笔 CRSV', min: 0, max: 1, def: 0.5, step: 0.01, note: '0–1，直角↔斜切连笔' },
      { key: 'slnt', label: '倾斜 slnt', min: -15, max: 0, def: 0, step: 0.5, note: '-15–0' },
    ],
    source: '本地 /fonts/recursive.ttf · google/fonts ofl/recursive（arrowtype Recursive 1.085）',
  },
  {
    id: 'fraunces',
    label: 'Fraunces（4 轴）',
    family: 'Fraunces',
    axes: [
      { key: 'opsz', label: '视觉尺寸 opsz', min: 9, max: 144, def: 9, step: 1, note: '9–144' },
      { key: 'SOFT', label: '圆润 SOFT', min: 0, max: 100, def: 0, step: 1, note: '0–100，方角↔软角' },
      { key: 'WONK', label: '怪字 WONK', min: 0, max: 1, def: 1, step: 1, note: '0–1，常规↔歪斜个性字形' },
    ],
    source: '本地 /fonts/fraunces.ttf · google/fonts ofl/fraunces（Undercase Type）',
  },
];

const CN_FONTS: CnFontDef[] = [
  {
    id: 'wenyuan-rounded',
    label: '文渊圆体 SC（圆润现代）',
    family: 'WenYuan Rounded SC VF',
    axes: [],
    source: 'zeoseven fontsapi 414 · 471 分片 · wght 100–900',
  },
  {
    id: 'wenyuan-serif',
    label: '文渊宋体 SC（衬线人文）',
    family: 'WenYuan Serif SC VF',
    axes: [],
    source: 'zeoseven fontsapi 415 · 411 分片 · wght',
  },
  {
    id: 'noto-serif-cjk',
    label: '思源宋体 Variable（经典出版）',
    family: 'Noto Serif CJK',
    axes: [],
    source: 'zeoseven fontsapi 285 · 672 分片 · wght',
  },
  {
    id: 'misans-vf',
    label: 'MiSans VF（小米官方）',
    family: 'MiSans VF',
    axes: [],
    badge: '单轴 · 非标刻度',
    source: 'jsDelivr npm misans@5.0.0 MiSansVF.min.css · wght 150–700(def 330) 内部刻度：Thin=150 Light=250 Regular=330 Medium=380 Demibold=450 Semibold=520 Bold=630 Heavy=700（fontTools 分片 fvar 实测）',
  },
  {
    id: 'rhr',
    label: '资源圆体 CN VF（双轴！）',
    family: 'Resource Han Rounded CN VF',
    axes: [
      { key: 'ROND-cn', label: '中文圆角 ROND', min: 0, max: 100, def: 100, step: 1, note: '0–100，思源黑体直角→全圆角（v1.910 fvar 实测）' },
    ],
    badge: '双轴 wght+ROND',
    source: '本地 /fonts/ResourceHanRoundedCN-VF-Subset.woff2 · CyanoHao/Resource-Han-Rounded v1.910（CFF2 VF，OFL；65MB 原件 fontTools 子集化 3913 字形→2.4MB；fvar：wght 200–900(def 200) + ROND 0–100(def 100)，33 命名实例）',
  },
  {
    id: 'none',
    label: '不搭配中文（仅英文可变）',
    family: null,
    axes: [],
    source: '',
  },
];

const W_GSF: AxisDef = { key: 'wght', label: '中英联动字重 wght', min: 1, max: 1000, def: 400, step: 1, note: '中英 VF 同受 font-weight 驱动' };

/** 混搭预设（第 20 轮用户方案 3 条保留 + 第 30 轮新 4 条） */
interface MixedPreset {
  label: string;
  en: string;
  cn: string;
  wght: number;
  enAxes: Record<string, number>;
  cnAxes?: Record<string, number>;
}
const MIXED_PRESETS: MixedPreset[] = [
  {
    label: '预设 1 · 圆润未来 UI（GSF 全圆 + 文渊圆体）',
    en: 'gsf', cn: 'wenyuan-rounded', wght: 550,
    enAxes: { opsz: 36, ROND: 100, wdth: 100, slnt: 0 },
  },
  {
    label: '预设 2 · 设计杂志混搭（GSF 宽体 + 文渊宋体）',
    en: 'gsf', cn: 'wenyuan-serif', wght: 500,
    enAxes: { opsz: 72, ROND: 0, wdth: 114, slnt: 0 },
  },
  {
    label: '预设 3 · 高密度窄体海报（wdth 65 + 750 粗体）',
    en: 'gsf', cn: 'wenyuan-rounded', wght: 750,
    enAxes: { opsz: 60, ROND: 20, wdth: 65, slnt: -4 },
  },
  {
    label: '预设 4 · 系统级双圆角（GSF 全圆 × 资源圆体全圆）',
    en: 'gsf', cn: 'rhr', wght: 550,
    enAxes: { opsz: 36, ROND: 100, wdth: 100, slnt: 0 },
    cnAxes: { 'ROND-cn': 100 },
  },
  {
    label: '预设 5 · 直角工程风（GSF 直角 × 资源圆体直角）',
    en: 'gsf', cn: 'rhr', wght: 650,
    enAxes: { opsz: 24, ROND: 0, wdth: 88, slnt: 0 },
    cnAxes: { 'ROND-cn': 0 },
  },
  {
    label: '预设 6 · Roboto Flex 微调（GRAD -25 细节控）',
    en: 'robotoflex', cn: 'rhr', wght: 480,
    enAxes: { opsz: 40, wdth: 106, slnt: 0, GRAD: -25, XOPQ: 96, YOPQ: 79, XTRA: 468, YTUC: 712, YTLC: 514, YTAS: 750, YTDE: -203, YTFI: 738 },
    cnAxes: { 'ROND-cn': 60 },
  },
  {
    label: '预设 7 · Recursive 手写速记（CASL 1 + MONO 0.6）',
    en: 'recursive', cn: 'wenyuan-rounded', wght: 460,
    enAxes: { MONO: 0.6, CASL: 1, CRSV: 1, slnt: 0 },
  },
];

/** GSF 单飞轴预设（第 12 轮历史保留，仅作用于 GSF） */
const GSF_ENGLISH_PRESETS: { label: string; axes: Record<string, number>; wght: number }[] = [
  { label: 'Regular', axes: { opsz: 18, ROND: 0, wdth: 100, slnt: 0 }, wght: 400 },
  { label: 'Hairline', axes: { opsz: 18, ROND: 0, wdth: 100, slnt: 0 }, wght: 1 },
  { label: 'Black', axes: { opsz: 18, ROND: 0, wdth: 100, slnt: 0 }, wght: 1000 },
  { label: 'Display', axes: { opsz: 144, ROND: 0, wdth: 100, slnt: 0 }, wght: 640 },
  { label: 'Caption', axes: { opsz: 6, ROND: 0, wdth: 100, slnt: 0 }, wght: 430 },
  { label: 'Condensed', axes: { opsz: 18, ROND: 0, wdth: 62, slnt: 0 }, wght: 560 },
  { label: 'Wide', axes: { opsz: 18, ROND: 0, wdth: 151, slnt: 0 }, wght: 480 },
  { label: 'Rounded', axes: { opsz: 18, ROND: 100, wdth: 100, slnt: 0 }, wght: 540 },
  { label: 'Slanted', axes: { opsz: 18, ROND: 0, wdth: 100, slnt: -10 }, wght: 500 },
];

const VF_LS_KEY = 'aosp-vf-global';

const MIXED_BODY_TEXT =
  '在这段混排正文里，所有的英文单词如 Variable Fonts、版本号 Android 17 以及数字 1234567890，' +
  '都会自动使用选定的英文可变字体渲染；而中文段落的呼吸感与笔画粗细，则由选定的中文可变字体无缝承接。';

const enDefaults = (enId: string): Record<string, number> => {
  const f = EN_FONTS.find((x) => x.id === enId)!;
  return Object.fromEntries(f.axes.map((a) => [a.key, a.def]));
};

interface VariableFontPlaygroundProps {
  theme: M3ThemeTokens;
}

export const VariableFontPlayground: React.FC<VariableFontPlaygroundProps> = ({ theme }) => {
  const [enId, setEnId] = useState('gsf');
  const [cnId, setCnId] = useState('wenyuan-rounded');
  const [wght, setWght] = useState(400);
  const [enAxes, setEnAxes] = useState<Record<string, Record<string, number>>>(() =>
    Object.fromEntries(EN_FONTS.map((f) => [f.id, enDefaults(f.id)])),
  );
  const [cnAxes, setCnAxes] = useState<Record<string, number>>(() => ({ 'ROND-cn': 100 }));
  const [fontSize, setFontSize] = useState(56);
  const [text, setText] = useState('Hello 2026，探索 Material You 与东方字体的交融之美。');
  const [fontStatus, setFontStatus] = useState<'loading' | 'ready' | 'fail'>('loading');
  const [applied, setApplied] = useState<{ en: string; cn: string | null; rond: number } | null>(null);

  const enFont = EN_FONTS.find((f) => f.id === enId)!;
  const cnFont = CN_FONTS.find((f) => f.id === cnId)!;

  /* 中英 wght 轴范围的交集（真实 fvar 实测）：MiSans 内部刻度 150–700、
     资源圆体 200–900、Recursive 300–1000、Fraunces 100–900——交集即双方
     同时可达的真实字重区间，超出部分不提供（诚实呈现） */
  const EN_WGHT: Record<string, [number, number]> = {
    gsf: [1, 1000], robotoflex: [100, 1000], recursive: [300, 1000], fraunces: [100, 900],
  };
  const CN_WGHT: Record<string, [number, number]> = {
    'wenyuan-rounded': [100, 900], 'wenyuan-serif': [100, 900], 'noto-serif-cjk': [200, 900],
    'misans-vf': [150, 700], rhr: [200, 900], none: [1, 1000],
  };
  const wghtMin = Math.max(EN_WGHT[enId][0], CN_WGHT[cnId][0]);
  const wghtMax = Math.min(EN_WGHT[enId][1], CN_WGHT[cnId][1]);

  /* 换字体后把 wght 铰回交集区间（保留用户已调值当仍合法） */
  useEffect(() => {
    setWght((w) => Math.min(wghtMax, Math.max(wghtMin, w)));
  }, [wghtMin, wghtMax]);

  const variationCss = useMemo(() => {
    const parts = Object.entries(enAxes[enId]).map(([k, v]) => `'${k.replace('-cn', '')}' ${v}`);
    if (cnFont.family === 'Resource Han Rounded CN VF') {
      parts.push(`'ROND' ${cnAxes['ROND-cn'] ?? 100}`);
    }
    return parts.join(', ');
  }, [enAxes, enId, cnFont, cnAxes]);

  const familyCss = useMemo(() => {
    const stack: string[] = [`'${enFont.family}'`];
    if (cnFont.family) stack.push(`'${cnFont.family}'`);
    stack.push('sans-serif');
    return stack.join(', ');
  }, [enFont, cnFont]);

  /* 选中中文字体的分片加载探测（本地子集与 CDN 均走 document.fonts） */
  useEffect(() => {
    if (!cnFont.family) {
      setFontStatus('ready');
      return;
    }
    let alive = true;
    setFontStatus('loading');
    document.fonts
      .load(`16px "${cnFont.family}"`, '字混排 Variable 资源圆体MiSans')
      .then((faces) => {
        if (alive) setFontStatus(faces.length > 0 ? 'ready' : 'fail');
      })
      .catch(() => {
        if (alive) setFontStatus('fail');
      });
    return () => {
      alive = false;
    };
  }, [cnFont]);

  /* 挂载恢复"应用到全站"的持久化选择（含第 30 轮新增 --vf-en） */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(VF_LS_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as { en?: string; cn: string | null; rond: number };
      const root = document.documentElement;
      if (saved.en && EN_FONTS.some((f) => f.family === saved.en)) {
        root.style.setProperty('--vf-en', `'${saved.en}'`);
      }
      if (saved.cn) {
        root.style.setProperty('--vf-cn', `'${saved.cn}'`);
        const hit = CN_FONTS.find((f) => f.family === saved.cn);
        if (hit) setCnId(hit.id);
      }
      if (typeof saved.rond === 'number') {
        root.style.setProperty('--vf-rond', String(saved.rond));
        setEnAxes((p) => ({ ...p, gsf: { ...p.gsf, ROND: saved.rond } }));
      }
      setApplied({ en: saved.en ?? 'Google Sans Flex', cn: saved.cn ?? null, rond: saved.rond });
    } catch {
      /* 忽略损坏的持久化数据 */
    }
  }, []);

  const setAxis = (key: string, value: number) =>
    setEnAxes((p) => ({ ...p, [enId]: { ...p[enId], [key]: value } }));

  const resetAll = () => {
    setEnId('gsf');
    setCnId('wenyuan-rounded');
    setWght(400);
    setEnAxes(Object.fromEntries(EN_FONTS.map((f) => [f.id, enDefaults(f.id)])));
    setCnAxes({ 'ROND-cn': 100 });
    setFontSize(56);
    setText('Hello 2026，探索 Material You 与东方字体的交融之美。');
  };

  /* 应用到全站：写 :root 变量 + localStorage；专属轴不全局化 */
  const applyGlobal = () => {
    if (!cnFont.family) return;
    const root = document.documentElement;
    root.style.setProperty('--vf-en', `'${enFont.family}'`);
    root.style.setProperty('--vf-cn', `'${cnFont.family}'`);
    const rond = enFont.family === 'Google Sans Flex' ? (enAxes.gsf.ROND ?? 0) : 0;
    root.style.setProperty('--vf-rond', String(rond));
    try {
      localStorage.setItem(VF_LS_KEY, JSON.stringify({ en: enFont.family, cn: cnFont.family, rond }));
    } catch {
      /* 无痕模式等存储不可用：本次会话内仍生效 */
    }
    setApplied({ en: enFont.family, cn: cnFont.family, rond });
  };

  const revertGlobal = () => {
    const root = document.documentElement;
    root.style.removeProperty('--vf-en');
    root.style.removeProperty('--vf-cn');
    root.style.removeProperty('--vf-rond');
    try {
      localStorage.removeItem(VF_LS_KEY);
    } catch {
      /* 同上 */
    }
    setApplied(null);
    setEnId('gsf');
    setCnId('wenyuan-rounded');
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            <Type className="h-4 w-4" style={{ color: theme.primary }} />
            可变字体实验室 · 4 英文 × 5 中文 多字体多轴（第 30 轮）
          </h3>
          <p className="mt-0.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
            每条轴的取值范围均为真实字体文件 fvar 表实测（fontTools 逐轴核对，考据报告存{' '}
            <code className="font-mono">evidence/</code>）。英文与数字由选定的英文可变字体渲染，
            汉字由选定的中文可变字体接管；<code className="font-mono">font-weight</code> 同时驱动中英
            wght，<code className="font-mono">font-variation-settings</code> 仅驱动各自专属轴
            （无该轴的字体自动忽略）。
          </p>
        </div>
        <button
          type="button"
          onClick={resetAll}
          className="shrink-0 inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          复位
        </button>
      </div>

      {/* 英文字体选择 */}
      <div className="space-y-1.5">
        <p className="font-mono text-[10px] text-slate-500 dark:text-slate-400">英文可变字体（本地内置 · google/fonts ofl 原文件）</p>
        <div className="flex flex-wrap items-center gap-2">
          {EN_FONTS.map((f) => {
            const active = f.id === enId;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setEnId(f.id)}
                style={active ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary } : undefined}
                className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                  active ? '' : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>
        <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500">{enFont.source}</p>
      </div>

      {/* 中文字体选择 */}
      <div className="space-y-1.5">
        <p className="font-mono text-[10px] text-slate-500 dark:text-slate-400">中文可变字体（CDN 分片 / 本地子集）</p>
        <div className="flex flex-wrap items-center gap-2">
          {CN_FONTS.map((f) => {
            const active = f.id === cnId;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setCnId(f.id)}
                style={active ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary } : undefined}
                className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                  active ? '' : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {f.label}
                {f.badge && (
                  <span className={`ml-1.5 font-mono text-[9px] ${active ? 'opacity-80' : 'text-slate-400'}`}>
                    {f.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
        <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
          {cnId === 'none' ? '− 未选择中文字体（汉字将回退系统字体）' : cnFont.source}
        </p>
        {cnFont.family && (
          <span
            className="inline-flex items-center gap-1.5 font-mono text-[10px]"
            style={{ color: fontStatus === 'ready' ? theme.primary : fontStatus === 'loading' ? '#92400e' : '#b3261e' }}
          >
            {fontStatus === 'ready'
              ? `✓ ${cnFont.family} 已就绪${cnId === 'rhr' ? '（本地子集 2.4MB woff2 · 双轴）' : cnId === 'misans-vf' ? '（jsDelivr 分片按需加载）' : '（fontsapi.zeoseven.com 分片按需加载）'}`
              : fontStatus === 'loading'
                ? '⟳ 正在拉取字体分片…'
                : '✗ 分片拉取失败（回退系统字体；请检查网络后重试）'}
          </span>
        )}
      </div>

      {/* 混排舞台 */}
      <div className="rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 px-6 py-8 overflow-hidden">
        <div
          contentEditable
          suppressContentEditableWarning
          spellCheck={false}
          className="outline-none break-words leading-tight text-slate-900 dark:text-white min-h-[1.3em]"
          style={{
            fontFamily: familyCss,
            fontWeight: wght,
            fontVariationSettings: variationCss,
            fontOpticalSizing: 'auto',
            fontSize: `${fontSize}px`,
          }}
        >
          {text}
        </div>
        <div className="mt-4" style={{ fontFamily: familyCss, fontWeight: wght, fontVariationSettings: variationCss }}>
          <p className="text-sm leading-loose text-slate-600 dark:text-slate-300">{MIXED_BODY_TEXT}</p>
        </div>
        <div className="mt-4">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="修改大标题混排文本..."
            style={{ outlineColor: theme.primary }}
            className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-2"
          />
        </div>
      </div>

      {/* 轴滑块：wght（中英联动，取中英轴范围交集——诚实呈现双方共同可达区间）
          + 当前英文字体专属轴 + 当前中文专属轴 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2.5">
        <AospExpressiveSlider
          label={W_GSF.label}
          value={Math.max(wghtMin, Math.min(wght, wghtMax))}
          min={wghtMin}
          max={wghtMax}
          step={1}
          size="xs"
          compact
          unit=""
          formatValue={(v) => `${Math.round(v)} · font-weight 驱动中英`}
          accentHex={theme.primary}
          theme={theme}
          onChange={setWght}
        />
        {enFont.axes.map((a) => (
          <AospExpressiveSlider
            key={a.key}
            label={`${a.label}（${enFont.family}）`}
            value={enAxes[enId][a.key]}
            min={a.min}
            max={a.max}
            step={a.step}
            size="xs"
            compact
            unit=""
            formatValue={(v) => `${v} · ${a.note.split('，')[0]}`}
            accentHex={theme.primary}
            theme={theme}
            onChange={(v) => setAxis(a.key, v)}
          />
        ))}
        {cnFont.axes.map((a) => (
          <AospExpressiveSlider
            key={a.key}
            label={`${a.label}（${cnFont.family}）`}
            value={cnAxes[a.key] ?? a.def}
            min={a.min}
            max={a.max}
            step={a.step}
            size="xs"
            compact
            unit=""
            formatValue={(v) => `${v} · ${a.note.split('，')[0]}`}
            accentHex={theme.primary}
            theme={theme}
            onChange={(v) => setCnAxes((p) => ({ ...p, [a.key]: v }))}
          />
        ))}
        <AospExpressiveSlider
          label="预览字号"
          value={fontSize}
          min={16}
          max={96}
          step={1}
          size="xs"
          compact
          unit="px"
          accentHex={theme.primary}
          theme={theme}
          onChange={setFontSize}
        />
      </div>

      {/* 混搭预设（第 20 轮 3 条 + 第 30 轮 4 条） */}
      <div className="flex flex-wrap items-center gap-2">
        {MIXED_PRESETS.map((p) => {
          const active =
            p.en === enId && p.cn === cnId && p.wght === wght &&
            JSON.stringify(p.enAxes) === JSON.stringify(enAxes[enId]) &&
            (!p.cnAxes || JSON.stringify(p.cnAxes) === JSON.stringify(cnAxes));
          return (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setEnId(p.en);
                setCnId(p.cn);
                setWght(p.wght);
                setEnAxes((prev) => ({ ...prev, [p.en]: { ...enDefaults(p.en), ...p.enAxes } }));
                if (p.cnAxes) setCnAxes({ ...p.cnAxes });
              }}
              style={active ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary } : undefined}
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                active ? '' : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {p.label}
            </button>
          );
        })}
        <button
          type="button"
          onClick={applyGlobal}
          disabled={!cnFont.family}
          title={cnFont.family ? '把英文/中文字体搭配与英文圆角 ROND 写入 :root 变量并持久化（全站所有区块生效）' : '请先选择一个中文字体，再应用全站'}
          style={applied ? { backgroundColor: theme.primary, color: theme.onPrimary, borderColor: theme.primary } : { borderColor: theme.primary, color: theme.primary }}
          className="rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap disabled:cursor-not-allowed disabled:opacity-40"
        >
          {applied ? '已应用到全站（再次点击刷新全局值）' : '应用到全站'}
        </button>
        {applied && (
          <button
            type="button"
            onClick={revertGlobal}
            className="rounded-full border border-slate-200 dark:border-slate-700 px-3 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
          >
            撤销全站应用
          </button>
        )}
      </div>

      {/* GSF 英文单飞轴预设（第 12 轮保留，仅 GSF 生效） */}
      {enId === 'gsf' && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 shrink-0">GSF 单飞预设：</span>
          {GSF_ENGLISH_PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setEnAxes((prev) => ({ ...prev, gsf: { ...p.axes } }));
                setWght(p.wght);
              }}
              style={
                JSON.stringify(p.axes) === JSON.stringify(enAxes.gsf) && p.wght === wght
                  ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary }
                  : undefined
              }
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                JSON.stringify(p.axes) === JSON.stringify(enAxes.gsf) && p.wght === wght
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      )}

      <div className="rounded-lg bg-slate-950 dark:bg-slate-950/80 border border-slate-800 px-4 py-3 font-mono text-[11px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre">
        {`.mixed-typography {
  font-family: ${familyCss};
  font-weight: ${wght}; /* 同时驱动中英文可变字重 */
  font-variation-settings: ${variationCss || '/* 当前字体无专属轴 */'}; /* 各自专属轴 */
  font-synthesis-style: none;
}`}
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        全站应用范围：英文字体（--vf-en）、中文字体搭配（--vf-cn）与英文圆角 ROND（--vf-rond）写入
        :root，其余专属轴不全局化——font-variation-settings 会覆盖 font-weight，硬套全站会毁掉
        所有组件的语义字重层级（取舍说明见 globals.css 注释）。考据排除记录：霞鹜文楷 v1.530 官方
        仅 3 静态字重（无可变版）；OPPO Sans VF 仅存于 ColorOS 系统内未提供下载；阿里巴巴普惠体
        3.0 仅静态字重。
      </p>
    </div>
  );
};
