"use client";
/**
 * M3 Checkbox 三态图标动画 · 第 30 轮新增细节动画（真实源码转译）
 * ============================================================
 * 【取证通道】evidence/mdc-1.14.0-tokens/material.aar（MDC-Android 1.14.0 官方
 *   AAR，离线原文）——res/drawable 与 res/values 逐 XML 提取，2026-11 本地解包核对。
 *
 * 【路径数据】（values.xml string 资源，32×32 viewport）
 *   mtrl_checkbox_button_icon_path_checked        = M14,18.2 11.4,15.6 10,17 14,21 22,13 20.6,11.6z
 *   mtrl_checkbox_button_icon_path_indeterminate = M13.4,15 11,15 11,17 13.4,17 21,17 21,15z
 *   mtrl_checkbox_button_path_checked（实心方块） = M23,7H9C7.9,7,7,7.9,7,9v14c0,1.1,0.9,2,2,2h14c1.1,0,2-0.9,2-2V9C25,7.9,24.1,7,23,7z
 *   mtrl_checkbox_button_path_unchecked（描边框） = 同上 + M23,23H9V9h14V23z（evenodd 挖空）
 *
 * 【动画器】（animated-vector objectAnimator，逐 target 提取）
 *   unchecked → checked（mtrl_checkbox_button_icon_unchecked_checked.xml）：
 *     icon 组 scaleX/scaleY 0.6→1.0 · duration = m3_sys_motion_duration_medium3 = 350ms
 *       · motionEasingEmphasizedDecelerate（控制点 (0.1,0.7)-(0.1,1)，values.xml dimen）
 *     check 路径 trimPathEnd 0→1 · medium3 · 同上缓动
 *   checked → unchecked（mtrl_checkbox_button_icon_checked_unchecked.xml）：
 *     icon 组 scaleX/scaleY 1.0→0.6 · duration = short3 = 150ms
 *       · motionEasingEmphasizedAccelerate（(0.3,0)-(0.8,0.2)）
 *     check 路径 fillAlpha 1→0 · short1 = 50ms · motionEasingLinear（(0,0)-(1,1)）
 *   checked ↔ indeterminate（checked_indeterminate / indeterminate_checked.xml）：
 *     check 路径 pathData 形变（勾↔横线）· medium3 · emphasizedAccelerate
 *   方块（mtrl_checkbox_button_checked_unchecked / unchecked_checked）：
 *     同方向 scale 1↔0.6（short3/medium3 同缓动）+ fillAlpha（short1 linear）
 *
 * 【时长 token】AAR values.xml integer：short1=50 · short2=100 · short3=150 ·
 *   short4=200 · medium3=350（m3_sys_motion_duration_*）
 * 【诚实边界】①trimPathEnd 在 Android 端作用于 AVD 路径；Web 端以 stroke 描画 +
 *   dashoffset 复现 draw-on 手感，勾形以 stroke-width 校准至 fill 版等宽观感；
 *   ②MDC 图标着色走 ColorStateList（m3_checkbox_button_icon_tint），本页固定用
 *   当前主题 primary 作 checked 色 / onPrimary 作勾色。
 */
import React, { useEffect, useRef, useState } from 'react';
import { M3ThemeTokens } from '../../aosp/dynamicColor';

interface CheckboxDrawDemoProps {
  theme: M3ThemeTokens;
}

/* —— 路径数据（32×32 viewport，AAR values.xml 原文） —— */
const PATH_CHECK = 'M14,18.2 11.4,15.6 10,17 14,21 22,13 20.6,11.6z';
const PATH_DASH = 'M13.4,15 11,15 11,17 13.4,17 21,17 21,15z';
const PATH_BOX_FILLED = 'M23,7H9C7.9,7,7,7.9,7,9v14c0,1.1,0.9,2,2,2h14c1.1,0,2-0.9,2-2V9C25,7.9,24.1,7,23,7z';
const PATH_BOX_OUTLINE = PATH_BOX_FILLED + ' M23,23H9V9h14V23z';

/* —— 时长/缓动（AAR values.xml 真值） —— */
const MEDIUM3 = 350;
const SHORT3 = 150;
const SHORT1 = 50;
const EASE_EMPH_DECEL = 'cubic-bezier(0.1, 0.7, 0.1, 1)';   // emphasizedDecelerate
const EASE_EMPH_ACCEL = 'cubic-bezier(0.3, 0.0, 0.8, 0.2)'; // emphasizedAccelerate
const EASE_LINEAR = 'cubic-bezier(0, 0, 1, 1)';             // motionEasingLinear

/** 勾形折线总长（M + 5 段直线，32 视口坐标累计）——dashoffset draw-on 用 */
function polyLen(d: string): number {
  const nums = d.replace(/[^0-9.,\-]/g, ' ').split(/[ ,]+/).filter(Boolean).map(Number);
  let len = 0;
  for (let i = 2; i + 1 < nums.length; i += 2) {
    len += Math.hypot(nums[i] - nums[i - 2], nums[i + 1] - nums[i - 1]);
  }
  return len;
}
const CHECK_PATH_LEN = polyLen(PATH_CHECK);

type Tri = 'unchecked' | 'checked' | 'indeterminate';

export const CheckboxDrawDemo: React.FC<CheckboxDrawDemoProps> = ({ theme }) => {
  const [state, setState] = useState<Tri>('unchecked');
  const prevRef = useRef<Tri>('unchecked');
  const iconGroupRef = useRef<SVGGElement | null>(null);
  const checkStrokeRef = useRef<SVGPathElement | null>(null);
  const checkFillRef = useRef<SVGPathElement | null>(null);
  const boxFillRef = useRef<SVGPathElement | null>(null);
  const boxOutlineRef = useRef<SVGPathElement | null>(null);

  useEffect(() => {
    const prev = prevRef.current;
    prevRef.current = state;
    if (prev === state) return;
    const icon = iconGroupRef.current;
    const stroke = checkStrokeRef.current;
    const fill = checkFillRef.current;
    const boxFill = boxFillRef.current;
    if (!icon || !stroke || !fill || !boxFill || !boxOutlineRef.current) return;

    /* icon 组 scale（源码逐 target：0.6↔1.0，medium3/short3 + emphasized 双向缓动） */
    icon.animate(
      prev === 'unchecked'
        ? [{ transform: 'scale(0.6)' }, { transform: 'scale(1)' }]
        : [{ transform: 'scale(1)' }, { transform: 'scale(0.6)' }],
      {
        duration: prev === 'unchecked' ? MEDIUM3 : SHORT3,
        easing: prev === 'unchecked' ? EASE_EMPH_DECEL : EASE_EMPH_ACCEL,
        fill: 'forwards',
      },
    );

    if (prev === 'unchecked' && state === 'checked') {
      // trimPathEnd 0→1 @350ms emphasizedDecelerate（stroke draw-on）
      stroke.animate(
        [{ strokeDashoffset: CHECK_PATH_LEN, opacity: 0 }, { strokeDashoffset: 0, opacity: 1 }],
        { duration: MEDIUM3, easing: EASE_EMPH_DECEL, fill: 'forwards' },
      );
      fill.animate([{ opacity: 0 }, { opacity: 1 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
      boxFill.animate([{ opacity: 0 }, { opacity: 1 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
      boxOutlineRef.current.animate([{ opacity: 0.62 }, { opacity: 0 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
    } else if (prev === 'checked' && state === 'unchecked') {
      // fillAlpha 1→0 @50ms linear + scale 1→0.6（上面）@150ms emphasizedAccelerate
      fill.animate([{ opacity: 1 }, { opacity: 0 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
      stroke.animate([{ opacity: 1 }, { opacity: 0 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
      boxFill.animate([{ opacity: 1 }, { opacity: 0 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
      boxOutlineRef.current.animate([{ opacity: 0 }, { opacity: 0.62 }], { duration: SHORT1, easing: EASE_LINEAR, fill: 'forwards' });
    } else {
      // checked ↔ indeterminate：pathData 勾↔横线形变 @350ms emphasizedAccelerate
      // 两路径同为 M + 5 段 L + z（命令结构一致 → 浏览器 d 插值可用）
      const anim = fill.animate(
        prev === 'checked'
          ? [{ d: PATH_CHECK }, { d: PATH_DASH }]
          : [{ d: PATH_DASH }, { d: PATH_CHECK }],
        { duration: MEDIUM3, easing: EASE_EMPH_ACCEL, fill: 'forwards' },
      );
      stroke.animate([{ opacity: 0 }, { opacity: 0 }], { duration: MEDIUM3, fill: 'forwards' });
      return () => anim.cancel();
    }
  }, [state]);

  const chips: { key: Tri; label: string }[] = [
    { key: 'unchecked', label: '未选' },
    { key: 'checked', label: '已选' },
    { key: 'indeterminate', label: '半选' },
  ];

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            Checkbox 三态动画 · MDC-Android 1.14.0 AVD 真值
          </h3>
          <p className="mt-0.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
            路径、时长、缓动逐值转译自 evidence 内官方 AAR（离线取证）：勾形{' '}
            <code className="font-mono">M14,18.2…20.6,11.6z</code>；进场 scale 0.6→1 @350ms
            emphasizedDecelerate(0.1,0.7,0.1,1)，退场 1→0.6 @150ms emphasizedAccelerate(0.3,0,0.8,0.2)，
            fillAlpha @50ms linear，半选走 pathData 形变（勾↔横线）。点击复选框或状态徽章切换。
          </p>
        </div>
        <div className="flex gap-2 shrink-0">
          {chips.map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={() => setState(c.key)}
              style={
                state === c.key
                  ? { backgroundColor: theme.primary, borderColor: theme.primary, color: theme.onPrimary }
                  : undefined
              }
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                state === c.key
                  ? ''
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* 主演示：可点击的单枚复选框（动画 ref 挂载于此） */}
      <div className="flex items-center justify-center py-6">
        <button
          type="button"
          aria-label="三态复选框演示"
          onClick={() => setState(state === 'checked' ? 'unchecked' : state === 'unchecked' ? 'checked' : 'unchecked')}
          className="rounded-xl p-3 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
        >
          <svg width={64} height={64} viewBox="0 0 32 32">
            {/* 方块描边（unchecked，evenodd 挖空路径原文） */}
            <path
              ref={boxOutlineRef}
              d={PATH_BOX_OUTLINE}
              fillRule="evenodd"
              fill={theme.primary}
              opacity={state === 'unchecked' ? 0.62 : 0}
            />
            {/* 方块实心（checked/indeterminate） */}
            <path
              ref={boxFillRef}
              d={PATH_BOX_FILLED}
              fill={theme.primary}
              opacity={state === 'unchecked' ? 0 : 1}
            />
            <g ref={iconGroupRef} style={{ transformOrigin: '16px 16px' }}>
              {/* 勾形：stroke 复现 trimPathEnd draw-on + fill 兜底（AVD fill 原文） */}
              <path
                ref={checkStrokeRef}
                d={PATH_CHECK}
                fill="none"
                stroke={theme.onPrimary}
                strokeWidth={2.2}
                strokeLinejoin="round"
                strokeLinecap="square"
                strokeDasharray={CHECK_PATH_LEN}
                strokeDashoffset={state === 'checked' ? 0 : CHECK_PATH_LEN}
                opacity={state === 'checked' ? 1 : 0}
              />
              <path
                ref={checkFillRef}
                d={state === 'indeterminate' ? PATH_DASH : PATH_CHECK}
                fill={theme.onPrimary}
                opacity={state === 'unchecked' ? 0 : 1}
              />
            </g>
          </svg>
        </button>
      </div>

      <div className="rounded-lg bg-slate-950 dark:bg-slate-950/80 border border-slate-800 px-4 py-3 font-mono text-[11px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre">
        {`<!-- AAR: mtrl_checkbox_button_icon_unchecked_checked.xml（unchecked→checked） -->
<objectAnimator duration="@integer/m3_sys_motion_duration_medium3" <!-- 350ms -->
  interpolator="?attr/motionEasingEmphasizedDecelerate" <!-- (0.1,0.7)-(0.1,1) -->
  propertyName="trimPathEnd" valueFrom="0.0" valueTo="1.0"/>
<!-- checked→unchecked: scaleX/Y 1.0→0.6 @150ms emphasizedAccelerate + fillAlpha 1→0 @50ms linear
     checked↔indeterminate: pathData 勾↔横线形变 @350ms emphasizedAccelerate -->`}
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        诚实边界：trimPathEnd 在 Android 端作用于 AVD 路径，Web 端以 stroke-dashoffset 复现
        draw-on（stroke-width 校准至 fill 版等宽）；图标色固定当前主题 primary（MDC 端为
        ColorStateList m3_checkbox_button_icon_tint，按状态/主题动态取值）。
      </p>
    </div>
  );
};
