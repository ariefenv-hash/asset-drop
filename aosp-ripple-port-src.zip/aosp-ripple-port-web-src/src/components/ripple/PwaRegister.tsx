"use client";
/**
 * 第 29 轮：PWA Service Worker 注册组件。
 *
 * · 仅生产构建注册（dev 模式下 Next 的 HMR/整页刷新与 SW 缓存互相干扰，
 *   且 standalone dev 服务器不产出可缓存形态）；
 * · 路径经 withBasePath 注入——两种分发形态自动适配：
 *     standalone（根路径）→ /sw.js，scope = /；
 *     NEXT_EXPORT=1 + NEXT_BASE_PATH=/asset-drop（GitHub Pages）→
 *     /asset-drop/sw.js，scope = /asset-drop/（manifest 与 sw.js 内部
 *     全部使用相对 URL 解析，无需运行时探测）；
 * · 注册失败静默（无痕模式 / 不支持 SW 的浏览器照常访问，PWA 为渐进增强）。
 */
import { useEffect } from 'react';
import { withBasePath } from '@/lib/publicPath';

export function PwaRegister() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') return;
    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
    const swUrl = withBasePath('/sw.js');
    const onLoad = () => {
      navigator.serviceWorker.register(swUrl).catch(() => {
        /* 渐进增强：注册失败不影响站点功能 */
      });
    };
    if (document.readyState === 'complete') onLoad();
    else {
      window.addEventListener('load', onLoad, { once: true });
      return () => window.removeEventListener('load', onLoad);
    }
  }, []);
  return null;
}
