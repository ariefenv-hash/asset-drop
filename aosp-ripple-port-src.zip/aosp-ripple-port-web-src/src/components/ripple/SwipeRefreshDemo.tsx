"use client";
/**
 * androidx SwipeRefreshLayout × CircularProgressDrawable 移植 · 第 30 轮新增细节动画
 * ============================================================
 * 【真实源码位置】androidx/androidx（androidx-main，2026-11 联网逐值取证）：
 *   - swiperefreshlayout/swiperefreshlayout/src/main/java/androidx/swiperefreshlayout/
 *     widget/SwipeRefreshLayout.java（1454 行）：
 *       CIRCLE_DIAMETER = 40dp（L88）/ CIRCLE_DIAMETER_LARGE = 56dp（L90）
 *       MAX_ALPHA = 255（L94）/ STARTING_PROGRESS_ALPHA = (int)(0.3f*255) = 76（L95）
 *       DECELERATE_INTERPOLATION_FACTOR = 2f（L97）
 *       DRAG_RATE = .5f（L99，下拉位移 → 环位移的阻尼比）
 *       MAX_PROGRESS_ANGLE = .8f（L103）
 *       SCALE_DOWN_DURATION = 150（L105）/ ALPHA_ANIMATION_DURATION = 300（L107）
 *       ANIMATE_TO_TRIGGER_DURATION = 200（L109）/ ANIMATE_TO_START_DURATION = 200（L111）
 *       DEFAULT_CIRCLE_TARGET = 64dp（L114，刷新触发距离）
 *       DEFAULT_SLINGSHOT_DISTANCE = -1（L85）
 *   - 同目录 CircularProgressDrawable.java：
 *       DEFAULT：CENTER_RADIUS 7.5 / STROKE_WIDTH 2.5 / ARROW_WIDTH 10 / ARROW_HEIGHT 5（L88-91）
 *       LARGE：CENTER_RADIUS 11 / STROKE_WIDTH 3 / ARROW 12×6（L80-83）
 *       COLORS = { Color.BLACK }（L97-102，默认黑；API setColorSchemeColors 覆写）
 *       COLOR_CHANGE_OFFSET = 0.75f（L105）/ SHRINK_OFFSET = 0.5f（L106）
 *       ANIMATION_DURATION = 1332ms（L109）/ GROUP_FULL_ROTATION = 1080f/5f = 216°（L112）
 *       MAX_PROGRESS_ARC = .8f（L121）/ MIN_PROGRESS_ARC = .01f（L123）
 *       RING_ROTATION = 1 - (0.8 - 0.01) = 0.21（L126）
 *       MATERIAL_INTERPOLATOR = FastOutSlowIn（L70，(0.4,0)-(0.2,1)）
 *       applyTransformation L542-564：前半（t<0.5）endTrim 由 FOSI(t/0.5) 扩张；
 *       后半 startTrim 以 1-FOSI 收缩；ring 自转 0.21·t；组旋转 216°·(t+count)。
 * 【几何直译说明】环以 24u 绘制空间直译（DEFAULT 外径 = CENTER_RADIUS+STROKE/2 = 8.75u，
 *   LARGE = 12.5u），SwipeRefresh 的 40/56dp 视口缩放原样保留；与 Android 端同一圆环数学。
 * 【诚实边界】①Android 端的 VelocityTracker 判速（fling 直接触发）未移植——Web 端以
 *   pointer 位移判据等价实现；②箭头在小尺寸下的 arrowScale 微调未逐帧复刻，只保留
 *   「弧长 ≥ 0.3 才显箭头」的显隐规则（源码 Ring.setStartTrim L852-880 的 showArrow 判据）。
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { M3ThemeTokens } from '../../aosp/dynamicColor';

interface SwipeRefreshDemoProps {
  theme: M3ThemeTokens;
  isDark: boolean;
}

/* —— 原样转译的常量表（全部真实源码值） —— */
const CIRCLE_DIAMETER = 40;          // L88
const CIRCLE_DIAMETER_LARGE = 56;    // L90
const MAX_ALPHA = 255;               // L94
const STARTING_PROGRESS_ALPHA = 76;  // L95 = (int)(0.3f*255)
const DRAG_RATE = 0.5;               // L99
const ANIMATE_TO_TRIGGER_DURATION = 200; // L109
const ANIMATE_TO_START_DURATION = 200;   // L111
const SCALE_DOWN_DURATION = 150;     // L105
const ALPHA_ANIMATION_DURATION = 300;// L107
const DEFAULT_CIRCLE_TARGET = 64;    // L114（dp）
const MAX_PROGRESS_ANGLE = 0.8;      // SwipeRefreshLayout L103（拖拽期弧长上限）
const ANIMATION_DURATION = 1332;     // CPD L109
const GROUP_FULL_ROTATION = 1080 / 5;// CPD L112 = 216°
const MAX_PROGRESS_ARC = 0.8;        // CPD L121
const MIN_PROGRESS_ARC = 0.01;       // CPD L123
const RING_ROTATION = 1 - (MAX_PROGRESS_ARC - MIN_PROGRESS_ARC); // CPD L126 = 0.21
const SHRINK_OFFSET = 0.5;           // CPD L106
const COLOR_CHANGE_OFFSET = 0.75;    // CPD L105（默认单色，实际不触发换色，转译保留）

/** FastOutSlowIn = (0.4,0)-(0.2,1)：MATERIAL_INTERPOLATOR（CPD L70 + mtrl_fast_out_slow_in.xml） */
const fastOutSlowIn = (t: number) => {
  if (t <= 0) return 0;
  if (t >= 1) return 1;
  // 三次贝塞尔 x(t)=3(1-t)²t·x1 + 3(1-t)t²·x2 + t³，牛顿迭代求 x→t 后代回 y
  const x1 = 0.4, y1 = 0, x2 = 0.2, y2 = 1;
  let lo = 0, hi = 1, guess = t;
  for (let i = 0; i < 12; i++) {
    const cx = 3 * (1 - guess) * (1 - guess) * guess * x1 + 3 * (1 - guess) * guess * guess * x2 + guess * guess * guess;
    if (Math.abs(cx - t) < 1e-5) break;
    if (cx < t) lo = guess; else hi = guess;
    guess = (lo + hi) / 2;
  }
  const y = 3 * (1 - guess) * (1 - guess) * guess * y1 + 3 * (1 - guess) * guess * guess * y2 + guess * guess * guess;
  return y;
};

const DecelerateInterpolator = (t: number, factor = 2) => 1 - (1 - t) ** factor; // L97 factor=2

type Phase = 'idle' | 'drag' | 'spinner' | 'finishing';

export const SwipeRefreshDemo: React.FC<SwipeRefreshDemoProps> = ({ theme, isDark }) => {
  const [large, setLarge] = useState(false);
  const [offsetY, setOffsetY] = useState(0);      // 环位移（px，含 slingshot）
  const [phase, setPhase] = useState<Phase>('idle');
  const [triggered, setTriggered] = useState(false); // 是否越过 64dp 触发线
  const [items, setItems] = useState<string[]>(() => ['洗衣液 · 剩余 63%', '门锁 · 已反锁', '扫地机 · 回充完成']);
  const [log, setLog] = useState<string[]>([]);

  const wrapRef = useRef<HTMLDivElement | null>(null);
  const startYRef = useRef(0);
  const rafRef = useRef(0);
  const spinRef = useRef({ t: 0, count: 0, last: 0 });
  const ringRef = useRef<HTMLCanvasElement | null>(null);
  const phaseRef = useRef<Phase>('idle');
  phaseRef.current = phase;

  const box = large ? CIRCLE_DIAMETER_LARGE : CIRCLE_DIAMETER;
  const ringColor = isDark ? '#ffffff' : '#000000'; // COLORS = { Color.BLACK }（L97-102）

  /* CircularProgressDrawable：1332ms 单周期扫掠（applyTransformation L542-564 逐式转译） */
  useEffect(() => {
    if (phase !== 'spinner' && phase !== 'finishing') return;
    let alive = true;
    const startTs = performance.now();
    const startOffset = offsetYRef.current;
    const finishDuration = ANIMATION_DURATION / 2; // CPD L452：finishing 半周期

    const frame = (now: number) => {
      if (!alive) return;
      const canvas = ringRef.current;
      if (!canvas) return;
      if (phaseRef.current === 'finishing') {
        // applyFinishTranslation：弧收缩至 0 + 位移收回到 0（FOSI，半周期 666ms）
        const t = Math.min(1, (now - startTs) / finishDuration);
        const e = fastOutSlowIn(t);
        setOffsetY(startOffset * (1 - e));
        drawRing(canvas, { start: 0, end: Math.max(0.01, (1 - e) * 0.79), rot: spinRef.current.t * 216, arrow: false, t: spinRef.current.t });
        if (t >= 1) { setPhase('idle'); return; }
        rafRef.current = requestAnimationFrame(frame);
        return;
      }
      // spinner：t = (now-startTs) % ANIMATION_DURATION
      const t = ((now - startTs) % ANIMATION_DURATION) / ANIMATION_DURATION;
      spinRef.current.t = t;
      // applyTransformation 转译
      let startTrim: number, endTrim: number;
      if (t < SHRINK_OFFSET) {
        const scaled = t / SHRINK_OFFSET;
        startTrim = 0; // ring.getStartingStartTrim() = 0（Ring 构造 L629-630）
        endTrim = startTrim + (MAX_PROGRESS_ARC - MIN_PROGRESS_ARC) * fastOutSlowIn(scaled) + MIN_PROGRESS_ARC;
      } else {
        const scaled = (t - SHRINK_OFFSET) / (1 - SHRINK_OFFSET);
        endTrim = 0 + (MAX_PROGRESS_ARC - MIN_PROGRESS_ARC);
        // 源码 L553-556：startTrim = endTrim - 0.79·(1-FOSI(scaled)) - 0.01
        startTrim = endTrim - (MAX_PROGRESS_ARC - MIN_PROGRESS_ARC) * (1 - fastOutSlowIn(scaled)) - MIN_PROGRESS_ARC;
      }
      const ringRot = RING_ROTATION * t;          // L557
      const groupRot = GROUP_FULL_ROTATION * t;   // L558（count 由 % 周期天然复位）
      drawRing(canvas, { start: startTrim, end: endTrim, rot: ringRot, group: groupRot, arrow: endTrim - startTrim > 0.3, t });
      rafRef.current = requestAnimationFrame(frame);
    };
    rafRef.current = requestAnimationFrame(frame);
    return () => { alive = false; cancelAnimationFrame(rafRef.current); };
  }, [phase]);

  // 拖拽期的环位移快照（供 finishing 回收起始值）
  const offsetYRef = useRef(0);
  offsetYRef.current = offsetY;

  /** 环绘制：24u 空间 → box 视口；strokeCap=SQUARE（Ring 构造 L650） */
  const drawRing = (
    canvas: HTMLCanvasElement,
    o: { start: number; end: number; rot: number; group?: number; arrow: boolean; t: number },
  ) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const px = box * dpr;
    if (canvas.width !== px) { canvas.width = px; canvas.height = px; }
    ctx.clearRect(0, 0, px, px);
    ctx.save();
    const u = px / 24; // 24u 绘制空间
    const cx = px / 2, cy = px / 2;
    if (o.group !== undefined) { ctx.translate(cx, cy); ctx.rotate((o.group * Math.PI) / 180); ctx.translate(-cx, -cy); }
    const stroke = (large ? 3 : 2.5) * u * (box / (large ? 48 : 40)) * (large ? 1 : 1); // STROKE_WIDTH(L80-89)
    const ringR = (large ? 12.5 : 8.75) * u * (box / (large ? 48 : 40));
    const alpha = phase === 'drag' || phase === 'idle'
      ? (offsetYRef.current <= 0 ? 0 : Math.min(1, STARTING_PROGRESS_ALPHA / MAX_ALPHA + offsetYRef.current / DEFAULT_CIRCLE_TARGET * 0.7))
      : 1;
    ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
    ctx.strokeStyle = ringColor;
    ctx.lineWidth = stroke;
    ctx.lineCap = 'square';
    const a0 = (o.start + o.rot) * Math.PI * 2;
    const a1 = (o.end + o.rot) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(cx, cy, ringR, a0, a1);
    ctx.stroke();
    // 箭头（ARROW_WIDTH/HEIGHT：L82-83/L90-91；显隐判据 endTrim-startTrim>0.3）
    if (o.arrow) {
      const aw = (large ? 12 : 10) * u * (box / (large ? 48 : 40));
      const ah = (large ? 6 : 5) * u * (box / (large ? 48 : 40));
      const tipA = a1;
      const tipX = cx + Math.cos(tipA) * ringR;
      const tipY = cy + Math.sin(tipA) * ringR;
      ctx.save();
      ctx.translate(tipX, tipY);
      ctx.rotate(tipA);
      ctx.fillStyle = ringColor;
      ctx.beginPath();
      ctx.moveTo(0, -ah / 2);
      ctx.lineTo(aw, 0);
      ctx.lineTo(0, ah / 2);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  };

  // 拖拽/静止帧重绘
  useEffect(() => {
    const canvas = ringRef.current;
    if (!canvas || (phase !== 'idle' && phase !== 'drag')) return;
    const t = Math.min(1, offsetY / DEFAULT_CIRCLE_TARGET);
    const arc = 0.01 + (MAX_PROGRESS_ANGLE - 0.01) * t; // setStartTrim/setEndTrim L329-330 语义
    drawRing(canvas, { start: 0, end: arc, rot: 0, arrow: false, t });
  });

  const onPointerDown = (e: React.PointerEvent) => {
    if (phase !== 'idle') return;
    startYRef.current = e.clientY;
    setPhase('drag');
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (phase !== 'drag') return;
    const dy = e.clientY - startYRef.current;
    if (dy <= 0) { setOffsetY(0); setTriggered(false); return; }
    const damped = dy * DRAG_RATE;                       // DRAG_RATE 0.5（L99）
    setOffsetY(Math.min(damped, DEFAULT_CIRCLE_TARGET * 2));
    setTriggered(damped >= DEFAULT_CIRCLE_TARGET);       // DEFAULT_CIRCLE_TARGET 64dp（L114）
  };
  const onPointerUp = () => {
    if (phase !== 'drag') return;
    if (offsetYRef.current >= DEFAULT_CIRCLE_TARGET) {
      setPhase('spinner');
      setLog((l) => ['下拉越过 64dp 触发线 → 进 spinner（1332ms/圈，216° 组旋转）', ...l].slice(0, 4));
      window.setTimeout(() => {
        setPhase('finishing');
        setItems((prev) => [`刷新时间戳 · ${new Date().toLocaleTimeString('zh-CN')}`, ...prev.slice(0, 2)]);
        setLog((l) => ['finishing：弧收缩 + 位移回收（FOSI，666ms = ANIMATION_DURATION/2）', ...l].slice(0, 4));
      }, 1600);
    } else {
      // 未过线：ANIMATE_TO_START_DURATION = 200ms 收回（L111）
      setPhase('idle');
      setOffsetY(0);
      setLog((l) => ['未过线 → 200ms 弹回起点（ANIMATE_TO_START_DURATION）', ...l].slice(0, 4));
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            下拉刷新 · androidx SwipeRefreshLayout 真值移植
          </h3>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            常量逐值转译自 androidx-main{' '}
            <code className="font-mono">SwipeRefreshLayout.java</code>（DRAG_RATE 0.5 / 触发线 64dp /
            圆径 40·56dp / 回收 200ms）与{' '}
            <code className="font-mono">CircularProgressDrawable.java</code>
            （1332ms 扫掠 / 216° 组旋转 / 弧长 0.01–0.8 / 前后半 FOSI）。在下方卡片顶部按住下拉体验。
          </p>
        </div>
        <button
          type="button"
          onClick={() => setLarge((v) => !v)}
          style={large ? { backgroundColor: theme.primary, color: theme.onPrimary, borderColor: theme.primary } : { borderColor: theme.primary, color: theme.primary }}
          className="shrink-0 rounded-full border px-3 py-1 text-xs font-medium"
        >
          {large ? 'LARGE · 56dp（CENTER_RADIUS 11 / STROKE 3）' : 'DEFAULT · 40dp（CENTER_RADIUS 7.5 / STROKE 2.5）'}
        </button>
      </div>

      <div
        ref={wrapRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        className="relative select-none touch-none overflow-hidden rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60"
        style={{ height: 300 }}
      >
        {/* 环视口：跟随 offset（setProgressBarTranslationY 语义）
            drag: 环心随 offset 下滑；spinner: 锁定在 64dp 触发线上；finishing: 随回收淡出 */}
        <div
          className="absolute left-1/2 flex justify-center"
          style={{
            transform: `translateX(-50%) translateY(${
              phase === 'spinner'
                ? DEFAULT_CIRCLE_TARGET
                : Math.max(0, offsetY - box / 2 + (phase === 'drag' ? 0 : 0))
            }px)`,
          }}
        >
          <canvas
            ref={ringRef}
            style={{ width: box, height: box }}
          />
        </div>
        <div className="absolute inset-x-0 bottom-0 p-4 space-y-2">
          {items.map((it) => (
            <div key={it} className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 px-3.5 py-2.5 text-xs text-slate-700 dark:text-slate-200">
              {it}
            </div>
          ))}
        </div>
        {triggered && phase === 'drag' && (
          <span className="absolute right-3 top-3 rounded-full px-2.5 py-1 text-[10px] font-medium" style={{ backgroundColor: theme.primary, color: theme.onPrimary }}>
            已过 64dp 触发线
          </span>
        )}
      </div>

      <div className="rounded-lg bg-slate-950 dark:bg-slate-950/80 border border-slate-800 px-4 py-3 font-mono text-[11px] leading-relaxed text-emerald-300/90 space-y-0.5">
        <div>DRAG_RATE={DRAG_RATE} · TRIGGER={DEFAULT_CIRCLE_TARGET}dp · CIRCLE={box}dp · SPIN={ANIMATION_DURATION}ms/216°</div>
        <div>ARC ∈ [{MIN_PROGRESS_ARC}, {MAX_PROGRESS_ARC}] · RING_ROTATION={RING_ROTATION} · SHRINK@{SHRINK_OFFSET} · FOSI(0.4,0,0.2,1)</div>
        {log.map((l, i) => (
          <div key={i} className="text-slate-300/80">· {l}</div>
        ))}
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
        诚实边界：Android 端 VelocityTracker 抛掷判速与箭头 arrowScale 逐帧微调未逐行复刻（见头注）；
        环默认色按源码 COLORS = {'{'} Color.BLACK {'}'}，深色演示走 setColorSchemeColors 等价通道换白。
      </p>
    </div>
  );
};
