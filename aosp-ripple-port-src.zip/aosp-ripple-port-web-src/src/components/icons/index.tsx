"use client";
/**
 * Material Symbols 图标渲染器 · 第 27 轮（全站去 npm 化）
 * ============================================================
 * 此前全站图标取自 npm 包 lucide-react（stroke 笔画风格，非 Material
 * 体系——"剪切"按钮图标曾因此两轮返工：lucide 的 Scissors 与官方
 * content_cut 形制不符）。本轮起全站图标切换为官方 Material Symbols
 * Rounded/Outlined fill1 24px：路径数据【原样内联】于同目录
 * materialSymbols.ts（来源 google/material-design-icons 官方仓库，
 * 提取与回退通道见该文件头注），渲染器仅负责挂到 <svg> 上。
 *
 * 设计口径：
 *  · viewBox 沿官方 "0 -960 960 960"（Material Symbols 坐标系），
 *    不做任何重排/缩放，保证与 Google Fonts 渲染逐位一致；
 *  · fill="currentColor"——与 lucide 用法兼容，颜色继续由 style/class
 *    的 color 控制（M3 主题 token 直接可用）；
 *  · fill1 = 实心变体（M3 默认 icon 主题之一，AOSP SystemUI 同款）；
 *  · lucide 兼容面：size / className / style / 其余 SVGProps 透传；
 *    strokeWidth 等笔画参数被无害忽略（官方数据为实心剪影）。
 * ============================================================
 * 第 28 轮修复（用户复核"开关小球勾叉大一圈"的实根因）：
 *  size 尺寸原先经 inline style（width/height: 24px 默认值）写入——内联
 *  样式优先级高于 Tailwind 尺寸类，全站靠 className 定尺寸的图标
 *  （h-4 w-4 / h-3.5 w-3.5 / h-5 w-5 共 6 处）实际全被撑成 24px，
 *  开关小球勾叉由此比原系统大一圈。现改 width/height 属性写入
 *  （lucide 同款语义）：类名/样式可正常覆盖，无类名时仍为默认 24dp。
 * ============================================================
 */
import type { SVGProps } from 'react';
import { MATERIAL_SYMBOLS } from './materialSymbols';

export interface IconProps extends Omit<SVGProps<SVGSVGElement>, 'children'> {
  /** 图标盒边长（px），默认 24dp——M3 图标栅格口径 */
  size?: number | string;
}

function createIcon(name: keyof typeof MATERIAL_SYMBOLS) {
  const markup = MATERIAL_SYMBOLS[name];
  function Icon({ size = 24, style, ...rest }: IconProps) {
    // 第 28 轮：width/height 用属性而非 inline style——属性可被任何 CSS
    // （类名或 style）覆盖，size 默认值才真正退化为兜底；与 lucide 语义一致
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 -960 960 960"
        fill="currentColor"
        aria-hidden="true"
        width={size}
        height={size}
        style={style}
        dangerouslySetInnerHTML={{ __html: markup }}
        {...rest}
      />
    );
  }
  Icon.displayName = `MaterialSymbol(${String(name)})`;
  return Icon;
}

/* 导出清单 = 全站 14 个文件此前 lucide-react 的全部用名 + content_cut
   （第 28 轮补录 check_small/close_small 两枚官方小号光学变体备用——
   经真机逐像素取证，开关小球仍用默认 check/close，见 materialSymbols.ts
   头注取证结论）。命名保持 lucide 习惯（调用点只换 import 来源，
   不动 JSX），其中 ImageIcon 对应 lucide 的 `Image as ImageIcon`；
   ContentCut 供 MaterialButtonGroupDemo 把第 25 轮手工内联的官方路径
   换成统一通道。 */
export const AlignLeft = createIcon('AlignLeft');
export const Archive = createIcon('Archive');
export const ArrowLeft = createIcon('ArrowLeft');
export const BatteryCharging = createIcon('BatteryCharging');
export const Bell = createIcon('Bell');
export const Bluetooth = createIcon('Bluetooth');
export const Bold = createIcon('Bold');
export const Bookmark = createIcon('Bookmark');
export const Camera = createIcon('Camera');
export const Check = createIcon('Check');
export const CheckSmall = createIcon('CheckSmall');
export const ChevronDown = createIcon('ChevronDown');
export const ChevronLeft = createIcon('ChevronLeft');
export const ChevronRight = createIcon('ChevronRight');
export const Clock = createIcon('Clock');
export const CloseSmall = createIcon('CloseSmall');
export const ContentCut = createIcon('ContentCut');
export const ContentCopy = createIcon('ContentCopy');
export const ContentPaste = createIcon('ContentPaste');
export const Copy = createIcon('Copy');
export const Download = createIcon('Download');
export const Edit3 = createIcon('Edit3');
export const Eraser = createIcon('Eraser');
export const ErrorIcon = createIcon('Error');
export const FileText = createIcon('FileText');
export const Flashlight = createIcon('Flashlight');
export const Hand = createIcon('Hand');
export const Heart = createIcon('Heart');
export const Home = createIcon('Home');
export const ImageIcon = createIcon('ImageIcon');
export const ImagePlus = createIcon('ImagePlus');
export const Inbox = createIcon('Inbox');
export const Italic = createIcon('Italic');
export const Keyboard = createIcon('Keyboard');
export const Loader2 = createIcon('Loader2');
export const Mail = createIcon('Mail');
export const Menu = createIcon('Menu');
export const Mic = createIcon('Mic');
export const Moon = createIcon('Moon');
export const MoreHorizontal = createIcon('MoreHorizontal');
export const MoreVertical = createIcon('MoreVertical');
export const Pause = createIcon('Pause');
export const Palette = createIcon('Palette');
export const Plane = createIcon('Plane');
export const Play = createIcon('Play');
export const Plus = createIcon('Plus');
export const RefreshCw = createIcon('RefreshCw');
export const RotateCcw = createIcon('RotateCcw');
export const Search = createIcon('Search');
export const Share2 = createIcon('Share2');
export const Shield = createIcon('Shield');
export const SkipBack = createIcon('SkipBack');
export const SkipForward = createIcon('SkipForward');
export const Sliders = createIcon('Sliders');
export const Star = createIcon('Star');
export const Sun = createIcon('Sun');
export const Type = createIcon('Type');
export const Underline = createIcon('Underline');
export const User = createIcon('User');
export const Volume2 = createIcon('Volume2');
export const Wifi = createIcon('Wifi');
export const X = createIcon('X');

export type { MaterialSymbolName } from './materialSymbols';
