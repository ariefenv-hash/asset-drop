import type { Metadata, Viewport } from "next";
import "./globals.css";
import { withBasePath } from "@/lib/publicPath";
import { PwaRegister } from "@/components/ripple/PwaRegister";

/* 第 27 轮（全站去 npm 化）：①摘除 @/components/ui/toaster（shadcn/Radix 死代码，
    演示自身从未派发过 toast（全站零引用），留在树里只会拖着 radix/react-toast
    等一串 npm 依赖）；
   ②摘除 next/font/google 的 Geist/Geist_Mono——脚手架残留字体，实际排版用的是
    globals.css @layer base :root 声明的 Google Sans Flex × 中文可变字体混排栈，
    Geist 变量只剩被覆写后的空壳（还多出一次构建期字体拉取）。@theme 映射已
    同步改指真实栈，见 globals.css。

   第 29 轮（PWA 化）：
    ①manifest 声明（basePath 感知链接 public/manifest.webmanifest；manifest 文件
      内部全部为相对 URL（./），GitHub Pages 子路径与根路径两种分发形态无需
      任何运行时探测）；
    ②图标换成本地生成集（public/icons/*：Google Sans Flex 可变字体最窄字形
      wdth=25 绘制的「M3」黑字 + 小型涟漪触点装饰；外部 z-cdn 占位 logo 退场，
      去掉最后一个外部图标依赖）；
    ③appleWebApp / themeColor / apple-touch-icon（iOS 添加到主屏）；
    ④body 末尾挂 PwaRegister（仅生产注册 SW；dev 不注册避免 HMR 干扰）。 */

export const metadata: Metadata = {
  title: "AOSP Ripple Port · M3 Expressive 涟漪与组件移植研究",
  description:
    "AOSP RippleShader / RippleAnimationSession 与 M3 Expressive 组件的 Web 移植复现演示，附官方 @material/web 2.5.0 同台对照。学习研究性质，与 Google 无隶属关系。",
  keywords: ["AOSP", "Ripple", "Material Design 3", "Expressive", "WebGL2", "移植"],
  manifest: withBasePath("/manifest.webmanifest"),
  icons: {
    icon: [
      { url: withBasePath("/icons/icon.svg"), type: "image/svg+xml" },
      { url: withBasePath("/icons/icon-32.png"), sizes: "32x32", type: "image/png" },
      { url: withBasePath("/icons/icon-192.png"), sizes: "192x192", type: "image/png" },
    ],
    apple: [{ url: withBasePath("/icons/apple-touch-icon.png"), sizes: "180x180", type: "image/png" }],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "AOSP Ripple Port",
  },
  openGraph: {
    title: "AOSP Ripple Port",
    description: "AOSP 系统级涟漪与 M3 Expressive 组件的 Web 移植复现演示",
    type: "website",
  },
};

/* PWA 主题色：亮暗双档（安装到主屏后浏览器 UI 与 manifest theme_color 一致） */
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#FFFFFF" },
    { media: "(prefers-color-scheme: dark)", color: "#0B0B10" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // 第 22 轮修复：@font-face 的字体 URL 必须按部署形态注入 basePath
  // （CSS 里的 url() 不吃 assetPrefix）。NEXT_PUBLIC_BASE_PATH 由 next.config.ts
  // env 配置在构建期内联：standalone = ''，Pages 导出 = '/asset-drop'。
  // 第 23 轮加固：①src 双 format 回退——个别浏览器不认 'truetype-variations'
  // 老关键字时落到 'truetype'（可变字体照样按可变处理），不再整条 src 报废；
  // ②3.9MB TTF 增加 preload——font-display:swap 期间英文先用回退字形，
  // 大文件慢载时用户会看到"英文没混搭"的假象，preload 显著缩短该窗口。
  const gsfSrc = withBasePath("/fonts/GoogleSansFlex.ttf");
  const fontFaceCss = `@font-face{font-family:'Google Sans Flex';src:url('${gsfSrc}') format('truetype-variations'),url('${gsfSrc}') format('truetype');font-weight:1 1000;font-stretch:25% 151%;font-style:normal;font-optical-sizing:auto;font-display:swap;}`;
  /* 第 30 轮（可变字体扩展）：新增 4 枚 VF 的 @font-face（google/fonts ofl 原文件 +
     资源圆体 CN VF 官方 CFF2 子集），轴范围全部为本地 fontTools fvar 实测：
     · Roboto Flex 13 轴：wght 100-1000 / opsz 8-144 / wdth 25-151 / slnt -10-0
       / GRAD -200-150 / XOPQ 27-175 / YOPQ 25-135 / XTRA 323-603 / YTUC 528-760
       / YTLC 416-570 / YTAS 649-854 / YTDE -305--98 / YTFI 560-788
     · Recursive 5 轴：MONO/CASL/CRSV 0-1（CRSV def 0.5）/ slnt -15-0 / wght 300-1000
     · Fraunces 4 轴：opsz 9-144 / wght 100-900 / SOFT 0-100 / WONK 0-1(def 1)
     · 资源圆体 CN VF 双轴：wght 200-900(def 200) + ROND 0-100(def 100)
       （CyanoHao/Resource-Han-Rounded v1.910 CFF2 VF，OFL；65MB 原件经 fontTools
       子集化 3913 字形 → 2.4MB woff2，GB2312 一级汉字 + ASCII + 常用标点；
       CFF2 需较新浏览器内核，Chrome 62+/Firefox 62+/Safari 11+） */
  const bp = process.env.NEXT_PUBLIC_BASE_PATH || '';
  const vfFaces: { family: string; file: string; weight: string; extra?: string }[] = [
    { family: 'Roboto Flex', file: 'roboto-flex.ttf', weight: '100 1000', extra: 'font-stretch:25% 151%;font-optical-sizing:auto;' },
    { family: 'Recursive', file: 'recursive.ttf', weight: '300 1000', extra: 'font-optical-sizing:auto;' },
    { family: 'Fraunces', file: 'fraunces.ttf', weight: '100 900', extra: 'font-optical-sizing:auto;' },
    { family: 'Resource Han Rounded CN VF', file: 'ResourceHanRoundedCN-VF-Subset.woff2', weight: '200 900', extra: '' },
  ];
  const extraFaceCss = vfFaces
    .map((f) => {
      const src = `${bp}/fonts/${f.file}`;
      const fmt = f.file.endsWith('.woff2')
        ? `format('woff2-variations'),url('${src}') format('woff2')`
        : `format('truetype-variations'),url('${src}') format('truetype')`;
      return `@font-face{font-family:'${f.family}';src:url('${src}') ${fmt};font-weight:${f.weight};font-style:normal;${f.extra ?? ''}font-display:swap;}`;
    })
    .join('');
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <head>
        {/* 字体 preload（React 19 自动置于 head；fonts 按规范以 CORS-anonymous 模式
            拉取，preload 必须 crossorigin 匹配否则等于白预载） */}
        <link rel="preload" href={gsfSrc} as="font" type="font/ttf" crossOrigin="anonymous" />
      </head>
      <body className="antialiased bg-background text-foreground">
        {/* 第 20 条（用户混搭方案）：中文可变字体 CDN（zeoseven fontsapi）。
            family 名与分片注册已实测核实：414 = WenYuan Rounded SC VF（471 分片，
            wght 100–900 可变）· 415 = WenYuan Serif SC VF（411 分片）·
            285 = Noto Serif CJK（672 分片）。英文 Google Sans Flex 不走此处 CDN——
            项目已内置本地 /fonts/GoogleSansFlex.ttf（google/fonts v26，OFL），
            @font-face 自第 22 轮起内联于本文件（basePath 感知）。React 19 会将 <link rel="stylesheet">
            自动提升到 <head>，浏览器端按 unicode-range 分片按需加载。 */}
        <link rel="preconnect" href="https://fontsapi.zeoseven.com" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/414/main/result.css" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/415/main/result.css" />
        <link rel="stylesheet" href="https://fontsapi.zeoseven.com/285/main/result.css" />
        {/* 第 30 轮：MiSans VF（小米官方 VF，dsrkafuu/misanS npm 子集分片；
            family 'MiSans VF'，css 声明 font-weight 150 700 = 字体内部刻度） */}
        <link rel="preconnect" href="https://cdn.jsdelivr.net" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/misans@5.0.0/lib/Normal/MiSansVF.min.css" />
        {/* Google Sans Flex 本地 @font-face（第 22 轮自 globals.css 迁入，见上方注释） */}
        <style dangerouslySetInnerHTML={{ __html: fontFaceCss + extraFaceCss }} />
        {children}
        {/* 第 29 轮：PWA SW 注册（仅生产；渐进增强，失败静默） */}
        <PwaRegister />
      </body>
    </html>
  );
}
